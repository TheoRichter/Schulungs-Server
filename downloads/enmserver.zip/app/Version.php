<?php
namespace wenom;
class Version {
    public const VERSION = "1.4.1";
    public const GITHASH = "1f4667195e33049f622dbecc727fe06ba065f492";
}
