<?php
namespace wenom;
class Version {
    public const VERSION = "1.5.0";
    public const GITHASH = "8c89a5e6865def27ed06a39e98859d3f88013fad";
}
