<?php
$container = $_GET['name'] ?? '';

if (empty($container)) {
    echo json_encode(['error' => '']);
    exit;
}

$cmd = "docker inspect -f '{{.State.Status}}' " . escapeshellarg($container);
$status = trim(shell_exec($cmd));

if ($status === '') {
    echo json_encode(['error' => 'Container nicht gefunden oder Fehler beim Abrufen']);
} else {
    echo json_encode(['name' => $container, 'status' => $status]);
}
?>
