<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cmd = $_POST['command'] ?? '';
	
    // Einfaches Whitelisting – nur erlaubte Kommandos zulassen
    $allowed_cmds = ['docker start XX-mariadb-1', 'docker stop XX-mariadb-1'];
    if (!in_array($cmd, $allowed_cmds)) {
        die("Nicht erlaubter Befehl.");
    }

    $script_path = '/tmp/mein_script.sh';

    // In Datei schreiben
    file_put_contents($script_path, "#!/bin/bash\n$cmd\n");

    // Datei ausführbar machen
    chmod($script_path, 0755);

    // Ausführen (ggf. Ausgabe speichern)
    $output = shell_exec($script_path . ' 2>&1');
    //echo "<pre>$output</pre>";
    //echo "<font color='green'>Status mit F5 anzeigen!</font>";
    echo "<meta http-equiv='refresh' content='1'>";
} else {
?>
<form method="POST">
    <select name="command">
        <option value="docker start XX-mariadb-1">Start</option>
        <option value="docker stop XX-mariadb-1">Stop</option>
    </select>
    <button type="submit">OK</button>
</form>
<?php } ?>
