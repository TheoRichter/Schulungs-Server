<?php
/**
 * LP-Multiwahl
 * ------------
 * Lädt mehrere Laufbahnplanungsdateien (.lp) des SVWS-Servers hoch, füllt sie
 * mit zufällig erzeugten, regelkonformen Fachwahlen (APO-GOSt ab Abitur 2030)
 * und bietet die gefüllten Dateien einzeln oder als ZIP zum Download an.
 *
 * Format: .lp = gzip-komprimiertes JSON im Format GostLaufbahnplanungExportV2
 *         (lpRevision 2, genau ein Schüler pro Datei).
 *
 * Voraussetzungen: PHP >= 7.4 mit zlib (gzdecode/gzencode/gzinflate).
 * ZIP-Archive werden mit eigenem Code gelesen und geschrieben (ZipArchive nicht nötig).
 */

declare(strict_types=1);

const LPM_VERSION      = '1.5';
const LPM_MAX_VERSUCHE = 400;          // Versuche je Schüler, bis eine gültige Laufbahn gefunden ist
const LPM_TTL          = 3600;         // Lebensdauer der erzeugten Dateien auf dem Server (Sekunden)

// Halbjahre: 0 = EF.1, 1 = EF.2, 2 = Q1.1, 3 = Q1.2, 4 = Q2.1, 5 = Q2.2
const HJ_NAMEN = ['EF.1', 'EF.2', 'Q1.1', 'Q1.2', 'Q2.1', 'Q2.2'];

/* =========================================================================
 *  Hilfsfunktionen für Zufall
 * ========================================================================= */

final class Zufall
{
    public static function int(int $min, int $max): int { return mt_rand($min, $max); }
    public static function chance(float $p): bool { return mt_rand() / mt_getrandmax() < $p; }
    /** @template T @param T[] $a @return T|null */
    public static function eins(array $a) { if (!$a) return null; $a = array_values($a); return $a[mt_rand(0, count($a) - 1)]; }
    public static function mischen(array $a): array { $a = array_values($a); shuffle($a); return $a; }
}

/* =========================================================================
 *  Fächer der Oberstufe (aus der .lp-Datei)
 * ========================================================================= */

final class Faecher
{
    /** @var array<int,array> */ public array $alle = [];
    /** @var array<int,string> Kategorie je Fach-ID */ public array $kat = [];

    private const FS_ZEICHEN = 'ECFGHIKLNOPRSTUZ';   // erste Buchstaben möglicher Fremdsprachen-Kürzel
    private const KAT = [
        'D' => 'D', 'M' => 'M', 'SP' => 'SP', 'PX' => 'PX', 'VX' => 'VX',
        'KU' => 'KUMU', 'MU' => 'KUMU',
        'LI' => 'LIT', 'IN' => 'LIT', 'VO' => 'LIT',
        'GE' => 'GE', 'SW' => 'SW', 'PL' => 'PL',
        'EK' => 'GWS', 'PA' => 'GWS', 'PS' => 'GWS', 'RK' => 'GWS',
        'HR' => 'REL', 'OR' => 'REL', 'YR' => 'REL', 'ER' => 'REL', 'KR' => 'REL', 'IL' => 'REL',
        'BI' => 'NWK', 'CH' => 'NWK', 'PH' => 'NWK',
        'EL' => 'NWN', 'IF' => 'NWN', 'TC' => 'NWN',
    ];

    public function __construct(array $faecher)
    {
        foreach ($faecher as $f) {
            $id = (int)$f['id'];
            $this->alle[$id] = $f;
            $k = $this->kategorie($f);
            if ($k !== null) $this->kat[$id] = $k;
        }
    }

    private function kategorie(array $f): ?string
    {
        if (array_key_exists('istPruefungsordnungsRelevant', $f) && !$f['istPruefungsordnungsRelevant']) return null;
        if (!empty($f['biliSprache'])) return null;              // bilinguale Sachfächer werden nicht gewählt
        $k = strtoupper((string)$f['kuerzel']);
        if (!empty($f['istFremdsprache']) && preg_match('/^[A-Z][0-9]?$/', $k) && strpos(self::FS_ZEICHEN, $k[0]) !== false)
            return 'FS';
        return self::KAT[$k] ?? null;
    }

    public function kuerzel(int $id): string { return strtoupper((string)$this->alle[$id]['kuerzel']); }
    public function anzeige(int $id): string
    {
        $f = $this->alle[$id];
        return (string)($f['kuerzelAnzeige'] ?? '') !== '' ? (string)$f['kuerzelAnzeige'] : (string)$f['kuerzel'];
    }
    public function moeglich(int $id, int $hj): bool { return !empty($this->alle[$id]['istMoeglich'][$hj]); }
    public function moeglichVonBis(int $id, int $von, int $bis): bool
    {
        for ($h = $von; $h <= $bis; $h++) if (!$this->moeglich($id, $h)) return false;
        return true;
    }
    public function durchgehend(int $id): bool { return $this->moeglichVonBis($id, 0, 5); }
    public function istNeueFS(int $id): bool { return ($this->kat[$id] ?? '') === 'FS' && !empty($this->alle[$id]['istFremdSpracheNeuEinsetzend']); }
    public function sprache(int $id): string { return $this->kuerzel($id)[0]; }
    public function abiLK(int $id): bool { return !empty($this->alle[$id]['istMoeglichAbiLK']); }
    public function abiGK(int $id): bool { return !empty($this->alle[$id]['istMoeglichAbiGK']); }

    /** Schlüssel für "inhaltsgleiche" Fächer: Sprache bzw. Kürzel */
    public function inhalt(int $id): string
    {
        return ($this->kat[$id] ?? '') === 'FS' ? 'FS-' . $this->sprache($id) : $this->kuerzel($id);
    }

    /** @return int[] */
    public function ids(string ...$kategorien): array
    {
        $r = [];
        foreach ($this->kat as $id => $k) if (in_array($k, $kategorien, true)) $r[] = $id;
        return $r;
    }

    /** Aufgabenfeld (1, 2, 3) eines Faches; Religion zählt für die GKL zum AF II */
    public function aufgabenfeld(int $id): int
    {
        switch ($this->kat[$id] ?? '') {
            case 'D': case 'FS': case 'KUMU': case 'LIT': return 1;
            case 'GE': case 'SW': case 'PL': case 'GWS': case 'REL': return 2;
            case 'M': case 'NWK': case 'NWN': return 3;
        }
        return 0;
    }
}

/* =========================================================================
 *  Sprachenfolge des Schülers (Logik wie SprachendatenUtils im SVWS-Core)
 * ========================================================================= */

final class Sprachen
{
    private array $belegungen;
    /** @var array<string,bool> Sprachen mit Sprachprüfung – werden nicht automatisch verplant */
    private array $mitPruefung = [];

    public function __construct(array $schueler)
    {
        $this->belegungen = $schueler['sprachbelegungen'] ?? [];
        foreach ($schueler['sprachpruefungen'] ?? [] as $p) {
            if (!empty($p['sprache'])) $this->mitPruefung[strtoupper((string)$p['sprache'])] = true;
            if (!empty($p['ersetzteSprache'])) $this->mitPruefung[strtoupper((string)$p['ersetzteSprache'])] = true;
        }
    }

    public function hatPruefungen(): bool { return !empty($this->mitPruefung); }

    private static function jg($k): int
    {
        if ($k === null || $k === '') return 0;
        switch ((string)$k) { case 'EF': return 11; case 'Q1': return 12; case 'Q2': return 13; }
        return is_numeric($k) ? (int)$k : 0;
    }

    private static function endetInSekI(array $b): bool
    {
        $bis = $b['belegungBisJahrgang'] ?? null;
        if ($bis === null) return true;
        $n = self::jg($bis);
        if ($n <= 8) return false;
        if (($n === 9 || $n === 10) && (int)($b['belegungBisAbschnitt'] ?? 0) === 1) return false;
        return true;
    }

    private static function dauer(array $b): int
    {
        $von = self::jg($b['belegungVonJahrgang'] ?? null);
        $bis = self::jg($b['belegungBisJahrgang'] ?? null);
        if ($bis === 0 || $bis > 10) $bis = 10;
        return $bis - $von + 1;
    }

    private function belegung(string $sprache): ?array
    {
        foreach ($this->belegungen as $b) if (strtoupper((string)($b['sprache'] ?? '')) === $sprache) return $b;
        return null;
    }

    private function minJahre(string $sprache, int $n): bool
    {
        $b = $this->belegung($sprache);
        if ($b === null || !self::endetInSekI($b)) return false;
        $von = self::jg($b['belegungVonJahrgang'] ?? null);
        return $von > 0 && $von <= 10 && self::dauer($b) >= $n;
    }

    public function fortfuehrbar(string $s): bool { return !isset($this->mitPruefung[$s]) && $this->minJahre($s, 2); }
    public function neuEinsetzbar(string $s): bool { return !isset($this->mitPruefung[$s]) && !$this->minJahre($s, 2); }

    /** @return string[] Sprachen mit Beginn in Jg. $von..$bis und Mindestdauer $n bis Ende Sek I (sortiert nach Beginn) */
    private function fenster(int $von, int $bis, int $n): array
    {
        $r = [];
        foreach ($this->belegungen as $b) {
            if (empty($b['sprache']) || ($b['belegungVonJahrgang'] ?? null) === null || !self::endetInSekI($b)) continue;
            $v = self::jg($b['belegungVonJahrgang']);
            if ($v > 0 && $v >= $von && $v <= $bis && self::dauer($b) >= $n) $r[$v * 100 + count($r)] = strtoupper((string)$b['sprache']);
        }
        ksort($r);
        return array_values($r);
    }

    public function zweiAb5bis7(): bool { return count($this->fenster(5, 7, 4)) >= 2; }
    public function eineAb5bis7(): bool { return count($this->fenster(5, 7, 4)) >= 1; }
    public function eineAb8(): ?string { return $this->fenster(8, 10, 2)[0] ?? null; }
}

/* =========================================================================
 *  Der Generator
 * ========================================================================= */

final class GeneratorFehler extends RuntimeException {}

final class Laufbahn
{
    /** @var array<int,array{k:array,s:array,abi:?int,ref:?int,pflicht:bool}> */
    public array $p = [];

    public function hat(int $id): bool { return isset($this->p[$id]); }

    public function setze(int $id, int $von, int $bis, string $kursart = 'GK', bool $pflicht = true): void
    {
        if (!isset($this->p[$id])) $this->p[$id] = ['k' => array_fill(0, 6, null), 's' => array_fill(0, 6, false), 'abi' => null, 'ref' => null, 'pflicht' => $pflicht];
        for ($h = $von; $h <= $bis; $h++) $this->p[$id]['k'][$h] = $kursart;
        if ($pflicht) $this->p[$id]['pflicht'] = true;
    }

    public function schriftlich(int $id, int $von, int $bis, bool $wert = true): void
    {
        for ($h = $von; $h <= $bis; $h++) if ($this->p[$id]['k'][$h] !== null) $this->p[$id]['s'][$h] = $wert;
    }

    public function belegt(int $id, int $h): bool { return isset($this->p[$id]) && $this->p[$id]['k'][$h] !== null; }
    public function belegtVonBis(int $id, int $von, int $bis): bool
    {
        for ($h = $von; $h <= $bis; $h++) if (!$this->belegt($id, $h)) return false;
        return true;
    }
    public function ende(int $id): int { for ($h = 5; $h >= 0; $h--) if ($this->belegt($id, $h)) return $h; return -1; }

    public function kurseQ(): int
    {
        $n = 0;
        foreach ($this->p as $b) for ($h = 2; $h <= 5; $h++) if ($b['k'][$h] !== null) $n++;
        return $n;
    }
}

final class LaufbahnGenerator
{
    private Faecher $F;
    private array $daten;
    private array $hinweise = [];

    public function __construct(array $daten)
    {
        $this->daten = $daten;
        $this->F = new Faecher($daten['faecher'] ?? []);
    }

    public function faecher(): Faecher { return $this->F; }

    /** @var array{pflicht:int[],verboten:int[]} Vorgaben für die Leistungskurse dieses Schülers */
    private array $lkVorgabe = ['pflicht' => [], 'verboten' => []];
    /** @var array{pflicht:int[],verboten:int[]} Vorgaben für Grundkurse in der Q1 */
    private array $gkVorgabe = ['pflicht' => [], 'verboten' => []];

    /** @var string[] Gründe, warum Lockerungsstufen scheiterten (Diagnose) */
    public array $stufenFehler = [];

    private function gkVerboten(int $id): bool { return in_array($id, $this->gkVorgabe['verboten'], true); }

    /** Fach-IDs zu einem Kürzel (bei Fremdsprachen: fortgeführte Sprache mit diesem Buchstaben) */
    public function idsZuKuerzel(string $k): array
    {
        $F = $this->F;
        $k = strtoupper($k);
        $r = [];
        foreach ($F->kat as $id => $kat) {
            if ($kat === 'FS' && strlen($k) === 1) { if ($F->sprache($id) === $k && !$F->istNeueFS($id)) $r[] = $id; }
            elseif ($F->kuerzel($id) === $k) $r[] = $id;
        }
        return $r;
    }

    /**
     * Erzeugt eine Laufbahn.
     * $vorgabe (Kürzel): ['lkPflicht' => [...], 'lkVerboten' => [...], 'gesperrt' => [...]]
     * Lässt sich die Vorgabe nicht erfüllen, wird ohne sie geplant und ein Hinweis ausgegeben.
     * Liefert ['fachbelegungen' => [...], 'gkl' => [...], 'hinweise' => [...], 'laufbahn' => Laufbahn, 'vorgabeErfuellt' => bool]
     */
    public function erzeuge(array $schueler, array $vorgabe = []): array
    {
        $typen = ['lkPflicht', 'gkPflicht', 'gkVerboten', 'lkVerboten', 'gesperrt'];
        $voll = [];
        foreach ($typen as $t) $voll[$t] = array_values(array_unique($vorgabe[$t] ?? []));
        // Lockerungsstufen: alles -> einzelne Pflichtvorgaben weglassen -> Gruppen weglassen
        // Reihenfolge der Lockerung: einzelne GK-Vorgabe, einzelnes GK-Verbot, einzelne LK-Vorgabe, dann ganze Gruppen
        $stufen = [$voll];
        $einzel = [];
        foreach (Zufall::mischen($voll['gkPflicht']) as $k) $einzel[] = ['gkPflicht', $k];
        foreach (Zufall::mischen($voll['gkVerboten']) as $k) $einzel[] = ['gkVerboten', $k];
        foreach (Zufall::mischen($voll['lkPflicht']) as $k) $einzel[] = ['lkPflicht', $k];
        foreach (array_slice($einzel, 0, 10) as [$t, $k]) { $x = $voll; $x[$t] = array_values(array_diff($x[$t], [$k])); $stufen[] = $x; }
        $x = $voll;
        foreach (['gkPflicht', 'gkVerboten', 'lkPflicht', 'lkVerboten', 'gesperrt'] as $t) { if (!$x[$t]) continue; $x[$t] = []; $stufen[] = $x; }

        foreach ($stufen as $nr => $st) {
            $letzte = $nr === count($stufen) - 1;
            $katOriginal = $this->F->kat;
            try {
                $map = fn(array $l) => array_merge([], ...array_map(fn($k) => $this->idsZuKuerzel($k), $l));
                $pflicht = [];
                foreach ($st['lkPflicht'] as $k) {
                    $ids = $this->idsZuKuerzel($k);
                    if (!$ids) throw new GeneratorFehler("$k wird nicht angeboten.");
                    $pflicht[] = $ids[0];
                }
                $gkPflicht = [];
                foreach ($st['gkPflicht'] as $k) {
                    $ids = $this->idsZuKuerzel($k);
                    if (!$ids) throw new GeneratorFehler("$k wird nicht angeboten.");
                    $gkPflicht[] = Zufall::eins($ids);
                }
                $this->lkVorgabe = ['pflicht' => $pflicht, 'verboten' => $map($st['lkVerboten'])];
                $this->gkVorgabe = ['pflicht' => $gkPflicht, 'verboten' => $map($st['gkVerboten'])];
                foreach ($map($st['gesperrt']) as $id) unset($this->F->kat[$id]);
                $r = $this->erzeugeIntern($schueler);
            } catch (GeneratorFehler $e) {
                $this->stufenFehler[] = $e->getMessage();
                if ($letzte) throw $e;
                continue;
            } finally {
                $this->F->kat = $katOriginal;
                $this->lkVorgabe = ['pflicht' => [], 'verboten' => []];
                $this->gkVorgabe = ['pflicht' => [], 'verboten' => []];
            }
            $text = ['lkPflicht' => '%s-LK', 'gkPflicht' => '%s-GK in Q1', 'gkVerboten' => 'kein %s-GK in Q1', 'lkVerboten' => 'kein %s-LK', 'gesperrt' => 'kein %s'];
            $verfehlt = [];
            foreach ($typen as $t) foreach (array_diff($voll[$t], $st[$t]) as $k) $verfehlt[] = sprintf($text[$t], $k);
            if ($verfehlt) $r['hinweise'][] = 'Voreinstellung nicht erfüllbar: ' . implode(', ', $verfehlt) . '.';
            $r['vorgabeErfuellt'] = !$verfehlt;
            return $r;
        }
        throw new GeneratorFehler('unbekannt');
    }

    private function erzeugeIntern(array $schueler): array
    {
        $sprachen = new Sprachen($schueler);
        $this->hinweise = [];
        if ($sprachen->hatPruefungen())
            $this->hinweise[] = 'Sprachprüfungen vorhanden – diese Sprachen wurden nicht verplant.';

        $letzterFehler = 'unbekannt';
        $fehlerZaehler = [];
        for ($v = 0; $v < LPM_MAX_VERSUCHE; $v++) {
            // die ersten 3/4 der Versuche verlangen 10 Kurse je Q-Halbjahr, danach nur noch 40 insgesamt
            // Stufen: (1) 11 Fächer in der EF + 10 Kurse je Q-Halbjahr, (2) 11 Fächer in der EF, (3) Mindestanforderungen
            $streng = $v < intdiv(LPM_MAX_VERSUCHE, 2);
            $ef11 = $v < intdiv(LPM_MAX_VERSUCHE * 17, 20);
            try {
                $lb = $this->versuch($schueler, $sprachen, $streng, $ef11);
                $gkl = $this->waehleGKL($lb);
                $this->pruefeFachkombinationen($lb);
                $this->pruefeEndkontrolle($lb);
                if (!$ef11) $this->hinweise[] = 'EF mit ' . $this->zaehleEF($lb) . ' statt 11 Fächern (11 war nicht möglich).';
                if (!$streng) $this->hinweise[] = 'Kursverteilung Q1/Q2: ' . implode('/', self::kurseJeHalbjahr($lb)) . ' (10 je Halbjahr war nicht möglich).';
                return ['fachbelegungen' => $this->export($lb), 'gkl' => $gkl, 'hinweise' => $this->hinweise, 'laufbahn' => $lb];
            } catch (GeneratorFehler $e) {
                $letzterFehler = $e->getMessage();
                $fehlerZaehler[$letzterFehler] = ($fehlerZaehler[$letzterFehler] ?? 0) + 1;
            }
        }
        arsort($fehlerZaehler);
        throw new GeneratorFehler((string)array_key_first($fehlerZaehler));
    }

    /* ---------------------------------------------------------------- */

    private function versuch(array $schueler, Sprachen $sp, bool $streng, bool $ef11 = true): Laufbahn
    {
        $F = $this->F;
        $lb = new Laufbahn();

        $einzig = function (string $kat) use ($F): ?int {
            $c = array_values(array_filter($F->ids($kat), fn($id) => $F->durchgehend($id)));
            return Zufall::eins($c);
        };
        $D = $einzig('D');
        $M = $einzig('M');
        $SP = $einzig('SP');
        if ($D === null) throw new GeneratorFehler('Deutsch ist nicht durchgehend wählbar.');
        if ($M === null) throw new GeneratorFehler('Mathematik ist nicht durchgehend wählbar.');
        if ($SP === null) throw new GeneratorFehler('Sport ist nicht durchgehend wählbar.');

        // ---------- Fremdsprachen ----------
        $fsFort = array_values(array_filter($F->ids('FS'), fn($id) => !$F->istNeueFS($id) && $sp->fortfuehrbar($F->sprache($id)) && $F->moeglichVonBis($id, 0, 1)));
        $fsFortDurch = array_values(array_filter($fsFort, fn($id) => $F->durchgehend($id)));
        $fsNeu = array_values(array_filter($F->ids('FS'), fn($id) => $F->istNeueFS($id) && $sp->neuEinsetzbar($F->sprache($id)) && $F->durchgehend($id)));

        // zweite Fremdsprache: was ist nötig?
        $zweiteFS = null;   // null | 'neu' | ['ef' => fachID]
        if (!$sp->zweiAb5bis7()) {
            $optionen = [];
            if ($fsNeu) $optionen[] = 'neu';
            $ab8 = $sp->eineAb5bis7() ? $sp->eineAb8() : null;
            if ($ab8 !== null) foreach ($fsFort as $id) if ($F->sprache($id) === $ab8) $optionen[] = ['ef' => $id];
            if (!$optionen) throw new GeneratorFehler('Die Sprachenfolge erfordert eine neu einsetzende Fremdsprache, die nicht angeboten wird.');
            $zweiteFS = Zufall::eins($optionen);
        }
        $neueFS = null;
        if ($zweiteFS === 'neu') $neueFS = Zufall::eins($fsNeu);

        $fs1Kandidaten = $fsFortDurch;
        if (!$fs1Kandidaten) {
            if (!$fsFort) throw new GeneratorFehler('Keine fortführbare Fremdsprache der Sprachenfolge wird angeboten.');
            if ($neueFS === null) {
                if (!$fsNeu) throw new GeneratorFehler('Keine Fremdsprache kann durchgehend belegt werden.');
                $neueFS = Zufall::eins($fsNeu);
            }
        }

        // ---------- Abiturfächer ----------
        $ausschlussInhalt = function (array $ids) use ($F): bool {
            $s = [];
            foreach ($ids as $id) { $k = $F->inhalt($id); if (isset($s[$k])) return false; $s[$k] = true; }
            return true;
        };
        $abiPool = [];
        foreach ($F->kat as $id => $k) {
            if (!in_array($k, ['D', 'M', 'FS', 'KUMU', 'GE', 'SW', 'PL', 'GWS', 'REL', 'NWK', 'NWN'], true)) continue;
            if (!$F->durchgehend($id)) continue;
            if ($k === 'FS') {
                if ($F->istNeueFS($id)) { if ($id !== $neueFS) continue; }
                elseif (!in_array($id, $fsFortDurch, true)) continue;
            }
            if ($k === 'D' && $id !== $D) continue;
            if ($k === 'M' && $id !== $M) continue;
            $abiPool[] = $id;
        }
        // Sport-LK nur über die Voreinstellung (Sport darf nur 2. LK sein)
        if (in_array($SP, $this->lkVorgabe['pflicht'], true) && $F->abiLK($SP)) $abiPool[] = $SP;
        $lk1Pool = array_values(array_filter($abiPool, fn($id) => $F->abiLK($id) && in_array($F->kat[$id], ['D', 'M', 'FS', 'NWK'], true) && !$F->istNeueFS($id)));
        $lkPool = array_values(array_filter($abiPool, fn($id) => $F->abiLK($id) && !$F->istNeueFS($id)));
        $gkPool = array_values(array_filter($abiPool, fn($id) => $F->abiGK($id) && $F->kat[$id] !== 'SP' && !$this->gkVerboten($id)));
        if (!$lk1Pool) throw new GeneratorFehler('Kein Fach ist als 1. Leistungskurs wählbar (D, M, FS, BI, CH, PH).');

        $pxFaecher = array_values(array_filter($F->ids('PX'), fn($id) => $F->moeglich($id, 4) && $F->moeglich($id, 5)));
        if (!$pxFaecher) throw new GeneratorFehler('Es wird kein Projektkurs in der Q2 angeboten.');

        // Vorgaben für Leistungskurse (Schieberegler)
        $pflicht = $this->lkVorgabe['pflicht'];
        $verboten = $this->lkVorgabe['verboten'];
        foreach ($pflicht as $id) if (!in_array($id, $lkPool, true)) throw new GeneratorFehler('Vorgegebener Leistungskurs ist für diese/n Schüler/in nicht wählbar.');
        $erlaubt1 = array_values(array_filter($lk1Pool, fn($id) => !in_array($id, $verboten, true)));
        $erlaubt = array_values(array_filter($lkPool, fn($id) => !in_array($id, $verboten, true)));
        $waehleLKs = function () use ($pflicht, $erlaubt1, $erlaubt, $lk1Pool): ?array {
            $opt = [];
            if (count($pflicht) === 2) {
                [$a, $b] = $pflicht;
                if (in_array($a, $lk1Pool, true)) $opt[] = [$a, $b];
                if (in_array($b, $lk1Pool, true)) $opt[] = [$b, $a];
                return Zufall::eins($opt);
            }
            if (count($pflicht) === 1) {
                $p = $pflicht[0];
                if (in_array($p, $lk1Pool, true)) { $x = Zufall::eins(array_filter($erlaubt, fn($id) => $id !== $p)); if ($x !== null) $opt[] = [$p, $x]; }
                $x = Zufall::eins(array_filter($erlaubt1, fn($id) => $id !== $p)); if ($x !== null) $opt[] = [$x, $p];
                return Zufall::eins($opt);
            }
            $a = Zufall::eins($erlaubt1);
            $b = $a === null ? null : Zufall::eins(array_filter($erlaubt, fn($id) => $id !== $a));
            return $b === null ? null : [$a, $b];
        };

        $abi = null;
        for ($t = 0; $t < 60 && $abi === null; $t++) {
            $lks = $waehleLKs();
            if ($lks === null) continue;
            [$lk1, $lk2] = $lks;
            $pxAlsAbi5 = Zufall::chance(0.4);
            $anzahlGK = $pxAlsAbi5 ? 2 : 3;
            $gk = array_slice(Zufall::mischen(array_filter($gkPool, fn($id) => $id !== $lk1 && $id !== $lk2)), 0, $anzahlGK);
            if (count($gk) < $anzahlGK) continue;
            $alle = array_merge([$lk1, $lk2], $gk);
            if (!$ausschlussInhalt($alle)) continue;
            // höchstens ein Abiturfach aus Sport und Religionslehre
            if (in_array($SP, $alle, true) && array_filter($alle, fn($id) => $F->kat[$id] === 'REL')) continue;
            // zwei der Fächer D, M, FS (nicht zwei Fremdsprachen)
            $hatD = in_array($D, $alle, true) ? 1 : 0;
            $hatM = in_array($M, $alle, true) ? 1 : 0;
            $anzFS = count(array_filter($alle, fn($id) => $F->kat[$id] === 'FS'));
            if ($hatD + $hatM + min(1, $anzFS) < 2) continue;
            // alle drei Aufgabenfelder (ohne Religion für das AF II – vorsichtig)
            $af = [];
            foreach ($alle as $id) { $a = $F->kat[$id] === 'REL' ? 0 : $F->aufgabenfeld($id); if ($a) $af[$a] = true; }
            if (count($af) < 3) continue;
            if ($anzFS > 0 && count(array_filter($alle, fn($id) => $F->istNeueFS($id))) > 0 && $neueFS === null) continue;
            $abi = ['lk1' => $lk1, 'lk2' => $lk2, 'gk' => $gk, 'pxAbi' => $pxAlsAbi5];
        }
        if ($abi === null) throw new GeneratorFehler('Keine gültige Kombination von Abiturfächern gefunden.');

        // ---------- Grundgerüst ----------
        $lb->setze($D, 0, 5);
        $lb->setze($M, 0, 5);
        if ($abi['lk2'] !== $SP) $lb->setze($SP, 0, 5);
        $lb->setze($abi['lk1'], 0, 5); $lb->setze($abi['lk1'], 2, 5, 'LK'); $lb->p[$abi['lk1']]['abi'] = 1;
        $lb->setze($abi['lk2'], 0, 5); $lb->setze($abi['lk2'], 2, 5, 'LK'); $lb->p[$abi['lk2']]['abi'] = 2;
        foreach ($abi['gk'] as $i => $id) { $lb->setze($id, 0, 5); $lb->p[$id]['abi'] = 3 + $i; }

        // Voreinstellung: Fächer als Grundkurs in der Q1
        foreach ($this->gkVorgabe['pflicht'] as $id) {
            if ($lb->hat($id)) {
                if ($lb->p[$id]['k'][2] !== 'GK') throw new GeneratorFehler('GK-Vorgabe kollidiert mit Leistungskurs.');
                continue;
            }
            if (($F->kat[$id] ?? '') === 'LIT') {
                if (!$F->moeglichVonBis($id, 2, 3)) throw new GeneratorFehler('Literatur ist in der Q1 nicht wählbar.');
                $lb->setze($id, 2, 3);
                continue;
            }
            if (!$F->moeglichVonBis($id, 0, 3)) throw new GeneratorFehler('GK-Vorgabe: Fach in EF/Q1 nicht wählbar.');
            $lb->setze($id, 0, ($F->durchgehend($id) && Zufall::chance(0.6)) ? 5 : 3);
        }

        // Fremdsprache 1 (fortgeführt, durchgehend)
        $fs1 = null;
        foreach ($lb->p as $id => $_) if (in_array($id, $fsFortDurch, true)) { $fs1 = $id; break; }
        if ($fs1 === null && $fsFortDurch) {
            $fs1 = Zufall::eins(array_filter($fsFortDurch, fn($id) => $neueFS === null || $F->sprache($id) !== $F->sprache($neueFS)));
            if ($fs1 === null) throw new GeneratorFehler('Fremdsprachen kollidieren.');
            $lb->setze($fs1, 0, 5);
        }
        if ($fs1 === null) {
            // nur neu einsetzende FS durchgehend + fortgeführte FS in der EF
            $efFS = Zufall::eins($fsFort);
            $lb->setze($efFS, 0, 1);
        }
        if ($neueFS !== null) $lb->setze($neueFS, 0, 5);
        if (is_array($zweiteFS) && !$lb->hat($zweiteFS['ef'])) $lb->setze($zweiteFS['ef'], 0, 1);

        // Naturwissenschaft (klassisch, durchgehend)
        $nwk = null;
        foreach ($lb->p as $id => $_) if (($F->kat[$id] ?? '') === 'NWK' && $lb->belegtVonBis($id, 0, 5)) { $nwk = $id; break; }
        if ($nwk === null) {
            // vorhandenes Fach verlängern oder neues (erlaubtes) Fach wählen
            $nwk = Zufall::eins(array_filter($F->ids('NWK'), fn($id) => $F->durchgehend($id)
                && ($lb->hat($id) ? $lb->p[$id]['k'][2] === 'GK' : !$this->gkVerboten($id))));
            if ($nwk === null) throw new GeneratorFehler('Keine Naturwissenschaft (BI, CH, PH) ist durchgehend wählbar.');
            $lb->setze($nwk, 0, 5);
        }

        // Religion bzw. Philosophie als Ersatz
        $rel = null;
        foreach ($lb->p as $id => $_) if (($F->kat[$id] ?? '') === 'REL') { $rel = $id; break; }
        if ($rel === null) {
            $rel = Zufall::eins(array_filter($F->ids('REL'), fn($id) => $F->moeglichVonBis($id, 0, 3)));
            if ($rel !== null) $lb->setze($rel, 0, 3);
        }

        // Gesellschaftswissenschaft durchgehend
        $gwDurch = null;
        foreach ($lb->p as $id => $_) if (in_array($F->kat[$id] ?? '', ['GE', 'SW', 'GWS', 'PL'], true) && $lb->belegtVonBis($id, 0, 5)) {
            if ($F->kat[$id] === 'PL' && $rel === null) continue;
            $gwDurch = $id; break;
        }
        if ($gwDurch === null) {
            $kand = array_filter($F->ids('GE', 'SW', 'GWS', 'PL'), fn($id) => $F->durchgehend($id) && !($F->kat[$id] === 'PL' && $rel === null)
                && ($lb->hat($id) ? ($lb->p[$id]['k'][2] === 'GK' && !in_array('ZK', $lb->p[$id]['k'], true)) : !$this->gkVerboten($id)));
            $gwDurch = Zufall::eins($kand);
            if ($gwDurch === null) throw new GeneratorFehler('Keine Gesellschaftswissenschaft ist durchgehend wählbar.');
            $lb->setze($gwDurch, 0, 5);
        }
        if ($rel === null) {
            $pl = Zufall::eins(array_filter($F->ids('PL'), fn($id) => $F->moeglichVonBis($id, 0, 3) && $id !== $gwDurch));
            if ($pl === null) throw new GeneratorFehler('Weder Religionslehre noch Philosophie (EF.1–Q1.2) wählbar.');
            if (!$lb->hat($pl)) $lb->setze($pl, 0, 3);
            $rel = $pl;
        }

        // Geschichte und Sozialwissenschaften (bis Q1.2 oder Zusatzkurs)
        foreach (['GE', 'SW'] as $kat) {
            $vorhanden = null;
            foreach ($lb->p as $id => $_) if (($F->kat[$id] ?? '') === $kat) { $vorhanden = $id; break; }
            if ($vorhanden !== null) continue;
            $id = Zufall::eins(array_filter($F->ids($kat), fn($i) => $F->moeglichVonBis($i, 0, 1)));
            if ($id === null) throw new GeneratorFehler(($kat === 'GE' ? 'Geschichte' : 'Sozialwissenschaften') . ' ist nicht wählbar.');
            $zk = $this->zusatzkursBeginn($kat);
            $zkMoeglich = $zk !== null && $F->moeglich($id, $zk) && $F->moeglich($id, $zk + 1);
            $q1Moeglich = $F->moeglichVonBis($id, 0, 3) && !$this->gkVerboten($id);
            if ($zkMoeglich && (!$q1Moeglich || Zufall::chance(0.3))) {
                $lb->setze($id, 0, 1);
                $lb->setze($id, $zk, $zk + 1, 'ZK');
            } elseif ($q1Moeglich) {
                $lb->setze($id, 0, 3);
            } else {
                throw new GeneratorFehler(($kat === 'GE' ? 'Geschichte' : 'Sozialwissenschaften') . ' kann weder bis Q1.2 noch als Zusatzkurs belegt werden.');
            }
        }

        // Kunst oder Musik bis Q1.2
        $kumu = null;
        foreach ($lb->p as $id => $_) if (($F->kat[$id] ?? '') === 'KUMU') { $kumu = $id; break; }
        if ($kumu === null) {
            $kumu = Zufall::eins(array_filter($F->ids('KUMU'), fn($id) => $F->moeglichVonBis($id, 0, 3)));
            if ($kumu === null) throw new GeneratorFehler('Weder Kunst noch Musik ist bis Q1.2 wählbar.');
            $lb->setze($kumu, 0, 3);
        }

        // Schwerpunkt: zwei durchgehende Fremdsprachen oder zwei durchgehende Naturwissenschaften
        $fsDurch = array_filter(array_keys($lb->p), fn($id) => ($F->kat[$id] ?? '') === 'FS' && $lb->belegtVonBis($id, 0, 5));
        $nwDurch = array_filter(array_keys($lb->p), fn($id) => in_array($F->kat[$id] ?? '', ['NWK', 'NWN'], true) && $lb->belegtVonBis($id, 0, 5));
        if (count($nwDurch) < 2 && (count($fsDurch) < 2 || Zufall::chance(0.35))) {
            $kand = array_filter($F->ids('NWK', 'NWN'), fn($id) => $F->durchgehend($id) && !in_array($id, $nwDurch, true)
                && ($lb->hat($id) ? $lb->p[$id]['k'][2] === 'GK' : !$this->gkVerboten($id)));
            // Alternative: zweite fortgeführte Fremdsprache durchgehend
            $sprachen = array_map(fn($id) => $F->sprache($id), $fsDurch);
            $fs2 = array_filter($fsFortDurch, fn($id) => !$lb->hat($id) && !in_array($F->sprache($id), $sprachen, true));
            $nw2 = Zufall::eins($kand);
            if (count($fsDurch) === 1 && $fs2 && ($nw2 === null || Zufall::chance(0.15))) $lb->setze(Zufall::eins($fs2), 0, 5);
            elseif ($nw2 !== null) $lb->setze($nw2, 0, 5);
            elseif (count($fsDurch) < 2) throw new GeneratorFehler('Schwerpunkt (2 NW oder 2 FS durchgehend) nicht erfüllbar.');
        }

        // ---------- Sport als Abiturfach: genug nicht einzubringende Kurse sicherstellen ----------
        if ($lb->hat($SP) && $lb->p[$SP]['abi'] !== null) {
            $rel = null; $kml = null;
            foreach ($lb->p as $id => $b) {
                $kat = $F->kat[$id] ?? '';
                if ($b['abi'] !== null || $lb->ende($id) !== 3 || !$F->moeglichVonBis($id, 4, 5)) continue;
                if ($kat === 'REL') $rel = $id;
                if ($kat === 'KUMU') $kml = $id;
            }
            $vxF = Zufall::eins(array_filter($F->ids('VX'), fn($id) => $F->moeglichVonBis($id, 2, 5)));
            $li = Zufall::eins(array_filter($F->ids('LIT'), fn($id) => $F->moeglichVonBis($id, 2, 3) && !$this->gkVerboten($id) && !$lb->hat($id)));
            // Bausteine mit je 2 nicht einzubringenden Kursen
            $bausteine = [];
            if ($rel !== null) $bausteine['rel'] = fn() => $lb->setze($rel, 4, 5);
            if ($kml !== null) $bausteine['kml'] = fn() => $lb->setze($kml, 4, 5);
            if ($li !== null) $bausteine['li'] = fn() => $lb->setze($li, 2, 3);
            if ($vxF !== null) { $bausteine['vx1'] = fn() => $lb->setze($vxF, 2, 3, 'VTF'); $bausteine['vx2'] = fn() => $lb->setze($vxF, 4, 5, 'VTF'); }
            foreach (array_slice(Zufall::mischen(array_keys($bausteine)), 0, 2) as $k) ($bausteine[$k])();
        }

        // ---------- Projektkurs in Q2 ----------
        $this->waehleProjektkurs($lb, $abi['pxAbi'], $pxFaecher);

        // ---------- Schriftlichkeit ----------
        $this->setzeSchriftlichkeit($lb, $gwDurch, $nwk);

        // ---------- 40 Kurse in der Q-Phase (möglichst 10 je Halbjahr) ----------
        $this->gleicheKurszahlAus($lb, $streng);

        // ---------- mind. 10 Fächer in EF.1 und EF.2 ----------
        $this->fuelleEF($lb, $ef11);

        if ($lb->hat($SP) && $lb->p[$SP]['abi'] !== null && $this->sichereReduktion($lb) < 4)
            throw new GeneratorFehler('Sport als Abiturfach: zu wenige frei einbringbare Kurse.');

        return $lb;
    }

    /**
     * Untere Abschätzung, um wie viele Kurse die Obergrenze der Pflichteinbringung unter 40 liegt
     * (Vertiefungskurse, Religion über 2 Kurse hinaus, Kunst/Musik/Literatur über 2 Kurse hinaus).
     */
    private function sichereReduktion(Laufbahn $lb): int
    {
        $F = $this->F;
        $vx = 0; $rel = 0; $relAbi = false; $kml = 0; $kmlAbi = false;
        foreach ($lb->p as $id => $b) {
            $n = 0; for ($h = 2; $h <= 5; $h++) if ($b['k'][$h] !== null) $n++;
            switch ($F->kat[$id] ?? '') {
                case 'VX': $vx += $n; break;
                case 'REL': $rel += $n; $relAbi = $relAbi || $b['abi'] !== null; break;
                case 'KUMU': case 'LIT': $kml += $n; $kmlAbi = $kmlAbi || $b['abi'] !== null; break;
            }
        }
        return $vx + ($relAbi ? 0 : max(0, $rel - 2)) + ($kmlAbi ? 0 : max(0, $kml - 2));
    }

    private function zusatzkursBeginn(string $kat): ?int
    {
        $d = $this->daten;
        $hat = $kat === 'GE' ? ($d['hatZusatzkursGE'] ?? false) : ($d['hatZusatzkursSW'] ?? false);
        $beginn = $kat === 'GE' ? ($d['beginnZusatzkursGE'] ?? null) : ($d['beginnZusatzkursSW'] ?? null);
        if (!$hat || $beginn === null) return null;
        $i = array_search((string)$beginn, HJ_NAMEN, true);
        return ($i === false || $i < 2 || $i > 4) ? null : (int)$i;
    }

    private function waehleProjektkurs(Laufbahn $lb, bool $alsAbi5, array $pxFaecher): void
    {
        $F = $this->F;
        $optionen = [];
        foreach ($pxFaecher as $px) {
            $f = $F->alle[$px];
            foreach ([$f['referenzfach1ID'] ?? null, $f['referenzfach2ID'] ?? null] as $ref) {
                if ($ref === null) continue;
                $ref = (int)$ref;
                if (!isset($F->kat[$ref]) || in_array($F->kat[$ref], ['PX', 'VX', 'LIT', 'SP'], true)) continue;
                if (!$lb->belegtVonBis($ref, 0, 3)) continue;
                if ($alsAbi5 && $lb->p[$ref]['abi'] !== null) continue;
                $optionen[] = [$px, $ref];
            }
        }
        if (!$optionen && $alsAbi5) { $this->waehleProjektkurs($lb, false, $pxFaecher); $this->ergaenzeAbi5GK($lb); return; }
        if (!$optionen) throw new GeneratorFehler('Kein Projektkurs passt zu den gewählten Referenzfächern.');
        [$px, $ref] = Zufall::eins($optionen);
        $lb->setze($px, 4, 5, 'PJK');
        $lb->p[$px]['ref'] = $ref;
        $lb->p[$px]['refFach'] = $ref;
        if ($alsAbi5) $lb->p[$px]['abi'] = 5;
    }

    /** Falls der Projektkurs doch nicht 5. Abiturfach werden kann: ein weiteres Grundkurs-Abiturfach ergänzen */
    private function ergaenzeAbi5GK(Laufbahn $lb): void
    {
        $F = $this->F;
        $inhalte = [];
        foreach ($lb->p as $id => $b) if ($b['abi'] !== null) $inhalte[$F->inhalt($id)] = true;
        $kand = array_filter(array_keys($F->kat), fn($id) => in_array($F->kat[$id], ['KUMU', 'GE', 'SW', 'PL', 'GWS', 'NWK', 'NWN'], true)
            && $F->durchgehend($id) && $F->abiGK($id) && !isset($inhalte[$F->inhalt($id)]) && (!$lb->hat($id) || $lb->belegtVonBis($id, 0, 5))
            && ($lb->hat($id) || !$this->gkVerboten($id)));
        $id = Zufall::eins($kand);
        if ($id === null) throw new GeneratorFehler('Kein 5. Abiturfach gefunden.');
        $lb->setze($id, 0, 5);
        $lb->p[$id]['abi'] = 5;
    }

    private function setzeSchriftlichkeit(Laufbahn $lb, int $gwDurch, int $nwk): void
    {
        $F = $this->F;
        foreach ($lb->p as $id => &$b) { $b['s'] = array_fill(0, 6, false); }
        unset($b);
        foreach ($lb->p as $id => $b) {
            $kat = $F->kat[$id] ?? '';
            // Einführungsphase
            if (in_array($kat, ['D', 'M', 'FS'], true)) $lb->schriftlich($id, 0, 1);
            // Qualifikationsphase
            $abi = $b['abi'];
            if ($kat === 'PX') continue;
            if ($abi === 1 || $abi === 2 || $abi === 3) $lb->schriftlich($id, 2, 5);
            elseif ($abi === 4 || $abi === 5) $lb->schriftlich($id, 2, 4);
            elseif (in_array($kat, ['D', 'M'], true) || $F->istNeueFS($id)) $lb->schriftlich($id, 2, 4);
            if ($F->istNeueFS($id)) $lb->schriftlich($id, 0, 4);
        }
        // eine Naturwissenschaft und eine Gesellschaftswissenschaft schriftlich in der EF
        $lb->schriftlich($nwk, 0, 1);
        $lb->schriftlich($gwDurch, 0, 1);
        // Naturwissenschaft durchgehend schriftlich (für den Schwerpunkt)
        $lb->schriftlich($nwk, 2, 4);
        // eine durchgehende Fremdsprache bis Q2.1 schriftlich; bei zwei durchgehenden FS beide
        foreach ($lb->p as $id => $b) if (($F->kat[$id] ?? '') === 'FS' && $lb->belegtVonBis($id, 0, 5)) $lb->schriftlich($id, 2, 4);
        // GW oder Religion schriftlich Q1.1–Q2.1
        $gwOk = false;
        foreach ($lb->p as $id => $b) {
            if (in_array($F->kat[$id] ?? '', ['GE', 'SW', 'PL', 'GWS', 'REL'], true) && $b['abi'] !== null && $b['abi'] <= 5 && ($F->kat[$id] ?? '') !== 'PX') $gwOk = true;
        }
        if (!$gwOk) $lb->schriftlich($gwDurch, 2, 4);
        // Referenzfach des Projektkurses schriftlich in der Q1
        foreach ($lb->p as $id => $b) if (($F->kat[$id] ?? '') === 'PX' && $b['ref'] !== null) $lb->schriftlich((int)$b['ref'], 2, 3);
        // Zufällig: weitere Fächer schriftlich in der EF (nur Grundkurse ohne Sonderrolle)
        foreach ($lb->p as $id => $b) {
            $kat = $F->kat[$id] ?? '';
            if (in_array($kat, ['SP', 'PX', 'VX', 'LIT'], true)) continue;
            if (Zufall::chance(0.25)) $lb->schriftlich($id, 0, 1);
        }
        // Q2.2: alle Nicht-Abiturfächer mündlich
        foreach ($lb->p as $id => $b) if ($b['abi'] === null || $b['abi'] >= 4) $lb->schriftlich($id, 5, 5, false);
        foreach ($lb->p as $id => $b) if ($b['abi'] === 3 || $b['abi'] === 1 || $b['abi'] === 2) $lb->schriftlich($id, 5, 5, true);
    }

    /** Anzahl der Kurse je Q-Halbjahr (Index 0..3 = Q1.1..Q2.2) */
    private static function kurseJeHalbjahr(Laufbahn $lb): array
    {
        $c = [0, 0, 0, 0];
        foreach ($lb->p as $b) for ($h = 2; $h <= 5; $h++) if ($b['k'][$h] !== null) $c[$h - 2]++;
        return $c;
    }

    /**
     * Gleicht die Kurszahl der Q-Phase aus: genau 40 Kurse; bei $streng zusätzlich
     * genau 10 Kurse in jedem Halbjahr der Q1 und Q2.
     */
    private function gleicheKurszahlAus(Laufbahn $lb, bool $streng): void
    {
        $F = $this->F;
        $vx = Zufall::eins($F->ids('VX'));
        $abstand = function (array $c) use ($streng): int {
            if (!$streng) return abs(array_sum($c) - 40);
            $d = 0; foreach ($c as $x) $d += abs($x - 10); return $d;
        };
        for ($i = 0; $i < 80; $i++) {
            $c = self::kurseJeHalbjahr($lb);
            $d0 = $abstand($c);
            if ($d0 === 0) return;
            $aktionen = [];   // je Eintrag: [Änderung je Halbjahr, Funktion]
            // Fach, das nach Q1.2 endet, bis Q2.2 verlängern
            foreach ($lb->p as $id => $b) {
                $kat = $F->kat[$id] ?? '';
                if (in_array($kat, ['PX', 'VX', 'LIT'], true) || in_array('ZK', $b['k'], true)) continue;
                if ($lb->ende($id) === 3 && $F->moeglichVonBis($id, 4, 5)) $aktionen[] = [[0, 0, 1, 1], fn() => $lb->setze($id, 4, 5, 'GK', false)];
            }
            // neues Fach ab EF.1 (bis Q1.2 bzw. bis Q2.2)
            foreach (array_keys($F->kat) as $id) {
                if ($lb->hat($id) || !$this->darfZusaetzlich($lb, $id) || $this->gkVerboten($id)) continue;
                if ($F->moeglichVonBis($id, 0, 3)) $aktionen[] = [[1, 1, 0, 0], fn() => $lb->setze($id, 0, 3, 'GK', false)];
                if ($F->durchgehend($id)) $aktionen[] = [[1, 1, 1, 1], fn() => $lb->setze($id, 0, 5, 'GK', false)];
            }
            // Geschichte/Sozialwissenschaften: Q1-Grundkurs durch Zusatzkurs ersetzen
            foreach ($lb->p as $id => $b) {
                $kat = $F->kat[$id] ?? '';
                if (!in_array($kat, ['GE', 'SW'], true) || $b['abi'] !== null || $lb->ende($id) !== 3 || $b['k'][2] !== 'GK') continue;
                if (in_array($id, $this->gkVorgabe['pflicht'], true)) continue;
                $istRef = false;
                foreach ($lb->p as $b2) if (($b2['ref'] ?? null) === $id) $istRef = true;
                if ($istRef) continue;
                $zk = $this->zusatzkursBeginn($kat);
                if ($zk === null || !$F->moeglich($id, $zk) || !$F->moeglich($id, $zk + 1)) continue;
                $delta = [-1, -1, 0, 0]; $delta[$zk - 2]++; $delta[$zk - 1]++;
                $aktionen[] = [$delta, function () use ($lb, $id, $zk) {
                    $lb->p[$id]['k'][2] = $lb->p[$id]['k'][3] = null;
                    $lb->p[$id]['s'][2] = $lb->p[$id]['s'][3] = false;
                    $lb->setze($id, $zk, $zk + 1, 'ZK');
                }];
            }
            // umgekehrt: Zusatzkurs durch Grundkurs in der Q1 ersetzen
            foreach ($lb->p as $id => $b) {
                if (!in_array('ZK', $b['k'], true) || $this->gkVerboten($id) || !$lb->belegtVonBis($id, 0, 1) || !$F->moeglichVonBis($id, 2, 3)) continue;
                $delta = [1, 1, 0, 0];
                for ($h = 2; $h <= 5; $h++) if ($b['k'][$h] === 'ZK') $delta[$h - 2]--;
                $aktionen[] = [$delta, function () use ($lb, $id) {
                    for ($h = 2; $h <= 5; $h++) if ($lb->p[$id]['k'][$h] === 'ZK') { $lb->p[$id]['k'][$h] = null; $lb->p[$id]['s'][$h] = false; }
                    $lb->setze($id, 2, 3);
                }];
            }
            // Literatur in zwei aufeinanderfolgenden Halbjahren
            foreach ($F->ids('LIT') as $id) {
                if ($lb->hat($id)) continue;
                if ($F->moeglichVonBis($id, 2, 3) && !$this->gkVerboten($id)) $aktionen[] = [[1, 1, 0, 0], fn() => $lb->setze($id, 2, 3, 'GK', false)];
                if ($F->moeglichVonBis($id, 4, 5)) $aktionen[] = [[0, 0, 1, 1], fn() => $lb->setze($id, 4, 5, 'GK', false)];
            }
            // Vertiefungskurs in einem Halbjahr (max. 4)
            if ($vx !== null) {
                $anz = $lb->hat($vx) ? count(array_filter($lb->p[$vx]['k'], fn($k) => $k !== null)) : 0;
                if ($anz < 4) for ($h = 2; $h <= 5; $h++) if ($F->moeglich($vx, $h) && !$lb->belegt($vx, $h)) {
                    $delta = [0, 0, 0, 0]; $delta[$h - 2] = 1;
                    $aktionen[] = [$delta, fn() => $lb->setze($vx, $h, $h, 'VTF', false)];
                }
            }
            // freiwillige Belegungen zurücknehmen
            foreach ($lb->p as $id => $b) {
                if ($b['pflicht']) continue;
                $kat = $F->kat[$id] ?? '';
                if ($kat === 'VX') {
                    for ($h = 2; $h <= 5; $h++) if ($lb->belegt($id, $h)) {
                        $delta = [0, 0, 0, 0]; $delta[$h - 2] = -1;
                        $aktionen[] = [$delta, function () use ($lb, $id, $h) { $lb->p[$id]['k'][$h] = null; }];
                    }
                    continue;
                }
                if ($kat === 'LIT') { $aktionen[] = [$lb->belegt($id, 2) ? [-1, -1, 0, 0] : [0, 0, -1, -1], function () use ($lb, $id) { unset($lb->p[$id]); }]; continue; }
                if ($lb->ende($id) === 5 && $lb->belegt($id, 2)) $aktionen[] = [[0, 0, -1, -1], function () use ($lb, $id) { $lb->p[$id]['k'][4] = $lb->p[$id]['k'][5] = null; }];
                elseif ($lb->ende($id) === 3 && $lb->belegt($id, 2)) $aktionen[] = [[-1, -1, 0, 0], function () use ($lb, $id) { $lb->p[$id]['k'][2] = $lb->p[$id]['k'][3] = null; }];
            }
            // nur Aktionen, die dem Ziel näher kommen
            $gut = [];
            foreach ($aktionen as [$delta, $fn]) {
                $neuC = $c; foreach ($delta as $j => $x) $neuC[$j] += $x;
                if ($abstand($neuC) < $d0) $gut[] = $fn;
            }
            if (!$gut) break;
            (Zufall::eins($gut))();
            if ($vx !== null && $lb->hat($vx) && !array_filter($lb->p[$vx]['k'])) unset($lb->p[$vx]);
        }
        throw new GeneratorFehler($streng ? 'Je Halbjahr 10 Kurse in der Q-Phase nicht erreichbar.' : 'Die Kurszahl 40 in der Q-Phase konnte nicht erreicht werden.');
    }

    /** darf das Fach als freiwilliges Zusatzfach ab EF.1 ergänzt werden? */
    private function darfZusaetzlich(Laufbahn $lb, int $id): bool
    {
        $F = $this->F;
        $kat = $F->kat[$id] ?? '';
        if (in_array($kat, ['PX', 'VX', 'LIT', 'SP', 'D', 'M'], true)) return false;
        if ($kat === 'FS' && $F->istNeueFS($id)) return false;
        if ($kat === 'FS') {
            // nur fortführbare Sprachen, keine zweite Belegung derselben Sprache
            return false; // Fremdsprachen werden bewusst nicht zusätzlich gewählt (Sprachenfolge)
        }
        if (in_array($kat, ['GE', 'SW', 'REL'], true)) {
            foreach ($lb->p as $j => $_) if (($F->kat[$j] ?? '') === $kat) return false;   // max. eine Belegung je Fach/Religion
        }
        foreach ($lb->p as $j => $_) if ($F->inhalt($j) === $F->inhalt($id)) return false;
        return true;
    }

    /** Anzahl der Fächer in der EF (das kleinere von EF.1 und EF.2, ohne Vertiefungskurse) */
    private function zaehleEF(Laufbahn $lb): int
    {
        $c = [0, 0];
        foreach ($lb->p as $id => $b) for ($h = 0; $h <= 1; $h++) if ($b['k'][$h] !== null && ($this->F->kat[$id] ?? '') !== 'VX') $c[$h]++;
        return min($c);
    }

    /**
     * EF auffüllen: genau 11 Fächer in EF.1 und EF.2 (Spielraum für die Blockung);
     * falls das nicht geht ($ef11 = false), mindestens 10.
     */
    private function fuelleEF(Laufbahn $lb, bool $ef11 = true): void
    {
        $F = $this->F;
        $anzahl = function (int $h) use ($lb, $F): int {
            $n = 0;
            foreach ($lb->p as $id => $b) if ($b['k'][$h] !== null && ($F->kat[$id] ?? '') !== 'VX') $n++;
            return $n;
        };
        // zu viele: (1) freiwillige, nur in der EF belegte Fächer streichen,
        //           (2) bei reinen Zusatzkursen GE/SW die EF-Belegung streichen (Zusatzkurs ersetzt GE/SW in EF/Q1)
        foreach ([1, 2] as $durchgang) foreach (Zufall::mischen(array_keys($lb->p)) as $id) {
            if (max($anzahl(0), $anzahl(1)) <= 11) break 2;
            $b = $lb->p[$id];
            if ($durchgang === 1 && !$b['pflicht'] && $lb->ende($id) <= 1) unset($lb->p[$id]);
            if ($durchgang === 2 && in_array('ZK', $b['k'], true) && $b['k'][2] === null && $b['k'][3] === null && $b['k'][0] !== null) {
                $lb->p[$id]['k'][0] = $lb->p[$id]['k'][1] = null;
                $lb->p[$id]['s'][0] = $lb->p[$id]['s'][1] = false;
            }
        }
        // zu wenige: Fächer nur für die EF ergänzen
        for ($i = 0; $i < 12 && min($anzahl(0), $anzahl(1)) < 11; $i++) {
            $kand = array_filter(array_keys($F->kat), fn($id) => !$lb->hat($id) && $F->moeglichVonBis($id, 0, 1) && $this->darfZusaetzlich($lb, $id));
            $id = Zufall::eins($kand);
            if ($id === null) break;
            $lb->setze($id, 0, 1, 'GK', false);
            if (Zufall::chance(0.3)) $lb->schriftlich($id, 0, 1);
        }
        if ($ef11 && ($anzahl(0) !== 11 || $anzahl(1) !== 11)) throw new GeneratorFehler('In der EF können nicht genau 11 Fächer belegt werden.');
        if (min($anzahl(0), $anzahl(1)) < 10) throw new GeneratorFehler('In der EF können nicht 10 Fächer belegt werden.');
    }

    /* ---------------------------------------------------------------- */

    private function waehleGKL(Laufbahn $lb): array
    {
        $F = $this->F;
        $vorgaben = $this->daten['gkl'] ?? [];
        $gkl = array_fill(0, 6, null);
        foreach ([1, 2, 3] as $af) {
            // Einführungsphase
            $pflicht = false;
            foreach ($lb->p as $id => $b) {
                if ($F->aufgabenfeld($id) !== $af) continue;
                for ($h = 0; $h <= 1; $h++) if ($b['k'][$h] === 'GK' && $b['s'][$h]) $pflicht = true;
            }
            if ($pflicht) {
                $kand = array_filter($vorgaben, fn($v) => (int)$v['idHalbjahr'] <= 1 && $this->passtGKL($lb, $v, $af));
                $wahl = Zufall::eins($kand);
                if ($wahl === null) {
                    $vorhanden = array_filter($vorgaben, fn($v) => (int)$v['idHalbjahr'] <= 1 && isset($F->alle[(int)$v['idFach']]) && $F->aufgabenfeld((int)$v['idFach']) === $af);
                    throw new GeneratorFehler($vorhanden
                        ? "Kein passender gleichwertiger Leistungsnachweis (GKL) in der EF für Aufgabenfeld $af."
                        : "Für die EF sind im Aufgabenfeld $af keine GKL-Vorgaben in der Datei definiert.");
                }
                $gkl[$af - 1] = (int)$wahl['id'];
            }
            // Qualifikationsphase (nur nötig, wenn ein schriftlicher GK mit möglicher GKL existiert)
            $kand = array_filter($vorgaben, fn($v) => in_array((int)$v['idHalbjahr'], [2, 3, 4], true) && $this->passtGKL($lb, $v, $af));
            if ($kand) $gkl[2 + $af] = (int)Zufall::eins($kand)['id'];
        }
        return $gkl;
    }

    private function passtGKL(Laufbahn $lb, array $v, int $af): bool
    {
        $fid = (int)$v['idFach'];
        $h = (int)$v['idHalbjahr'];
        if (!isset($this->F->kat[$fid]) || $this->F->aufgabenfeld($fid) !== $af || !$lb->hat($fid)) return false;
        return $lb->p[$fid]['k'][$h] === 'GK' && $lb->p[$fid]['s'][$h];
    }

    private function pruefeFachkombinationen(Laufbahn $lb): void
    {
        foreach ($this->daten['fachkombinationen'] ?? [] as $k) {
            $f1 = (int)$k['fachID1']; $f2 = (int)$k['fachID2'];
            for ($h = 0; $h <= 5; $h++) {
                if (empty($k['gueltigInHalbjahr'][$h])) continue;
                $b1 = $lb->belegt($f1, $h) && ($k['kursart1'] === null || $k['kursart1'] === '' || $lb->p[$f1]['k'][$h] === $k['kursart1']);
                if (!$b1) continue;
                $b2 = $lb->belegt($f2, $h) && ($k['kursart2'] === null || $k['kursart2'] === '' || $lb->p[$f2]['k'][$h] === $k['kursart2']);
                if ((int)$k['typ'] === 0 && $b2) throw new GeneratorFehler('Unzulässige Fächerkombination: ' . ($k['hinweistext'] ?? ''));
                if ((int)$k['typ'] === 1 && !$b2) throw new GeneratorFehler('Geforderte Fächerkombination fehlt: ' . ($k['hinweistext'] ?? ''));
            }
        }
    }

    /** Abschließende Plausibilitätskontrolle zentraler Zählregeln */
    private function pruefeEndkontrolle(Laufbahn $lb): void
    {
        if ($lb->kurseQ() !== 40) throw new GeneratorFehler('Kurszahl ungleich 40.');
        $abi = [];
        foreach ($lb->p as $id => $b) if ($b['abi'] !== null) $abi[] = $b['abi'];
        sort($abi);
        if ($abi !== [1, 2, 3, 4, 5]) throw new GeneratorFehler('Abiturfächer unvollständig.');
        foreach ($this->gkVorgabe['pflicht'] as $id)
            if (!$lb->hat($id) || $lb->p[$id]['k'][2] !== 'GK' || $lb->p[$id]['k'][3] !== 'GK') throw new GeneratorFehler('GK-Vorgabe nicht erfüllt.');
        foreach ($this->gkVorgabe['verboten'] as $id)
            if ($lb->hat($id) && ($lb->p[$id]['k'][2] === 'GK' || $lb->p[$id]['k'][3] === 'GK')) throw new GeneratorFehler('GK-Verbot nicht eingehalten.');
        foreach ($this->lkVorgabe['pflicht'] as $id)
            if (!$lb->hat($id) || $lb->p[$id]['k'][2] !== 'LK') throw new GeneratorFehler('LK-Vorgabe nicht erfüllt.');
        foreach ($lb->p as $id => $b) for ($h = 0; $h <= 5; $h++)
            if ($b['k'][$h] !== null && !$this->F->moeglich($id, $h)) throw new GeneratorFehler('Fach in einem Halbjahr nicht wählbar.');
    }

    private function export(Laufbahn $lb): array
    {
        $F = $this->F;
        $ids = array_keys($lb->p);
        usort($ids, fn($a, $b) => ((int)($F->alle[$a]['sortierung'] ?? 32000) <=> (int)($F->alle[$b]['sortierung'] ?? 32000)) ?: $a <=> $b);
        $r = [];
        foreach ($ids as $id) {
            $b = $lb->p[$id];
            if (!array_filter($b['k'])) continue;
            $s = [];
            for ($h = 0; $h <= 5; $h++) $s[$h] = $b['k'][$h] !== null && $b['s'][$h];
            $r[] = [
                'fachID'         => $id,
                'abiturFach'     => $b['abi'],
                'kursart'        => $b['k'],
                'schriftlich'    => $s,
                'idReferenzfach' => $b['ref'],
            ];
        }
        return $r;
    }
}

/* =========================================================================
 *  Datei-Verarbeitung
 * ========================================================================= */

function lp_lesen(string $roh): array
{
    $json = @gzdecode($roh);
    if ($json === false) $json = $roh;                      // evtl. unkomprimiert
    $daten = json_decode($json, true);
    if (!is_array($daten)) throw new GeneratorFehler('Die Datei ist keine gültige Laufbahnplanungsdatei (gzip/JSON).');
    return $daten;
}

function lp_schreiben(array $daten): string
{
    $json = json_encode($daten, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
    if ($json === false) throw new GeneratorFehler('JSON-Fehler beim Schreiben.');
    return gzencode($json, 9);
}

/**
 * Füllt eine .lp-Datei. Liefert ['inhalt' => string|null, 'status' => ok|uebersprungen|fehler, 'meldung' => ..., ...]
 */
function lp_fuellen(string $roh, bool $ueberschreiben, array $vorgabe = []): array
{
    $daten = lp_lesen($roh);
    $rev = (int)($daten['lpRevision'] ?? 0);
    if ($rev !== 2) throw new GeneratorFehler("Nicht unterstützte LP-Revision ($rev). Bitte die Dateien mit einer aktuellen SVWS-Version exportieren.");
    if ((int)($daten['abiturjahr'] ?? 0) < 2030) throw new GeneratorFehler('Abiturjahrgang ' . ($daten['abiturjahr'] ?? '?') . ' – unterstützt wird die APO-GOSt ab Abitur 2030.');
    if (empty($daten['schueler'][0])) throw new GeneratorFehler('Die Datei enthält keinen Schüler.');

    $s = &$daten['schueler'][0];
    $info = [
        'name'   => trim(($s['nachname'] ?? '') . ', ' . ($s['vorname'] ?? ''), ', '),
        'abijahr' => (int)$daten['abiturjahr'],
    ];
    if (in_array(true, $s['bewertetesHalbjahr'] ?? [], true))
        return $info + ['status' => 'uebersprungen', 'meldung' => 'Es liegen bereits bewertete Halbjahre vor.'];
    if (!empty($s['bilingualeSprache']))
        return $info + ['status' => 'uebersprungen', 'meldung' => 'Bilingualer Bildungsgang wird nicht automatisch geplant.'];
    $hatWahlen = false;
    foreach ($s['fachbelegungen'] ?? [] as $fb) if (array_filter($fb['kursart'] ?? [])) $hatWahlen = true;
    if ($hatWahlen && !$ueberschreiben)
        return $info + ['status' => 'uebersprungen', 'meldung' => 'Enthält bereits Fachwahlen (nicht überschrieben).'];

    $gen = new LaufbahnGenerator($daten);
    $erg = $gen->erzeuge($s, $vorgabe);
    $s['fachbelegungen'] = $erg['fachbelegungen'];
    $s['gkl'] = $erg['gkl'];
    unset($s);

    // Zusammenfassung
    $F = $gen->faecher();
    $abi = [];
    foreach ($erg['fachbelegungen'] as $fb) if ($fb['abiturFach'] !== null) $abi[$fb['abiturFach']] = $F->anzeige($fb['fachID']);
    ksort($abi);
    // für die Auswertung der Voreinstellungen
    $stat = ['lk' => [], 'belegt' => [], 'gkQ1' => [], 'q' => [0, 0, 0, 0]];
    foreach ($erg['fachbelegungen'] as $fb) for ($h = 2; $h <= 5; $h++) if ($fb['kursart'][$h] !== null) $stat['q'][$h - 2]++;
    $stat['ef'] = [0, 0];
    foreach ($erg['fachbelegungen'] as $fb) for ($h = 0; $h <= 1; $h++) if ($fb['kursart'][$h] !== null && $F->kuerzel($fb['fachID']) !== 'VX') $stat['ef'][$h]++;
    foreach ($erg['fachbelegungen'] as $fb) {
        $kz = $F->kuerzel($fb['fachID']);
        if (($F->kat[$fb['fachID']] ?? '') === 'FS' && !$F->istNeueFS($fb['fachID'])) $kz = $F->sprache($fb['fachID']);
        if ($fb['abiturFach'] === 1 || $fb['abiturFach'] === 2) $stat['lk'][] = $kz;
        if (array_filter($fb['kursart'])) $stat['belegt'][] = $kz;
        if ($fb['kursart'][2] === 'GK' || $fb['kursart'][3] === 'GK') $stat['gkQ1'][] = $kz;
    }
    return $info + [
        'status'  => 'ok',
        'meldung' => implode(' ', $erg['hinweise']),
        'abi'     => $abi,
        'stat'    => $stat,
        'inhalt'  => lp_schreiben($daten),
    ];
}

/* =========================================================================
 *  Voreinstellungen (Schieberegler) auf den Jahrgang verteilen
 * ========================================================================= */

/** Fächer, deren LK-Anteil eingestellt werden kann: Kürzel => Bezeichnung */
const LK_REGLER = ['D' => 'Deutsch', 'M' => 'Mathematik', 'E' => 'Englisch', 'BI' => 'Biologie', 'PH' => 'Physik',
                   'GE' => 'Geschichte', 'EK' => 'Erdkunde', 'SP' => 'Sport'];
/** Fächer, deren Anteil als Grundkurs in der Q1 eingestellt werden kann */
const GK_REGLER = ['BI' => 'Biologie', 'CH' => 'Chemie', 'PH' => 'Physik', 'IF' => 'Informatik',
                   'GE' => 'Geschichte', 'EK' => 'Erdkunde', 'PA' => 'Pädagogik', 'LI' => 'Literatur'];
const REGLER_STANDARD = [
    'kumu' => 50,
    'LK' => ['D' => 30, 'M' => 35, 'E' => 30, 'BI' => 25, 'PH' => 10, 'GE' => 15, 'EK' => 10, 'SP' => 5],
    'GK' => ['BI' => 40, 'CH' => 25, 'PH' => 20, 'IF' => 15, 'GE' => 50, 'EK' => 30, 'PA' => 30, 'LI' => 20],
];

/** Kann das Fach (Kürzel) laut Fächerangebot der Datei überhaupt Leistungskurs sein? */
function lk_angeboten(string $roh, string $kuerzel): bool
{
    try { $gen = new LaufbahnGenerator(lp_lesen($roh)); } catch (Throwable $e) { return false; }
    $F = $gen->faecher();
    foreach ($gen->idsZuKuerzel($kuerzel) as $id) if ($F->abiLK($id) && $F->durchgehend($id)) return true;
    return false;
}

/** Kann das Fach als Grundkurs in der Q1 belegt werden? */
function gk_q1_angeboten(string $roh, string $kuerzel): bool
{
    try { $gen = new LaufbahnGenerator(lp_lesen($roh)); } catch (Throwable $e) { return false; }
    $F = $gen->faecher();
    foreach ($gen->idsZuKuerzel($kuerzel) as $id)
        if ($kuerzel === 'LI' ? $F->moeglichVonBis($id, 2, 3) : $F->moeglichVonBis($id, 0, 3)) return true;
    return false;
}

/** Wird diese Datei voraussichtlich gefüllt? (für die Verteilung der Anteile) */
function lp_wird_gefuellt(string $roh, bool $ueberschreiben): bool
{
    try { $d = lp_lesen($roh); } catch (Throwable $e) { return false; }
    $s = $d['schueler'][0] ?? null;
    if ((int)($d['lpRevision'] ?? 0) !== 2 || (int)($d['abiturjahr'] ?? 0) < 2030 || !$s) return false;
    if (in_array(true, $s['bewertetesHalbjahr'] ?? [], true) || !empty($s['bilingualeSprache'])) return false;
    if (!$ueberschreiben) foreach ($s['fachbelegungen'] ?? [] as $fb) if (array_filter($fb['kursart'] ?? [])) return false;
    return true;
}

/**
 * Verteilt die eingestellten Anteile exakt auf $n Schüler/innen.
 * $lkAnteile: Kürzel => Prozent (nur aktive Regler), $kuProzent: Anteil Kunst (null = frei)
 * @return array{0: array<int,array>, 1: string[]} [Vorgaben je Index, Warnungen]
 */
function verteile_vorgaben(int $n, array $lkAnteile, ?int $kuProzent, array $gkAnteile = []): array
{
    $vorgaben = array_fill(0, $n, ['lkPflicht' => [], 'lkVerboten' => [], 'gkPflicht' => [], 'gkVerboten' => [], 'gesperrt' => []]);
    $warn = [];
    if ($n === 0) return [$vorgaben, $warn];
    $last = array_fill(0, $n, 0);
    arsort($lkAnteile);
    foreach ($lkAnteile as $k => $prozent) {
        $soll = (int)round($n * $prozent / 100);
        $frei = array_keys(array_filter($last, fn($l) => $l < 2));
        shuffle($frei);
        usort($frei, fn($a, $b) => $last[$a] <=> $last[$b]);   // gleichmäßig verteilen
        $gewaehlt = array_slice($frei, 0, $soll);
        if (count($gewaehlt) < $soll) $warn[] = "$k-LK: nur " . count($gewaehlt) . " statt $soll Schüler/innen möglich (max. 2 LKs je Person).";
        $set = array_flip($gewaehlt);
        for ($i = 0; $i < $n; $i++) {
            if (isset($set[$i])) { $vorgaben[$i]['lkPflicht'][] = $k; $last[$i]++; }
            else $vorgaben[$i]['lkVerboten'][] = $k;
        }
    }
    // Grundkurse in der Q1: nur an Schüler/innen ohne LK in diesem Fach;
    // bei Naturwissenschaften zuerst an Schüler/innen, die noch keine NW haben
    $nw = ['BI', 'CH', 'PH'];
    $hatNW = function (int $i) use (&$vorgaben, $nw): bool {
        return (bool)array_intersect($nw, array_merge($vorgaben[$i]['lkPflicht'], $vorgaben[$i]['gkPflicht']));
    };
    arsort($gkAnteile);
    foreach ($gkAnteile as $k => $prozent) {
        $soll = (int)round($n * $prozent / 100);
        $kand = array_values(array_filter(range(0, $n - 1), fn($i) => !in_array($k, $vorgaben[$i]['lkPflicht'], true)));
        shuffle($kand);
        // Sport-LK-Schüler/innen zuletzt (Sport als Abiturfach lässt weniger Spielraum)
        $last = fn(int $i) => count($vorgaben[$i]['gkPflicht']) + (in_array('SP', $vorgaben[$i]['lkPflicht'], true) ? 3 : 0);
        usort($kand, fn($a, $b) => in_array($k, $nw, true)
            ? [(int)$hatNW($a), $last($a)] <=> [(int)$hatNW($b), $last($b)]
            : $last($a) <=> $last($b));
        $gewaehlt = array_flip(array_slice($kand, 0, $soll));
        if (count($gewaehlt) < $soll) $warn[] = "$k-GK in Q1: nur " . count($gewaehlt) . " statt $soll Schüler/innen möglich (die übrigen haben $k als LK).";
        for ($i = 0; $i < $n; $i++) {
            if (isset($gewaehlt[$i])) { $vorgaben[$i]['gkPflicht'][] = $k; if (!in_array($k, $vorgaben[$i]['lkVerboten'], true)) $vorgaben[$i]['lkVerboten'][] = $k; }
            else $vorgaben[$i]['gkVerboten'][] = $k;
        }
    }
    if (count(array_intersect($nw, array_keys($gkAnteile))) === 3) {
        $ohne = count(array_filter(range(0, $n - 1), fn($i) => !$hatNW($i)));
        if ($ohne > 0) $warn[] = "Für $ohne Schüler/innen bleibt nach den Reglern weder BI, CH noch PH (LK oder GK) – dort wird die Vorgabe gelockert, denn eine Naturwissenschaft ist Pflicht.";
    }
    if ($kuProzent !== null) {
        $anzKU = (int)round($n * $kuProzent / 100);
        $idx = range(0, $n - 1);
        shuffle($idx);
        foreach ($idx as $j => $i) $vorgaben[$i]['gesperrt'][] = $j < $anzKU ? 'MU' : 'KU';
    }
    return [$vorgaben, $warn];
}

/* =========================================================================
 *  Minimaler ZIP-Schreiber (ohne ZipArchive, Methode "stored")
 * ========================================================================= */

function zip_erzeugen(array $dateien): string
{
    $daten = ''; $zentral = ''; $n = 0;
    [$zeit, $datum] = (function () {
        $t = getdate();
        return [($t['hours'] << 11) | ($t['minutes'] << 5) | intdiv($t['seconds'], 2),
                (($t['year'] - 1980) << 9) | ($t['mon'] << 5) | $t['mday']];
    })();
    foreach ($dateien as $name => $inhalt) {
        $crc = crc32($inhalt); $len = strlen($inhalt); $nameLen = strlen($name);
        $offset = strlen($daten);
        $daten .= pack('VvvvvvVVVvv', 0x04034b50, 20, 0x0800, 0, $zeit, $datum, $crc, $len, $len, $nameLen, 0) . $name . $inhalt;
        $zentral .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0x0800, 0, $zeit, $datum, $crc, $len, $len, $nameLen, 0, 0, 0, 0, 0, $offset) . $name;
        $n++;
    }
    return $daten . $zentral . pack('VvvvvVVv', 0x06054b50, 0, 0, $n, $n, strlen($zentral), strlen($daten), 0);
}

/* =========================================================================
 *  Ablage der Ergebnisse
 * ========================================================================= */

function ablage_basis(): string
{
    $d = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'lp-multiwahl';
    if (!is_dir($d)) @mkdir($d, 0700, true);
    foreach (glob($d . DIRECTORY_SEPARATOR . '*') ?: [] as $alt) {
        if (is_dir($alt) && filemtime($alt) < time() - LPM_TTL) {
            foreach (glob($alt . DIRECTORY_SEPARATOR . '*') ?: [] as $f) @unlink($f);
            @rmdir($alt);
        }
    }
    return $d;
}

function sicherer_name(string $n): string
{
    $n = basename(str_replace('\\', '/', $n));
    $n = preg_replace('/[^\w\-. äöüÄÖÜß]/u', '_', $n) ?? 'datei.lp';
    if (!preg_match('/\.lp$/i', $n)) $n .= '.lp';
    return $n;
}

/** @return array<string,string> Dateiname => Rohinhalt */
function hochgeladene_dateien(): array
{
    $r = [];
    // Vom Browser gebündelte Dateien (umgeht die PHP-Grenze max_file_uploads)
    if (!empty($_POST['paket'])) {
        foreach ((array)json_decode((string)$_POST['paket'], true) as $eintrag) {
            if (!isset($eintrag['name'], $eintrag['data'])) continue;
            $roh = base64_decode((string)$eintrag['data'], true);
            if ($roh === false) continue;
            if (preg_match('/\.zip$/i', (string)$eintrag['name'])) {
                $tmp = tempnam(sys_get_temp_dir(), 'lpz');
                file_put_contents($tmp, $roh);
                $r += zip_lesen($tmp);
                @unlink($tmp);
            } else {
                $r[sicherer_name((string)$eintrag['name'])] = $roh;
            }
        }
        return $r;
    }
    $f = $_FILES['dateien'] ?? null;
    if (!$f) return $r;
    $namen = (array)$f['name']; $tmp = (array)$f['tmp_name']; $err = (array)$f['error'];
    foreach ($namen as $i => $name) {
        if (($err[$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;
        if (preg_match('/\.zip$/i', (string)$name)) {
            $r += zip_lesen($tmp[$i]);
        } else {
            $r[sicherer_name((string)$name)] = (string)file_get_contents($tmp[$i]);
        }
    }
    return $r;
}

/** @return array<string,string> .lp-Dateien aus einem ZIP-Archiv (reines PHP, ohne ZipArchive) */
function zip_lesen(string $pfad): array
{
    $roh = (string)file_get_contents($pfad);
    $r = [];
    $eocd = strrpos($roh, "PK\x05\x06");
    if ($eocd === false) return $r;
    $e = unpack('vdisk/vcddisk/vnumdisk/vnum/Vsize/Voffset/vclen', substr($roh, $eocd + 4, 18));
    $pos = $e['offset'];
    for ($i = 0; $i < $e['num']; $i++) {
        if (substr($roh, $pos, 4) !== "PK\x01\x02") break;
        $c = unpack('vver/vneed/vflags/vmethod/vtime/vdate/Vcrc/Vcsize/Vsize/vnlen/velen/vclen/vdisk/viattr/Vexattr/Voff', substr($roh, $pos + 4, 42));
        $name = substr($roh, $pos + 46, $c['nlen']);
        $pos += 46 + $c['nlen'] + $c['elen'] + $c['clen'];
        if (!preg_match('/\.lp$/i', $name) || strpos($name, '__MACOSX') !== false) continue;
        $lh = unpack('vnlen/velen', substr($roh, $c['off'] + 26, 4));
        $daten = substr($roh, $c['off'] + 30 + $lh['nlen'] + $lh['elen'], $c['csize']);
        if ($c['method'] === 0) $inhalt = $daten;
        elseif ($c['method'] === 8) { $inhalt = @gzinflate($daten); if ($inhalt === false) continue; }
        else continue;   // andere Kompressionsverfahren nicht unterstützt
        $r[sicherer_name($name)] = $inhalt;
    }
    return $r;
}

/* =========================================================================
 *  Web-Oberfläche
 * ========================================================================= */

if (PHP_SAPI === 'cli' || defined('LPM_NUR_BIBLIOTHEK')) return;

// ---- Downloads ----
if (isset($_GET['t'])) {
    $token = preg_replace('/[^a-f0-9]/', '', (string)$_GET['t']);
    $dir = ablage_basis() . DIRECTORY_SEPARATOR . $token;
    if ($token === '' || !is_dir($dir)) { http_response_code(404); exit('Die Dateien sind nicht mehr verfügbar. Bitte erneut hochladen.'); }
    if (isset($_GET['zip'])) {
        $dateien = [];
        foreach (glob($dir . DIRECTORY_SEPARATOR . '*.lp') ?: [] as $p) $dateien[basename($p)] = (string)file_get_contents($p);
        $zip = zip_erzeugen($dateien);
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="Laufbahnplanungen_gefuellt.zip"');
        header('Content-Length: ' . strlen($zip));
        echo $zip;
        exit;
    }
    $name = sicherer_name((string)($_GET['f'] ?? ''));
    $pfad = $dir . DIRECTORY_SEPARATOR . $name;
    if (!is_file($pfad)) { http_response_code(404); exit('Datei nicht gefunden.'); }
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . rawurlencode($name) . '"; filename*=UTF-8\'\'' . rawurlencode($name));
    header('Content-Length: ' . filesize($pfad));
    readfile($pfad);
    exit;
}

// ---- Verarbeitung ----
$ergebnisse = null; $token = null; $globalFehler = null; $warnungen = []; $auswertung = [];
// Reglerwerte (aus dem Formular oder Standardwerte)
$regler = ['kumu' => ['aktiv' => false, 'wert' => REGLER_STANDARD['kumu']]];
foreach (LK_REGLER as $k => $_) $regler['LK_' . $k] = ['aktiv' => false, 'wert' => REGLER_STANDARD['LK'][$k]];
foreach (GK_REGLER as $k => $_) $regler['GK_' . $k] = ['aktiv' => false, 'wert' => REGLER_STANDARD['GK'][$k]];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($regler as $k => &$r) {
        $r['aktiv'] = !empty($_POST['aktiv_' . $k]);
        if (isset($_POST['wert_' . $k])) $r['wert'] = max(0, min(100, (int)$_POST['wert_' . $k]));
    }
    unset($r);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    @set_time_limit(300);
    $ueberschreiben = !empty($_POST['ueberschreiben']);
    $dateien = hochgeladene_dateien();
    if (!$dateien) {
        $globalFehler = empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0
            ? 'Die hochgeladene Datenmenge überschreitet die PHP-Grenze post_max_size (' . ini_get('post_max_size') . '). Bitte in kleineren Gruppen hochladen oder den Wert erhöhen.'
            : 'Es wurden keine .lp-Dateien gefunden (auch nicht in einem ZIP-Archiv).';
    } else {
        $token = bin2hex(random_bytes(12));
        $dir = ablage_basis() . DIRECTORY_SEPARATOR . $token;
        @mkdir($dir, 0700, true);
        $ergebnisse = [];
        ksort($dateien, SORT_NATURAL | SORT_FLAG_CASE);

        // Voreinstellungen exakt auf die zu füllenden Dateien verteilen
        $fuellbar = [];
        foreach ($dateien as $name => $roh) if (lp_wird_gefuellt($roh, $ueberschreiben)) $fuellbar[] = $name;
        $lkAnteile = [];
        foreach (LK_REGLER as $k => $bez) if ($regler['LK_' . $k]['aktiv']) {
            if ($fuellbar && !lk_angeboten($dateien[$fuellbar[0]], $k)) { $warnungen[] = "$bez wird in diesem Jahrgang nicht als Leistungskurs (EF.1–Q2.2) angeboten – der Regler wird ignoriert."; continue; }
            $lkAnteile[$k] = $regler['LK_' . $k]['wert'];
        }
        $gkAnteile = [];
        foreach (GK_REGLER as $k => $bez) if ($regler['GK_' . $k]['aktiv']) {
            if ($fuellbar && !gk_q1_angeboten($dateien[$fuellbar[0]], $k)) { $warnungen[] = "$bez wird in diesem Jahrgang nicht als Grundkurs in der Q1 angeboten – der Regler wird ignoriert."; continue; }
            $gkAnteile[$k] = $regler['GK_' . $k]['wert'];
        }
        if (array_sum($lkAnteile) > 200) $warnungen[] = 'Die LK-Anteile ergeben zusammen mehr als 200 % – nicht alle Vorgaben sind erfüllbar.';
        foreach (array_intersect_key($lkAnteile, $gkAnteile) as $k => $p)
            if ($p + $gkAnteile[$k] > 100) $warnungen[] = "$k: LK- und GK-Anteil ergeben zusammen mehr als 100 %.";
        [$vorgabeListe, $w] = verteile_vorgaben(count($fuellbar), $lkAnteile, $regler['kumu']['aktiv'] ? $regler['kumu']['wert'] : null, $gkAnteile);
        $warnungen = array_merge($warnungen, $w);
        $vorgabeJeDatei = array_combine($fuellbar, $vorgabeListe) ?: [];

        foreach ($dateien as $name => $roh) {
            try {
                $e = lp_fuellen($roh, $ueberschreiben, $vorgabeJeDatei[$name] ?? []);
                if (($e['status'] ?? '') === 'ok') file_put_contents($dir . DIRECTORY_SEPARATOR . $name, $e['inhalt']);
                unset($e['inhalt']);
                $ergebnisse[] = ['datei' => $name] + $e;
            } catch (Throwable $ex) {
                $ergebnisse[] = ['datei' => $name, 'status' => 'fehler', 'meldung' => $ex->getMessage()];
            }
        }
    }
}

function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

$anzOk = $ergebnisse ? count(array_filter($ergebnisse, fn($e) => $e['status'] === 'ok')) : 0;
// Auswertung: tatsächlich erreichte Anteile
if ($anzOk > 0) {
    $gefuellt = array_filter($ergebnisse, fn($e) => $e['status'] === 'ok');
    foreach (LK_REGLER as $k => $bez) {
        if (!$regler['LK_' . $k]['aktiv']) continue;
        $ist = count(array_filter($gefuellt, fn($e) => in_array($k, $e['stat']['lk'], true)));
        $auswertung[] = ["$bez-LK", $regler['LK_' . $k]['wert'] . ' %', round(100 * $ist / $anzOk) . " % ($ist)"];
    }
    foreach (GK_REGLER as $k => $bez) {
        if (!$regler['GK_' . $k]['aktiv']) continue;
        $ist = count(array_filter($gefuellt, fn($e) => in_array($k, $e['stat']['gkQ1'], true)));
        $auswertung[] = ["$bez-GK in Q1", $regler['GK_' . $k]['wert'] . ' %', round(100 * $ist / $anzOk) . " % ($ist)"];
    }
    $ku = count(array_filter($gefuellt, fn($e) => in_array('KU', $e['stat']['belegt'], true)));
    $mu = count(array_filter($gefuellt, fn($e) => in_array('MU', $e['stat']['belegt'], true)));
    $zehn = count(array_filter($gefuellt, fn($e) => $e['stat']['q'] === [10, 10, 10, 10]));
    $elf = count(array_filter($gefuellt, fn($e) => $e['stat']['ef'] === [11, 11]));
    $auswertung[] = ['11 Fächer in der EF', 'alle', "$elf von $anzOk"];
    $auswertung[] = ['10 Kurse je Q-Halbjahr', 'möglichst alle', "$zehn von $anzOk"];
    if ($regler['kumu']['aktiv']) $auswertung[] = ['Kunst : Musik', $regler['kumu']['wert'] . ' : ' . (100 - $regler['kumu']['wert']), "$ku : $mu Schüler/innen"];
}
?><!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="favicon.png">
<title>LP-Multiwahl – Laufbahnplanungen automatisch füllen</title>
<style>
  :root { --bg:#f6f7f9; --card:#fff; --text:#1d2433; --muted:#5d6779; --line:#e2e6ec; --accent:#1f6feb; --ok:#1a7f37; --warn:#9a6700; --err:#cf222e; }
  * { box-sizing:border-box; }
  body { margin:0; font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif; background:var(--bg); color:var(--text); }
  header { background:#16325c; color:#fff; padding:22px 0; }
  .wrap { max-width:1100px; margin:0 auto; padding:0 20px; }
  header h1 { margin:0; font-size:22px; font-weight:650; }
  header p { margin:4px 0 0; opacity:.85; }
  main.wrap { padding-top:24px; padding-bottom:48px; }
  .card { background:var(--card); border:1px solid var(--line); border-radius:10px; padding:22px; margin-bottom:20px; }
  h2 { font-size:17px; margin:0 0 12px; }
  .drop { display:block; width:100%; max-width:560px; border:2px dashed #b8c2d1; border-radius:10px; padding:16px 18px; text-align:center; background:#fafbfc; cursor:pointer; transition:.15s; overflow-wrap:anywhere; }
  .drop.over { border-color:var(--accent); background:#eef4ff; }
  .drop strong { display:block; font-size:15px; margin-bottom:2px; }
  .drop small { display:block; }
  .drop small { color:var(--muted); }
  #liste { margin-top:10px; color:var(--muted); font-size:13px; }
  .row { display:flex; gap:18px; align-items:center; flex-wrap:wrap; margin-top:16px; }
  label.cb { display:flex; gap:8px; align-items:center; }
  button, .btn { background:var(--accent); color:#fff; border:0; border-radius:8px; padding:10px 18px; font-size:15px; font-weight:600; cursor:pointer; text-decoration:none; display:inline-block; }
  button:disabled { opacity:.5; cursor:default; }
  .btn.sek { background:#fff; color:var(--accent); border:1px solid var(--accent); }
  table { width:100%; border-collapse:collapse; font-size:14px; }
  th, td { text-align:left; padding:8px 10px; border-bottom:1px solid var(--line); vertical-align:top; }
  th { color:var(--muted); font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:.03em; }
  .st { font-weight:600; white-space:nowrap; }
  .st.ok { color:var(--ok); } .st.uebersprungen { color:var(--warn); } .st.fehler { color:var(--err); }
  .abi span { display:inline-block; background:#eef1f5; border-radius:4px; padding:0 6px; margin:0 3px 2px 0; font-size:12.5px; }
  .abi span.lk { background:#dbe8ff; font-weight:600; }
  .muted { color:var(--muted); font-size:13px; }
  .hinweis { background:#fff8e6; border:1px solid #f0d58c; border-radius:8px; padding:10px 14px; font-size:13.5px; }
  .fehlerbox { background:#ffebe9; border:1px solid #f5b5b0; border-radius:8px; padding:10px 14px; }
  ol { margin:6px 0 0 18px; padding:0; } li { margin:3px 0; }
  details.regler-box { margin-top:16px; border:1px solid var(--line); border-radius:10px; padding:10px 16px; }
  details.regler-box summary { font-weight:600; cursor:pointer; }
  .regler-gruppen { display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:14px; }
  fieldset.regler { border:1px solid var(--line); border-radius:8px; margin:0; padding:6px 12px 10px; min-width:0; }
  fieldset.regler legend { font-weight:600; padding:0 6px; font-size:13px; color:var(--muted); text-transform:uppercase; letter-spacing:.03em; }
  .regel { display:grid; grid-template-columns:118px 1fr 92px; gap:10px; align-items:center; padding:3px 0; }
  .regel label.cb { font-size:14px; gap:6px; }
  .regel input[type=range] { width:100%; min-width:0; accent-color:var(--accent); }
  .regel input[type=range]:disabled { opacity:.35; }
  .regel output { font-variant-numeric:tabular-nums; font-size:13.5px; text-align:right; white-space:nowrap; }
  .regel.aus output { color:var(--muted); }
  .kumu-regel { border-top:1px dashed var(--line); margin-top:6px; padding-top:8px; }
  .summe { font-size:13px; color:var(--err); }
  @media (max-width:420px) { .regel { grid-template-columns:1fr 84px; } .regel input[type=range] { grid-column:1 / -1; grid-row:2; } }
  table.auswertung { width:auto; margin:4px 0 16px; }
  table.auswertung td, table.auswertung th { padding:4px 14px 4px 0; border:0; }
  .zusammen { display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-bottom:14px; }
</style>
</head>
<body>
<header><div class="wrap">
  <h1>LP-Multiwahl</h1>
  <p>Laufbahnplanungsdateien (.lp) des SVWS-Servers mit zufälligen, gültigen Fachwahlen füllen</p>
</div></header>
<main class="wrap">

<?php if ($globalFehler): ?>
  <div class="card fehlerbox"><?= h($globalFehler) ?></div>
<?php endif; ?>

<?php if ($ergebnisse !== null): ?>
  <div class="card">
    <div class="zusammen">
      <h2 style="margin:0"><?= $anzOk ?> von <?= count($ergebnisse) ?> Dateien gefüllt</h2>
      <?php if ($anzOk > 0): ?>
        <a class="btn" href="?t=<?= h($token) ?>&amp;zip=1">Alle gefüllten Dateien als ZIP herunterladen</a>
      <?php endif; ?>
    </div>
    <?php foreach ($warnungen as $w): ?><p class="hinweis"><?= h($w) ?></p><?php endforeach; ?>
    <?php if ($auswertung): ?>
      <table class="auswertung">
        <thead><tr><th>Voreinstellung</th><th>Ziel</th><th>Ergebnis</th></tr></thead>
        <tbody><?php foreach ($auswertung as [$a, $b, $c]): ?><tr><td><?= h($a) ?></td><td><?= h($b) ?></td><td><?= h($c) ?></td></tr><?php endforeach; ?></tbody>
      </table>
    <?php endif; ?>
    <table>
      <thead><tr><th>Datei</th><th>Schüler/in</th><th>Status</th><th>Abiturfächer</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($ergebnisse as $e): ?>
        <tr>
          <td><?= h($e['datei']) ?></td>
          <td><?= h($e['name'] ?? '') ?></td>
          <td>
            <span class="st <?= h($e['status']) ?>"><?= ['ok' => 'gefüllt', 'uebersprungen' => 'übersprungen', 'fehler' => 'Fehler'][$e['status']] ?? h($e['status']) ?></span>
            <?php if (!empty($e['meldung'])): ?><div class="muted"><?= h($e['meldung']) ?></div><?php endif; ?>
          </td>
          <td class="abi">
            <?php if (!empty($e['abi']) && is_array($e['abi'])) foreach ($e['abi'] as $nr => $k): ?>
              <span class="<?= $nr <= 2 ? 'lk' : '' ?>" title="<?= $nr ?>. Abiturfach"><?= $nr ?>: <?= h($k) ?></span>
            <?php endforeach; ?>
          </td>
          <td><?php if ($e['status'] === 'ok'): ?><a href="?t=<?= h($token) ?>&amp;f=<?= rawurlencode($e['datei']) ?>">Download</a><?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <p class="muted" style="margin-bottom:0">Die erzeugten Dateien bleiben ca. <?= intdiv(LPM_TTL, 60) ?> Minuten auf dem Server und werden danach automatisch gelöscht.</p>
  </div>
<?php endif; ?>

  <div class="card">
    <h2>Dateien hochladen</h2>
    <form method="post" enctype="multipart/form-data" id="form">
      <label class="drop" id="drop">
        <strong>.lp-Dateien oder ZIP-Archiv hierher ziehen oder klicken</strong>
        <small>Mehrfachauswahl möglich (z. B. alle Dateien eines Abiturjahrgangs) – auch als ZIP-Archiv</small>
        <input type="file" name="dateien[]" id="dateien" accept=".lp,.zip" multiple hidden>
        <div id="liste"></div>
      </label>
      <details class="regler-box" <?= array_filter(array_column($regler, 'aktiv')) ? 'open' : '' ?>>
        <summary>Voreinstellungen für den Jahrgang</summary>
        <p class="muted" style="margin:6px 0 10px">Nur angehakte Regler werden berücksichtigt. Die Anteile werden genau auf die hochgeladenen Schüler/innen verteilt;
          wer nicht ausgewählt wird, bekommt das Fach in dieser Form nicht.</p>
        <div class="regler-gruppen">
          <fieldset class="regler">
            <legend>Leistungskurse</legend>
            <?php foreach (LK_REGLER as $k => $bez): ?>
            <div class="regel">
              <label class="cb"><input type="checkbox" name="aktiv_LK_<?= $k ?>" value="1" <?= $regler['LK_' . $k]['aktiv'] ? 'checked' : '' ?>> <?= h($bez) ?></label>
              <input type="range" name="wert_LK_<?= $k ?>" min="0" max="100" step="1" value="<?= (int)$regler['LK_' . $k]['wert'] ?>" data-art="lk" aria-label="Anteil <?= h($bez) ?>-LK">
              <output></output>
            </div>
            <?php endforeach; ?>
            <div class="muted summe" id="summe"></div>
          </fieldset>
          <fieldset class="regler">
            <legend>Grundkurse in der Q1</legend>
            <?php foreach (GK_REGLER as $k => $bez): ?>
            <div class="regel">
              <label class="cb"><input type="checkbox" name="aktiv_GK_<?= $k ?>" value="1" <?= $regler['GK_' . $k]['aktiv'] ? 'checked' : '' ?>> <?= h($bez) ?></label>
              <input type="range" name="wert_GK_<?= $k ?>" min="0" max="100" step="1" value="<?= (int)$regler['GK_' . $k]['wert'] ?>" data-art="gk" aria-label="Anteil <?= h($bez) ?>-GK">
              <output></output>
            </div>
            <?php endforeach; ?>
            <div class="regel kumu-regel">
              <label class="cb"><input type="checkbox" name="aktiv_kumu" value="1" <?= $regler['kumu']['aktiv'] ? 'checked' : '' ?>> Kunst : Musik</label>
              <input type="range" name="wert_kumu" min="0" max="100" step="5" value="<?= (int)$regler['kumu']['wert'] ?>" data-art="kumu" aria-label="Verhältnis Kunst zu Musik">
              <output></output>
            </div>
          </fieldset>
        </div>
      </details>
      <div class="row">
        <label class="cb"><input type="checkbox" name="ueberschreiben" value="1" checked> Vorhandene Fachwahlen überschreiben</label>
        <button type="submit" id="los" disabled>Laufbahnen erzeugen</button>
      </div>
    </form>
  </div>

  <div class="card">
    <h2>So funktioniert es</h2>
    <ol>
      <li>Im SVWS-Client unter <em>Oberstufe → Laufbahnplanung</em> die Laufbahnplanungen des Abiturjahrgangs als .lp-Dateien exportieren (einzeln oder zusammen als ZIP-Archiv).</li>
      <li>Die Dateien bzw. das ZIP-Archiv hier hochladen. Ein ZIP-Archiv wird automatisch entpackt. Für jede Schülerin und jeden Schüler wird eine zufällige Laufbahn nach APO-GOSt (ab Abitur 2030) erzeugt – passend zur Sprachenfolge und zum Fächerangebot der Datei.</li>
      <li>Die gefüllten Dateien herunterladen und im SVWS-Client bzw. in der WebLuPO wieder importieren.</li>
    </ol>
    <p class="hinweis" style="margin-top:14px">
      Über die Voreinstellungen lassen sich Anteile für Leistungskurse, Grundkurse in der Q1 und das Verhältnis Kunst : Musik vorgeben.
      Berücksichtigt werden u. a.: 11 Fächer in EF.1 und EF.2 (Spielraum für die Blockung), 2 Leistungskurse und 5 Abiturfächer, 40 Kurse in der Q-Phase (möglichst je 10 in Q1.1, Q1.2, Q2.1 und Q2.2), Projektkurs mit Referenzfach,
      Fremdsprachen- und Naturwissenschafts-Schwerpunkt, Zusatzkurse GE/SW, Schriftlichkeiten, gleichwertige komplexe Leistungsnachweise (GKL)
      sowie die schulspezifischen Fächerkombinationen und Wählbarkeiten aus der Datei.
      Nicht automatisch geplant werden bilinguale Bildungsgänge und Schüler/innen mit bereits bewerteten Halbjahren.
    </p>
  </div>

  <p class="muted">LP-Multiwahl <?= LPM_VERSION ?> · Daten werden nur temporär auf diesem Server verarbeitet.</p>
</main>
<script>
(() => {
  const drop = document.getElementById('drop'), input = document.getElementById('dateien'),
        liste = document.getElementById('liste'), los = document.getElementById('los'), form = document.getElementById('form');
  const zeige = () => {
    const n = input.files.length;
    los.disabled = n === 0;
    liste.textContent = n ? n + ' Datei(en) ausgewählt: ' + Array.from(input.files).slice(0, 3).map(f => f.name).join(', ') + (n > 3 ? ' und ' + (n - 3) + ' weitere' : '') : '';
  };
  input.addEventListener('change', zeige);
  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => { input.files = e.dataTransfer.files; zeige(); });

  // Schieberegler: Anzeige der Werte, Aktivierung per Häkchen, Summenkontrolle
  const regeln = Array.from(document.querySelectorAll('.regel'));
  const aktualisiere = () => {
    let summe = 0;
    for (const r of regeln) {
      const cb = r.querySelector('input[type=checkbox]'), sl = r.querySelector('input[type=range]'), out = r.querySelector('output');
      sl.disabled = !cb.checked; r.classList.toggle('aus', !cb.checked);
      const v = +sl.value;
      if (!cb.checked) out.textContent = 'zufällig';
      else if (sl.dataset.art === 'kumu') out.textContent = 'KU ' + v + ' : ' + (100 - v) + ' MU';
      else { out.textContent = v + ' %'; if (sl.dataset.art === 'lk') summe += v; }
    }
    document.getElementById('summe').textContent = summe > 200
      ? '⚠ Zusammen ' + summe + ' % – jede/r hat nur 2 LKs (max. 200 %).' : '';
  };
  regeln.forEach(r => r.addEventListener('input', aktualisiere));
  aktualisiere();

  // Alle Dateien in einem Formularfeld bündeln – so gilt die PHP-Grenze max_file_uploads nicht.
  const alsBase64 = f => new Promise((ok, fehler) => {
    const r = new FileReader();
    r.onload = () => ok(String(r.result).split(',')[1] || '');
    r.onerror = fehler;
    r.readAsDataURL(f);
  });
  let gebuendelt = false;
  form.addEventListener('submit', async e => {
    los.disabled = true; los.textContent = 'Wird erzeugt …';
    if (gebuendelt || !window.FileReader) return;
    e.preventDefault();
    try {
      const paket = [];
      for (const f of input.files) paket.push({ name: f.name, data: await alsBase64(f) });
      const feld = document.createElement('input');
      feld.type = 'hidden'; feld.name = 'paket'; feld.value = JSON.stringify(paket);
      form.appendChild(feld);
      input.removeAttribute('name');
    } catch (err) { /* Fallback: normaler Datei-Upload */ }
    gebuendelt = true;
    form.submit();
  });
})();
</script>
</body>
</html>