<?php
namespace wenom;
class Version {
    public const VERSION = "1.5.1";
    public const GITHASH = "cb0a389ee8d431d1e09e5daa4dae0b01f619552b";
}
