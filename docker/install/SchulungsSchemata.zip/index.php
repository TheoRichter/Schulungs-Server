<?php

$directory = __DIR__;
$baseUrl = '/netzlaufwerk/OfficelleTestDBS/';


/*
 * ============================================================
 * Dateien eines Ordners auslesen
 * ============================================================
 */
function getFiles(string $directory): array
{
    $files = [];

    if (!is_dir($directory)) {
        return $files;
    }

    /*
     * Erlaubte Dateiendungen
     */
    $allowedExtensions = [
        'sqlite',
        'gz',
        'zip',
        'json',
        'csv',
        'mdb'
    ];

    foreach (scandir($directory) as $file) {

        if ($file === '.' || $file === '..') {
            continue;
        }

        $path = $directory . DIRECTORY_SEPARATOR . $file;

        if (!is_file($path)) {
            continue;
        }

        /*
         * Dateiendung ermitteln
         */
        $extension = strtolower(
            pathinfo($file, PATHINFO_EXTENSION)
        );

        /*
         * Nur erlaubte Dateien
         */
        if (!in_array($extension, $allowedExtensions, true)) {
            continue;
        }

        $files[] = [
            'name'      => $file,
            'extension' => $extension,
            'mtime'     => filemtime($path),
            'size'      => filesize($path)
        ];
    }

    return $files;
}


/*
 * ============================================================
 * Beschreibung zur Dateiendung
 * ============================================================
 */
function getDescription(string $extension): string
{
    switch (strtolower($extension)) {

        case 'sqlite':
            return 'SQLite-Schema';

        case 'gz':
            return 'GZIP-Datei';

        case 'json':
            return 'JSON-Datei';

        case 'csv':
            return 'CSV-Datei';

        case 'zip':
            return 'ZIP-Datei';

        case 'mdb':
            return 'Microsoft-Access-Datenbank';

        default:
            return 'Datei';
    }
}


/*
 * ============================================================
 * Ordner rekursiv auslesen
 * ============================================================
 */
function getFolders(
    string $directory,
    string $relativePath = ''
): array {

    $folders = [];

    if (!is_dir($directory)) {
        return $folders;
    }

    foreach (scandir($directory) as $item) {

        if ($item === '.' || $item === '..') {
            continue;
        }

        $path = $directory . DIRECTORY_SEPARATOR . $item;

        if (!is_dir($path)) {
            continue;
        }

        $folder = [
            'name'       => $item,
            'path'       => $relativePath . $item,
            'files'      => getFiles($path),
            'subfolders' => getFolders(
                $path,
                $relativePath . $item . '/'
            )
        ];

        /*
         * Ordner nur anzeigen, wenn er Dateien
         * oder weitere Unterordner enthält.
         */
        if (
            !empty($folder['files']) ||
            !empty($folder['subfolders'])
        ) {
            $folders[] = $folder;
        }
    }

    return $folders;
}


/*
 * ============================================================
 * Dateigröße formatieren
 * ============================================================
 */
function formatSize(int $bytes): string
{
    if ($bytes < 1024) {
        return $bytes . ' B';
    }

    if ($bytes < 1024 * 1024) {
        return number_format(
            $bytes / 1024,
            1,
            ',',
            '.'
        ) . ' KB';
    }

    if ($bytes < 1024 * 1024 * 1024) {
        return number_format(
            $bytes / 1024 / 1024,
            1,
            ',',
            '.'
        ) . ' MB';
    }

    return number_format(
        $bytes / 1024 / 1024 / 1024,
        1,
        ',',
        '.'
    ) . ' GB';
}


/*
 * ============================================================
 * URL für eine Datei erzeugen
 * ============================================================
 */
function fileUrl(
    string $baseUrl,
    string $folder,
    string $filename
): string {

    $parts = [];

    if ($folder !== '') {
        $parts[] = trim($folder, '/');
    }

    $parts[] = $filename;

    /*
     * Jeden Pfadbestandteil einzeln URL-encoden.
     * Dadurch bleiben "/" als Verzeichnistrenner erhalten.
     */
    $encoded = array_map(
        'rawurlencode',
        $parts
    );

    return $baseUrl . implode('/', $encoded);
}


/*
 * ============================================================
 * Ordner rekursiv ausgeben
 * ============================================================
 */
function renderFolders(
    array $folders,
    string $baseUrl,
    int $level = 0
): void {

    foreach ($folders as $folder):

        $indent = $level * 30;

?>

<!-- Ordner -->

<tr class="folder">

    <td colspan="4"
        style="padding-left: <?= 25 + $indent ?>px;">

        <span class="folder-icon">📁</span>

        <strong>
            <?= htmlspecialchars($folder['name']) ?>
        </strong>

    </td>

</tr>


<?php

        /*
         * Dateien
         */
        foreach ($folder['files'] as $file):

            $url = fileUrl(
                $baseUrl,
                $folder['path'],
                $file['name']
            );

            $description = getDescription(
                $file['extension']
            );

?>

<tr class="file">

    <td class="name"
        style="padding-left: <?= 55 + $indent ?>px;">

        <span class="file-icon">📄</span>

        <a href="<?= htmlspecialchars($url) ?>">

            <?= htmlspecialchars($file['name']) ?>

        </a>

    </td>

    <td class="date">

        <?= date(
            'd.m.Y H:i',
            $file['mtime']
        ) ?>

    </td>

    <td class="size">

        <?= formatSize(
            $file['size']
        ) ?>

    </td>

    <td class="description">

        <?= htmlspecialchars($description) ?>

    </td>

</tr>

<?php

        endforeach;


        /*
         * Unterordner
         */
        if (!empty($folder['subfolders'])) {

            renderFolders(
                $folder['subfolders'],
                $baseUrl,
                $level + 1
            );
        }

    endforeach;
}


/*
 * ============================================================
 * Ordner einlesen
 * ============================================================
 */
$folders = getFolders($directory);

?>

<!DOCTYPE html>

<html lang="de">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Index de Schulungs-Schemata</title>


<style>

body {

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    font-size: 17px;

    margin:
        35px 45px;

    background:
        #ffffff;

    color:
        #222222;
}


h1 {

    font-size:
        30px;

    font-weight:
        normal;

    margin:
        0 0 30px 0;
}


table {

    border-collapse:
        collapse;

    width:
        100%;

    max-width:
        1400px;
}


th {

    text-align:
        left;

    font-size:
        18px;

    font-weight:
        bold;

    padding:
        12px 25px;

    border-bottom:
        2px solid #bbbbbb;

    white-space:
        nowrap;
}


td {

    font-size:
        17px;

    padding:
        10px 25px;

    vertical-align:
        middle;
}


.name {

    min-width:
        500px;
}


.date {

    white-space:
        nowrap;
}


.size {

    white-space:
        nowrap;
}


.description {

    white-space:
        nowrap;
}


/*
 * ============================================================
 * Ordner
 * ============================================================
 */

tr.folder {

    background:
        #f5f5f5;

    border-bottom:
        1px solid #dddddd;
}


tr.folder:hover {

    background:
        #eeeeee;
}


.folder-icon {

    margin-right:
        8px;
}


/*
 * ============================================================
 * Dateien
 * ============================================================
 */

tr.file:hover {

    background:
        #f2f2f2;
}


.file-icon {

    margin-right:
        8px;
}


/*
 * ============================================================
 * Links
 * ============================================================
 */

a {

    color:
        #0645ad;

    text-decoration:
        none;
}


a:hover {

    text-decoration:
        underline;
}


/*
 * ============================================================
 * Parent Directory
 * ============================================================
 */

.parent {

    padding-bottom:
        18px;
}


/*
 * ============================================================
 * Fußzeile
 * ============================================================
 */

.footer {

    margin-top:
        35px;

    padding-top:
        12px;

    border-top:
        1px solid #cccccc;

    color:
        #777777;

    font-size:
        13px;
}

</style>

</head>


<body>


<h1>
    Index der Schulungs-Schemata
</h1>


<table>

<thead>

<tr>

<th class="name">
    Name
</th>

<th class="date">
    Letzte Änderung
</th>

<th class="size">
    Größe
</th>

<th class="description">
    Beschreibung
</th>

</tr>

</thead>


<tbody>


<!-- Parent Directory -->

<tr>

<td class="parent">

<a href="/">
    Parent Directory
</a>

</td>

<td></td>

<td>
    -
</td>

<td></td>

</tr>


<?php

/*
 * Ordner und Dateien ausgeben
 */
renderFolders(
    $folders,
    $baseUrl
);

?>


</tbody>

</table>


<div class="footer">

Apache/<?= htmlspecialchars(
    $_SERVER['SERVER_SOFTWARE'] ?? ''
) ?>

</div>


</body>

</html>

