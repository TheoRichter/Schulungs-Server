# Änderungen an der Gesamtschuldatenbank

Zu Schulungszwecken wurde die Gesamtschudatenbank abgeändert. Folgende Änderungen wurden vorgenommen:

* Die Klasse 07B enthält keine Fächer.

* Der Jahrgang 05 hat keine Religions-/Philosophiekurse.

* Es wurden Floskeln zugewiesen.
