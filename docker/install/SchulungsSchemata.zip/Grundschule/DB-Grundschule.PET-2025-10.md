# Änderungen der Grundschuldatenbank

Folgende Änderungen an der DB "Grundschule" haben wir vorgenommen (PET Bonn, 28./29.10.2025, Marit, Ralf):

* GELÖSCHT: Lehrkraft BER hatte gesamte UV.
* GEÄNDERT/ERGÄNZT: Katalog Unterrichtsfächer angepasst, "exotische" Fächer ausgeblendet.
* GEÄNDERT/ERGÄNZT: Stundentafeln für Jahrgänge 3 und 4 angelegt.
* ERGÄNZT: Klassenunterrichte für 02B und 04B angelegt aus Stundentafeln, Lehrkräfte zugeordnet.

