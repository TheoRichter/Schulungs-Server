#!/bin/bash
##########################################################################
# Quelldatei und Zieldatei
QUELLE="schulungen.txt"
ZIEL="letzteZeile.txt"
##########################################################################
# Prüfen, ob Quelldatei existiert
if [ ! -f "$QUELLE" ]; then
  echo "Datei '$QUELLE' nicht gefunden."
  exit 1
fi
##########################################################################
# Letzte Zeile auslesen und in Zieldatei schreiben
tail -n 1 "$QUELLE" > "$ZIEL"
cp $ZIEL /var/www/html/sh
chmod -R 777 /var/www/html/sh/$ZIEL
chown -R www-data:www-data /var/www/html/sh/$ZIEL
##########################################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
##########################################################################
sed -i 's/letzteZeile/'$STACK'/g' /var/www/html/svws-schemata.html     ###
sed -i 's/letzteZeile/'$STACK'/g' /var/www/html/container_update.php   ###
##########################################################################
done  < letzteZeile.txt
