#!/bin/bash
STACK=""
################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
   docker stop $STACK-Webserver
   docker stop $STACK-Webserver
done < schulungen.txt
