#/!/bin/bash
cd /var/www/html/zip
unzip -u -o /var/www/html/zip/*.zip -d /netzlaufwerk/OfficelleTestDBS/
chmod -R 777 /netzlaufwerk/OfficelleTestDBS/
chown -R www-data:www-data /netzlaufwerk/OfficelleTestDBS/
rm *.zip