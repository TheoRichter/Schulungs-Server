#!/bin/bash
#
WINPC=""
############################################################################
rm -rf  /netzlaufwerk/Schild-NRW-Reports 2>/dev/null
rm -rf  /netzlaufwerk/Schild-NRW-BK-Zeugnisse 2>/dev/null
cd /netzlaufwerk                                                  
git clone https://github.com/SVWS-NRW/Schild-NRW-Reports.git
git clone https://github.com/SVWS-NRW/Schild-NRW-BK-Zeugnisse.git
chmod -R 777 /netzlaufwerk
chown -R www-data:www-data /netzlaufwerk
############################################################################
cd /var/www/html/sh
############################################################################
while read ZEILE; do
  WINPC=$(echo $ZEILE | awk -F : '{print $1}')
#
cd /netzlaufwerk/SVWS-Arbeitsverzeichnisse
  rm -rf  $WINPC/Schild-Reports 2>/dev/null
  mkdir $WINPC/Schild-Reports
  cp -a /netzlaufwerk/Schild-NRW-Reports/"Reports Allgemein"/ -d $WINPC/Schild-Reports/"Reports Allgemein"/
  cp -a /netzlaufwerk/Schild-NRW-Reports/Oberstufenpaket/ -d $WINPC/Schild-Reports/Oberstufenpaket
  cp -a /netzlaufwerk/Schild-NRW-Reports/"Reports PS"/ -d $WINPC/Schild-Reports/"Reports PS"/
  cp -a /netzlaufwerk/Schild-NRW-Reports/"Reports SI"/ -d $WINPC/Schild-Reports/"Reports SI"/
  cp -a /netzlaufwerk/Schild-NRW-Reports/"Reports SII"/ -d $WINPC/Schild-Reports/"Reports SII"/
  cp -a /netzlaufwerk/Schild-NRW-Reports/Serienbriefe/ -d $WINPC/Schild-Reports/Serienbriefe
  cp -a /netzlaufwerk/Schild-NRW-BK-Zeugnisse/ -d $WINPC/Schild-Reports/"Zeugnisse - BK"/
#
chmod -R 777 /netzlaufwerk/SVWS-Arbeitsverzeichnisse/$WINPC
chown -R www-data:www-data /netzlaufwerk/SVWS-Arbeitsverzeichnisse/$WINPC
#
done < schid3connection.txt

