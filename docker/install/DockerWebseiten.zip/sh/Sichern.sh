#!/bin/bash
####################################################
cd sh                                            ###
####################################################
### schulungen.txt sichern                       ###
cp schulungen.txt schulungenOLD.txt              ### 
####################################################
cp schulungen.txt /var/www/html/docker           ###
echo "Anzeige der Datei und der Sicherungsdatei" ###
ls *.txt                                         ###
echo                                             ###
####################################################