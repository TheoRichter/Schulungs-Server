
#!/bin/bash

#####################################################################
# Verzeichnisse
#####################################################################

BASE="/var/www/html"
ZIPDIR="/var/www/html/zip"
DOCKERDIR="$BASE/docker"
SCRIPT_DIR="$BASE/sh"

cd "$SCRIPT_DIR" || exit 1

#####################################################################
# ZIP-Dateien ermitteln
#####################################################################

declare -A ZIP_FILES

ALL_ZIPS=()

TOOLS=(
    "laufbahn"
    "prognos"
    "import"
    "gradehub"
    "conference"
)

# Zuordnung der ZIP-Dateinamen
declare -A ZIP_PATTERNS

ZIP_PATTERNS["laufbahn"]="SVWS-Laufbahnplanung-*.zip"
ZIP_PATTERNS["wenom"]="WeNoM-*.zip"
ZIP_PATTERNS["import"]="SVWS-Import-*-webapp.zip"
ZIP_PATTERNS["prognos"]="SVWS-Prognos-*-webserver.zip"
ZIP_PATTERNS["conference"]="svws-conference-*-webserver.zip"
ZIP_PATTERNS["gradehub"]="gradehub-*-webserver.zip"

FOUND=false

echo ""
echo "=========================================="
echo "      Vorhandene ZIP-Dateien prüfen"
echo "=========================================="

#####################################################################
# Passende ZIP-Dateien suchen
#####################################################################

for TOOL in "${!ZIP_PATTERNS[@]}"; do

    PATTERN="${ZIP_PATTERNS[$TOOL]}"

    mapfile -t MATCHES < <(
        find "$ZIPDIR" -maxdepth 1 -type f \
        -name "$PATTERN" -printf '%f\n' | sort -V
    )

    if [ ${#MATCHES[@]} -gt 0 ]; then

        # Neueste Version auswählen
        ZIP_FILES["$TOOL"]="${MATCHES[-1]}"

        FOUND=true

        echo "[OK] $TOOL: ${ZIP_FILES[$TOOL]}"

        # Alle gefundenen ZIP-Dateien für die Bereinigung merken
        for FILE in "${MATCHES[@]}"; do
            ALL_ZIPS+=("$ZIPDIR/$FILE")
        done

    fi

done

#####################################################################
# Prüfen, ob ZIP-Dateien vorhanden sind
#####################################################################

if [ "$FOUND" = false ]; then

    echo ""
    echo "Keine passenden ZIP-Dateien gefunden."
    exit 1

fi

#####################################################################
# Schulungen abarbeiten
#####################################################################

while IFS= read -r ZEILE; do

    [ -z "$ZEILE" ] && continue

    STACK="${ZEILE%%:*}"

    echo ""
    echo "=========================================="
    echo "Bearbeite Stack: $STACK"
    echo "=========================================="

    STACKDIR="$DOCKERDIR/$STACK/$STACK"

    if [ ! -d "$STACKDIR" ]; then
        echo "Verzeichnis nicht gefunden: $STACKDIR"
        continue
    fi

    cd "$STACKDIR" || continue

    #################################################################
    # Docker Compose Datei übernehmen
    #################################################################

    if [ -f docker-compose-wenom.yml ]; then

        cp docker-compose-wenom.yml docker-compose.yml

    else

        echo "docker-compose-wenom.yml nicht gefunden!"
        continue

    fi

    #################################################################
    # ENM / WeNoM aktualisieren
    #################################################################

    if [ -n "${ZIP_FILES[wenom]:-}" ]; then

        echo "Aktualisiere WeNoM..."

        rm -rf www/wenom

        mkdir -p www/wenom

        cp "$ZIPDIR/${ZIP_FILES[wenom]}" \
           www/wenom/enmserver.zip

        cd www/wenom || continue

        if unzip -o enmserver.zip; then

            rm -f enmserver.zip

            echo "WeNoM erfolgreich aktualisiert."

            #################################################################
            # Datenbanken und Schlüssel übernehmen
            #################################################################

            if [ -f "/var/www/html/sqlite/app.sqlite" ]; then
                mkdir -p db
                cp "/var/www/html/sqlite/app.sqlite" db/app.sqlite
            fi

            if [ -f "/var/www/html/sqlite/client.sec" ]; then
                mkdir -p db
                cp "/var/www/html/sqlite/client.sec" db/client.sec
            fi

        else

            echo "Fehler beim Entpacken von WeNoM!"

        fi

        cd "$STACKDIR" || continue

    fi

    #################################################################
    # SVWS-Tools aktualisieren
    #################################################################

    for TOOL in "${TOOLS[@]}"; do

        # Prüfen, ob eine ZIP-Datei vorhanden ist
        if [ -n "${ZIP_FILES[$TOOL]:-}" ]; then

            ZIPNAME="${ZIP_FILES[$TOOL]}"

            echo ""
            echo "Aktualisiere Tool: $TOOL"
            echo "ZIP-Datei: $ZIPNAME"

            # Nur das vorhandene Tool löschen
            rm -rf "tools/$TOOL"

            # Verzeichnis neu anlegen
            mkdir -p "tools/$TOOL"

            # ZIP kopieren
            cp "$ZIPDIR/$ZIPNAME" "tools/$TOOL/$TOOL.zip"

            cd "tools/$TOOL" || continue

            # ZIP entpacken
            if unzip -o "$TOOL.zip"; then

                rm -f "$TOOL.zip"

                echo "$TOOL erfolgreich aktualisiert."

            else

                echo "Fehler beim Entpacken von $TOOL!"

            fi

            cd "$STACKDIR" || continue

        fi

    done

    #################################################################
    # Docker Compose starten
    #################################################################

    echo ""
    echo "Starte Docker Compose..."

    docker compose up -d

    #################################################################
    # Berechtigungen setzen
    #################################################################

    cd /tmp || continue

    if [ -n "${ZIP_FILES[wenom]:-}" ]; then

        docker exec "${STACK}-Webserver" /bin/sh -c \
            'chmod -R 775 /var/www/wenom/db' \
            'chmod 660 /var/www/wenom/db/app.sqlite' \
            'chmod 660 /var/www/wenom/db/tools.sqlite' \
            'chmod 644 /var/www/wenom/db/client.sec'
    fi

    docker exec "${STACK}-Webserver" /bin/sh -c \
        'chown -R www-data:www-data /var/www'

    #################################################################
    # Webserver stoppen
    #################################################################

    docker stop "${STACK}-Webserver"
    docker stop "${STACK}-svws-server-1"

    echo ""
    echo "Stack $STACK abgeschlossen."


done < "$SCRIPT_DIR/schulungen.txt"

#####################################################################
# Verwendete ZIP-Dateien löschen
#####################################################################

echo ""
echo "=========================================="
echo "       ZIP-Dateien aufräumen"
echo "=========================================="

for FILE in "${ALL_ZIPS[@]}"; do

    if [ -f "$FILE" ]; then

        rm -f "$FILE"

        echo "$(basename "$FILE") gelöscht."

    fi

done

#####################################################################
# Container neu starten
#####################################################################

echo ""
echo "=========================================="
echo "       Container neu starten"
echo "=========================================="

cd "$SCRIPT_DIR" || exit 1

while IFS= read -r ZEILE; do

    [ -z "$ZEILE" ] && continue

    STACK="${ZEILE%%:*}"

    docker start "${STACK}-Webserver"
    docker start "${STACK}-svws-server-1"

done < schulungen.txt
#####################################################################
### SVWS-Version einmalig in tools.sqlite eintragen               ###
#####################################################################
DB="/var/www/html/sqlite/tools.sqlite"

SVWSVersion=$(awk -F ':' 'NR==1 {print $8}' schulungen.txt)

sqlite3 "$DB" <<EOF
UPDATE laufbahn SET Installiert = '$SVWSVersion';
UPDATE wenom SET Installiert = '$SVWSVersion';

UPDATE conference SET Installiert = Aktuell;
UPDATE gradehub SET Installiert = Aktuell;
UPDATE import SET Installiert = Aktuell;
UPDATE prognos SET Installiert = Aktuell;
EOF

echo "SVWS-Version in tools.sqlite eingetragen: $SVWSVersion"
#####################################################################
# Fertig
#####################################################################

echo ""
echo "######################################################"
echo "### SVWS-Tools und WeNoM aktualisiert!             ###"
echo "### Container wurden neu gestartet!                ###"
echo "######################################################"