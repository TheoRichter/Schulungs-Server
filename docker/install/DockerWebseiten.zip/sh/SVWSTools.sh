
#!/bin/bash

#####################################################################
# Verzeichnisse
#####################################################################

BASE="/var/www/html"
ZIPDIR="$BASE/zip"
DOCKERDIR="$BASE/docker"
SCRIPT_DIR="$BASE/sh"

cd "$SCRIPT_DIR" || exit 1

#####################################################################
# Vorhandene ZIP-Dateien ermitteln
#####################################################################

ENM=false

TOOLS=(
    "laufbahn"
    "prognos"
    "import"
    "gradehub"
    "conference"
)

FOUND=false

echo ""
echo "=========================================="
echo "      Vorhandene ZIP-Dateien prüfen"
echo "=========================================="

if [ -f "$ZIPDIR/enmserver.zip" ]; then
    ENM=true
    FOUND=true
    echo "[OK] enmserver.zip"
fi

for TOOL in "${TOOLS[@]}"; do
    if [ -f "$ZIPDIR/$TOOL.zip" ]; then
        FOUND=true
        echo "[OK] $TOOL.zip"
    fi
done

#####################################################################
# Prüfen, ob ZIP-Dateien vorhanden sind
#####################################################################

if [ "$FOUND" = false ]; then
    echo ""
    echo "Keine passenden ZIP-Dateien gefunden."
    exit 1
fi

#####################################################################
# Schulungen abarbeiten
#####################################################################

while IFS= read -r ZEILE; do

    # Leere Zeilen überspringen
    [ -z "$ZEILE" ] && continue

    STACK=$(echo "$ZEILE" | awk -F ':' '{print $1}')

    echo ""
    echo "=========================================="
    echo "Bearbeite Stack: $STACK"
    echo "=========================================="

    STACKDIR="$DOCKERDIR/$STACK/$STACK"

    if [ ! -d "$STACKDIR" ]; then
        echo "Verzeichnis nicht gefunden: $STACKDIR"
        continue
    fi

    cd "$STACKDIR" || continue

    #################################################################
    # Docker Compose Datei übernehmen
    #################################################################

    if [ -f docker-compose-wenom.yml ]; then
        cp docker-compose-wenom.yml docker-compose.yml
    else
        echo "docker-compose-wenom.yml nicht gefunden!"
        continue
    fi

    #################################################################
    # ENM-Server aktualisieren
    #################################################################

    if [ "$ENM" = true ]; then

        echo "Aktualisiere ENM-Server..."

        # Nur ENM-Verzeichnis löschen
        rm -rf www/wenom

        # Neu anlegen
        mkdir -p www/wenom

        # ZIP kopieren
        cp "$ZIPDIR/enmserver.zip" www/wenom/enmserver.zip

        cd www/wenom || continue

        if unzip -o enmserver.zip; then

            rm -f enmserver.zip

            #################################################################
            # Datenbanken und Schlüssel übernehmen
            #################################################################

            if [ -f "/root/$STACK/www/wenom/db/app.sqlite" ]; then
                cp "/root/$STACK/www/wenom/db/app.sqlite" db/app.sqlite
            fi

            if [ -f "/root/$STACK/www/wenom/db/client.sec" ]; then
                cp "/root/$STACK/www/wenom/db/client.sec" db/client.sec
            fi

        else
            echo "Fehler beim Entpacken von enmserver.zip!"
        fi

        cd "$STACKDIR" || continue

    fi

    #################################################################
    # Tools aktualisieren
    #################################################################

    for TOOL in "${TOOLS[@]}"; do

        if [ -f "$ZIPDIR/$TOOL.zip" ]; then

            echo "Aktualisiere Tool: $TOOL"

            # Nur das vorhandene Tool löschen
            rm -rf "tools/$TOOL"

            # Verzeichnis neu anlegen
            mkdir -p "tools/$TOOL"

            # ZIP kopieren
            cp "$ZIPDIR/$TOOL.zip" "tools/$TOOL/$TOOL.zip"

            cd "tools/$TOOL" || continue

            # ZIP entpacken
            if unzip -o "$TOOL.zip"; then
                rm -f "$TOOL.zip"
                echo "$TOOL erfolgreich aktualisiert."
            else
                echo "Fehler beim Entpacken von $TOOL.zip!"
            fi

            cd "$STACKDIR" || continue

        fi

    done

    #################################################################
    # Docker Compose starten
    #################################################################

    echo "Starte Docker Compose..."

    docker compose up -d

    #################################################################
    # Berechtigungen setzen
    #################################################################

    cd /tmp || continue

    if [ "$ENM" = true ]; then

        docker exec "$STACK-Webserver" /bin/sh -c \
            'chmod -R 777 /var/www/wenom/db'

    fi

    docker exec "$STACK-Webserver" /bin/sh -c \
        'chown -R www-data:www-data /var/www'

    #################################################################
    # Webserver stoppen
    #################################################################

    docker stop "$STACK-Webserver"

    echo "Stack $STACK abgeschlossen."

done < "$SCRIPT_DIR/schulungen.txt"

#####################################################################
# Verwendete ZIP-Dateien löschen
#####################################################################

echo ""
echo "=========================================="
echo "       ZIP-Dateien aufräumen"
echo "=========================================="

if [ "$ENM" = true ]; then
    rm -f "$ZIPDIR/enmserver.zip"
    echo "enmserver.zip gelöscht."
fi

for TOOL in "${TOOLS[@]}"; do

    if [ -f "$ZIPDIR/$TOOL.zip" ]; then
        rm -f "$ZIPDIR/$TOOL.zip"
        echo "$TOOL.zip gelöscht."
    fi

done

#####################################################################
# Fertig
#####################################################################

echo ""
echo "=========================================="
echo "       Aktualisierung abgeschlossen"
echo "=========================================="
######################################################################
# Container neu starten
cd /var/www/html/sh
######################################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
#
  docker start $STACK-Webserver
done < schulungen.txt
#######################################################################
echo
echo "######################################################"
echo "### Wenom upgedatet und Container neu gestartet!!  ###" 
echo "######################################################"
