#!/bin/bash
#
for pc in `ls /netzlaufwerk/SVW-Arbeitsverzeichnisse/`;
do
	echo ++++++++++++++++++++++++++++
	echo + Ersetze Reports in $pc +
	echo ++++++++++++++++++++++++++++
	cd /netzlaufwerk/SVW-Arbeitsverzeichnisse/$pc/Schild-Reports	# Betrete das Reports-Verzeichnis des entsprechenden PCs
	rm -rf *	# lösche alle Dateien und Ordner
	# Erstelle die Ordner neu
	mkdir Reports\ Allgemein Reports\  Leistungsübersichten Reports\ PS Reports\ SI Reports\ SII Serienbriefe Oberstufenpaket
	# Ordner bekommen alle Rechte und gehören www-data
	chmod 777 *
	chown www-data:www-data *
	# Kopiere alle Dateien aus dem Vorlagenordner in die einzelnen PCs
	for ordner in *;
	do
		cp -a /netzlaufwerk/Schild-NRW-Reports/"$ordner"/* "$ordner"/;
		# Wegen der Leerzeichen in den Ordnernamen sind die Anführungsstriche nötig
	done
	echo Ende $pc
done
cd ~	# gehe zum Schluss ins Homeverzeichnis