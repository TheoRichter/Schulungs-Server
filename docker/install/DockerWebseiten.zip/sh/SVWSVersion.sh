#!/bin/bash
#
AlteSVWSVersion=""
#####################################################################
cd /var/www/html/sh                                               ###
#####################################################################
### schulungen.txt sichern                                        ###
cp schulungen.txt schulungenOLD.txt                               ###
#####################################################################
cp schulungen.txt /var/www/html/docker                            ###
#####################################################################
### SVWS-Version einmalig in tools.sqlite eintragen               ###
#####################################################################
DB="/var/www/html/sqlite/tools.sqlite"

SVWSVersion=$(awk -F ':' 'NR==1 {print $8}' schulungen.txt)

sqlite3 "$DB" <<EOF
UPDATE svws
SET Installiert = '$SVWSVersion';
EOF

echo "SVWS-Version in tools.sqlite eingetragen: $SVWSVersion"
#####################################################################
while read ZEILE; do                                              ###
  STACK=$(echo $ZEILE | awk -F : '{print $1}')                    ###
  SVWSVersion=$(echo $ZEILE | awk -F : '{print $8}')              ###
#####################################################################
####In die server.json die neue SVWSVersion eintragen             ###
cd /netzlaufwerk/SchILD3                                          ###
sed -i 's/'$AlteSVWSVersion'/'$SVWSVersion'/g' server.json        ###
chmod -R 777 /netzlaufwerk/SchILD3/server.json                    ###
chown -R www-data:www-data /netzlaufwerk/SchILD3/server.json      ###
#####################################################################
  cd /var/www/html/docker/$STACK/$STACK                           ###
  cp docker-compose-svws.yml docker-compose.yml                   ###
### SVWSVersion #####################################################
sed -i 's/'svwslatest'/'$SVWSVersion'/g' docker-compose.yml       ###
#####################################################################
### Docker Container Einspielen #####################################
docker compose up -d                                              ###
#####################################################################
done  < schulungen.txt                                            ###
#####################################################################
#####################################################################
## DatenbankSchemata auf NeueVersion updaten                      ###
#####################################################################
# Neu DatenbankSchemata einspielen                                ###
cd /var/www/html/sh                                               ###
#####################################################################
ANZAHL="14"
#####################################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
#
echo
echo -e -n "${WEISS}### Starten der Docker-Container ${GELB}$STACK-mariadb-1 ${WEISS}und ${GELB}$STACK-svws-server-1 ${WEISS}### ${NC}" 
echo
docker start $STACK-mariadb-1
docker start $STACK-svws-server-1
done < schulungen.txt
#
echo
echo -e -n "${HELLGRUEN} OK ${NC}" 
echo
################################################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
  MariaDBPort=$(echo $ZEILE | awk -F : '{print $2}')
  WebServerPortHTTP=$(echo $ZEILE | awk -F : '{print $3}')
  WebServerPortHTTPS=$(echo $ZEILE | awk -F : '{print $4}')
  WebServerName=$(echo $ZEILE | awk -F : '{print $5}')
  SVWSPort=$(echo $ZEILE | awk -F : '{print $6}')
  MariaDB_ROOT_PASSWORD=$(echo $ZEILE | awk -F : '{print $7}')
  SVWSVersion=$(echo $ZEILE | awk -F : '{print $8}')
  SERVERNAME=$(echo $ZEILE | awk -F : '{print $9}')
  Pfad=$(echo $ZEILE | awk -F : '{print $10}') 
########################################################################################################################################################################################
### ANFANG der for schleife #######################################################################################################################################
###################################################################################################################################################################
  for (( i=1; i<=$ANZAHL; i++ ))
  do
 if [[ "$i" == "1" ]]; then
   ############################################################################
   ### Angelegt der SQLITE DatenbankSchemata fuer die Schulform: Gymnasium  ###
   ############################################################################
   SCHULFORM="Gymnasium"
   DB_NAME=GOSt_DB-1_VorbereitungEFPlanung
   DB_USER=$DB_NAME
   DB_MYSQL_PW=$DB_NAME
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$DB_NAME.sqlite
  fi
  if [[ "$i" == "2" ]]; then
   ############################################################################
   ### Angelegt der SQLITE DatenbankSchemata fuer die Schulform: Gymnasium  ###
   ############################################################################
   SCHULFORM="Gymnasium"
   DB_NAME=GOSt_DB-2_Laufbahnen10EF-zumBlocken
   DB_USER=$DB_NAME
   DB_MYSQL_PW=$DB_NAME
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$DB_NAME.sqlite
  fi
  if [[ "$i" == "3" ]]; then
   ############################################################################
   ### Angelegt der SQLITE DatenbankScehemata fuer die Schulform: Gymnasium ###
   ############################################################################
   SCHULFORM="Gymnasium"
   DB_NAME=GOSt_DB-3_Blockungen10EFmitFehlern
   DB_USER=$DB_NAME
   DB_MYSQL_PW=$DB_NAME
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$DB_NAME.sqlite
  fi
  if [[ "$i" == "4" ]]; then
   ############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: Gymnasium ###
   ############################################################################
   SCHULFORM="Gymnasium"
   DB_NAME=GOSt_DB-4-KlausurplanungEF2
   DB_USER=$DB_NAME
   DB_MYSQL_PW=$DB_NAME
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$DB_NAME.sqlite
 fi
 if [[ "$i" == "5" ]]; then
   ###############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: Gesamtschule ###
   ###############################################################################
   SCHULFORM="Gesamtschule"
   DB_NAME=$SCHULFORM
   DB_USER=$SCHULFORM
   DB_MYSQL_PW=$SCHULFORM
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$SCHULFORM.sqlite
  fi
  if [[ "$i" == "6" ]]; then
   ##############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: Grundschule ###
   ##############################################################################
   SCHULFORM="Grundschule"
   DB_NAME=$SCHULFORM
   DB_USER=$SCHULFORM
   DB_MYSQL_PW=$SCHULFORM
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$SCHULFORM.sqlite
  fi
  if [[ "$i" == "7" ]]; then
   ##############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: ENM01       ###
   ##############################################################################
   DB_NAME=ENM_SVWS
   DB_USER=$DB_NAME
   DB_MYSQL_PW=$DB_NAME
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/ENM-Json/ENM-Testdaten-01/$DB_NAME.sqlite
  fi
  if [[ "$i" == "8" ]]; then
   ###############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: Berufschule  ###
   ###############################################################################
   SCHULFORM="Berufschule"
   DB_NAME=$SCHULFORM
   DB_USER=$SCHULFORM
   DB_MYSQL_PW=$SCHULFORM
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$SCHULFORM.sqlite
  fi
  if [[ "$i" == "9" ]]; then
   ###############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: S1Schulung   ###
   ###############################################################################
   SCHULFORM="S1Schulung"
   DB_NAME=$SCHULFORM
   DB_USER=$SCHULFORM
   DB_MYSQL_PW=$SCHULFORM
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$SCHULFORM.sqlite
  fi
  if [[ "$i" == "10" ]]; then
   ###############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: S2Schulung   ###
   ###############################################################################
   SCHULFORM="S2Schulung"
   DB_NAME=$SCHULFORM
   DB_USER=$SCHULFORM
   DB_MYSQL_PW=$SCHULFORM
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$SCHULFORM.sqlite
  fi
  if [[ "$i" == "11" ]]; then
   ##############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: Grundschule_1Hj ###
   ##############################################################################
   SCHULFORM="Grundschule"
   DB_NAME=Grundschule_1Hj
   DB_USER=$DB_NAME
   DB_MYSQL_PW=$DB_NAME
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$DB_NAME.sqlite
  fi
  if [[ "$i" == "12" ]]; then
   ##############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: Grundschule_2Hj ###
   ##############################################################################
   SCHULFORM="Grundschule"
   DB_NAME=Grundschule_2Hj
   DB_USER=$DB_NAME
   DB_MYSQL_PW=$DB_NAME
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$DB_NAME.sqlite
  fi
  if [[ "$i" == "13" ]]; then
   ##############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: Grundschule_1HjLeistungsdaten ###
   ##############################################################################
   SCHULFORM="Grundschule"
   DB_NAME=Grundschule_1HjLeistungsdaten
   DB_USER=DB_NAME
   DB_MYSQL_PW=DB_NAME
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$DB_NAME.sqlite
  fi
  if [[ "$i" == "14" ]]; then
   ##############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: Grundschule_2HjLeistungsdaten ###
   ##############################################################################
   SCHULFORM="Grundschule"
   DB_NAME=Grundschule_2HjLeistungsdaten
   DB_USER=$DB_NAME
   DB_MYSQL_PW=$DB_NAME
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$DB_NAME.sqlite
  fi
  echo
  echo -e -n "${HELLROT}###!?!?!ACHTUNG DAS DAUERT JETZT ETWAS!?!?!###${WEISS}###!?!?!ACHTUNG DAS DAUERT JETZT ETWAS!?!?!###${HELLROT}###!?!?!ACHTUNG DAS DAUERT JETZT ETWAS!?!?!### ${NC}"
  echo
  echo -e -n "${WEISS}### ${TUERKIS}Anlegen des DatenbankSchemata Nummer: ${GELB}$i ${TUERKIS}von ${GELB}$ANZAHL ${TUERKIS}mit dem Namen: ${GELB}${DB_NAME} ${TUERKIS}im Docker-Container: ${GELB}$STACK ${WEISS}### ${NC}"
  echo
  sleep 4
  echo
    curl --user "root:${MariaDB_ROOT_PASSWORD}" \
     -k --insecure \
     -X "POST" "https://${SERVERNAME}:${SVWSPort}/api/schema/root/import/sqlite/${DB_NAME}" \
     -H "accept: application/json" \
     -H "Content-Type: multipart/form-data" \
     -F "database=@${DB_PATH}" \
     -F "schemaUsername=${DB_USER}" \
     -F "schemaUserPassword=${DB_MYSQL_PW}" 
  clear
  done
###################################################################################################################################################################
### ENDE der for schleife #########################################################################################################################################
###################################################################################################################################################################
echo
echo -e -n "${WEISS}### Stoppen der docker-container ${GELB}$STACK-mariadb-1 ${WEISS}und ${GELB}$STACK-svws-server-1 ${WEISS}### ${NC}" 
echo
    docker stop $STACK-mariadb-1
    docker stop $STACK-svws-server-1 
echo
echo -e -n " ${HELLGRUEN}OK ${NC}"
echo
#
done < schulungen.txt
#
##########################################################################################################################################
# Container neu starten
cd /var/www/html/sh
######################################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
#
echo
echo -e -n "${WEISS}### Starten der Docker-Container ${GELB}$STACK-mariadb-1 ${WEISS}und ${GELB}$STACK-svws-server-1 ${WEISS}### ${NC}" 
echo
docker start $STACK-mariadb-1
docker start $STACK-svws-server-1
done < schulungen.txt
#
echo
echo -e -n "${HELLGRUEN} OK ${NC}" 
echo
#############################################################################################################################################
echo
echo -e -n "${WEISS}### ${GELB}Alle DatenbankSchemata eingeplegt. ${WEISS}### ${NC}" 
echo
