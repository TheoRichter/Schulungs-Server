#!/bin/bash
#
ANZAHL="1"
################################################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
#
echo
echo -e -n "${WEISS}### Starten der Docker-Container ${GELB}$STACK-mariadb-1 ${WEISS}und ${GELB}$STACK-svws-server-1 ${WEISS}### ${NC}" 
echo
  docker start $STACK-mariadb-1
  docker start $STACK-svws-server-1
#
done < schulungen.txt
echo
echo -e -n "${HELLGRUEN} OK ${NC}" 
echo
################################################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
  MariaDBPort=$(echo $ZEILE | awk -F : '{print $2}')
  WebServerPortHTTP=$(echo $ZEILE | awk -F : '{print $3}')
  WebServerPortHTTPS=$(echo $ZEILE | awk -F : '{print $4}')
  WebServerName=$(echo $ZEILE | awk -F : '{print $5}')
  SVWSPort=$(echo $ZEILE | awk -F : '{print $6}')
  MariaDB_ROOT_PASSWORD=$(echo $ZEILE | awk -F : '{print $7}')
  SVWSVersion=$(echo $ZEILE | awk -F : '{print $8}')
  SERVERNAME=$(echo $ZEILE | awk -F : '{print $9}')
  Pfad=$(echo $ZEILE | awk -F : '{print $10}') 
###################################################################################################################################################################
### ANFANG der for schleife #######################################################################################################################################
###################################################################################################################################################################
  for (( i=1; i<=$ANZAHL; i++ ))
  do
  if [[ "$i" == "1" ]]; then
   ###############################################################################
   ### Angelegt der SQLITE Datenbankscehemata fuer die Schulform: S2Schulung   ###
   ###############################################################################
   SCHULFORM="S2Schulung"
   DB_NAME=$SCHULFORM
   DB_USER=$SCHULFORM
   DB_MYSQL_PW=$SCHULFORM
   # SQLITE DatenbankPfad
   DB_PATH=/$Pfad/OfficelleTestDBS/$SCHULFORM/$SCHULFORM.sqlite
  fi
  echo
  echo -e -n "${HELLROT}###!?!?!ACHTUNG DAS DAUERT JETZT ETWAS!?!?!###${WEISS}###!?!?!ACHTUNG DAS DAUERT JETZT ETWAS!?!?!###${HELLROT}###!?!?!ACHTUNG DAS DAUERT JETZT ETWAS!?!?!### ${NC}"
  echo
  echo -e -n "${WEISS}### ${TUERKIS}Anlegen des DatenbankSchemata Nummer: ${GELB}$i ${TUERKIS}von ${GELB}$ANZAHL ${TUERKIS}mit dem Namen: ${GELB}${DB_NAME} ${TUERKIS}im Docker-Container: ${GELB}$STACK ${WEISS}### ${NC}"
  echo
echo
   curl --user "root:${MariaDB_ROOT_PASSWORD}" \
    -k -X "POST" "https://${SERVERNAME}:${SVWSPort}/api/schema/root/destroy/${DB_NAME}" \
    -H "accept: application/json"
echo
   curl --user "root:${MariaDB_ROOT_PASSWORD}" \
    -k --insecure \
    -X "POST" "https://${SERVERNAME}:${SVWSPort}/api/schema/root/import/sqlite/${DB_NAME}" \
    -H "accept: application/json" \
    -H "Content-Type: multipart/form-data" \
    -F "database=@${DB_PATH}" \
    -F "schemaUsername=${DB_USER}" \
    -F "schemaUserPassword=${DB_MYSQL_PW}" 
  clear
  done
###################################################################################################################################################################
### ENDE der for schleife #########################################################################################################################################
###################################################################################################################################################################
###################################################################################################################################################################
#docker exec $STACK-svws-server-1 /bin/sh -c 'sed -i 's/stable/alpha/g' /opt/app/svws/conf/svwsconfig.json'
#docker exec $STACK-mariadb-1 /bin/sh -c 'sed -i 's/#bind-address/bind-address/g' /etc/mysql/mariadb.conf.d/50-server.cnf'
#docker exec $STACK-mariadb-1 /bin/sh -c 'sed -i 's/127.0.0.1/0.0.0.0/g' /etc/mysql/mariadb.conf.d/50-server.cnf'
###################################################################################################################################################################
echo
echo -e -n "${WEISS}### Stoppen der docker-container ${GELB}$STACK-mariadb-1 ${WEISS}und ${GELB}$STACK-svws-server-1 ${WEISS}### ${NC}" 
echo
docker stop $STACK-mariadb-1
docker stop $STACK-svws-server-1 
#
done < schulungen.txt
######################################################################
# Container neu starten
cd /var/www/html/sh
######################################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
#
echo
echo -e -n "${WEISS}### Starten der Docker-Container ${GELB}$STACK-mariadb-1 ${WEISS}und ${GELB}$STACK-svws-server-1 ${WEISS}### ${NC}" 
echo
  docker start $STACK-mariadb-1
  docker start $STACK-svws-server-1  
  docker start $STACK-Webserver
#
done < schulungen.txt
#######################################################################
echo
echo -e -n "${HELLGRUEN} OK ${NC}" 
echo
########################################################################
echo
echo "#########################################################################################"
echo "### DatenbankSchemata: $SCHULFORM wurden eingeplegt und die Container neu gestart!!   ###" 
echo "#########################################################################################"
