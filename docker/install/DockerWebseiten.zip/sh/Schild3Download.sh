#/!/bin/bash
SCHILD_VERSIONSNR="3.1.14"
cd /var/www/html/zip
wget -q --show-progress https://github.com/SVWS-NRW/Schild3-BetaTest/releases/download/v$SCHILD_VERSIONSNR/Setup_SchILD3_v$SCHILD_VERSIONSNR.zip
mv Setup_SchILD3_v$SCHILD_VERSIONSNR.zip /netzlaufwerk/installationfiles/Setup_SchILD3_v$SCHILD_VERSIONSNR.zip
unzip -u -o /netzlaufwerk/installationfiles/Setup_SchILD3_v$SCHILD_VERSIONSNR.zip -d /netzlaufwerk/SchILD3/
chmod -R 777 /netzlaufwerk/SchILD3
chown -R www-data:www-data /netzlaufwerk/SchILD3
