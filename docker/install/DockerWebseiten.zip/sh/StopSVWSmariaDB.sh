#!/bin/bash
STACK=""
################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
docker stop $STACK-mariadb-1
docker stop $STACK-svws-server-1
done < schulungen.txt
