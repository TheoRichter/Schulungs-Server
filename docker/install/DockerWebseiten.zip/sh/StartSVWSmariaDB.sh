#!/bin/bash
STACK=""
###############################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
   docker start $STACK-mariadb-1
   docker start $STACK-svws-server-1
done < schulungen.txt