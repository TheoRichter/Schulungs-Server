#!/bin/bash
#
################################################################################################################################
cd /var/www/html/sh                                                                                                          ###
################################################################################################################################    
while read ZEILE; do                                                                                                         ###
  STACK=$(echo $ZEILE | awk -F : '{print $1}')                                                                               ###
#
  cd /var/www/html/docker/$STACK/$STACK                                                                                      ###
  cp docker-compose-wenom.yml docker-compose.yml                                                                             ###
  rm -rf tools/laufbahn                                                                                                      ###
  rm -rf www/wenom                                                                                                           ###
  mkdir tools/laufbahn                                                                                                       ###
  mkdir www/wenom                                                                                                            ###
  cp /var/www/html/zip/enmserver.zip /var/www/html/docker/$STACK/$STACK/www/wenom/enmserver.zip                              ###
  cd /var/www/html/docker/$STACK/$STACK/www/wenom                                                                            ###
  unzip enmserver.zip                                                                                                        ###
  rm enmserver.zip                                                                                                           ###
  cp /root/$STACK/www/wenom/db/app.sqlite /var/www/html/docker/$STACK/$STACK/www/wenom/db/app.sqlite                         ###
  cp /root/$STACK/www/wenom/db/client.sec /var/www/html/docker/$STACK/$STACK/www/wenom/db/client.sec                         ### 
  cp /var/www/html/zip/laufbahnplanung.zip /var/www/html/docker/$STACK/$STACK/tools/laufbahn/laufbahnplanung.zip             ###
  cd /var/www/html/docker/$STACK/$STACK/tools/laufbahn/                                                                      ###
  unzip laufbahnplanung.zip                                                                                                  ###
  rm laufbahnplanung.zip                                                                                                     ###
################################################################################################################################
docker compose up -d                                                                                                         ###
################################################################################################################################
cd /tmp                                                                                                                      ###
docker exec $STACK-Webserver /bin/sh -c 'chmod -R 777 /var/www/wenom/db'                                                     ###
docker exec $STACK-Webserver /bin/sh -c 'chown -R www-data:www-data /var/www'                                                ###
docker stop $STACK-Webserver                                                                                                 ### 
################################################################################################################################
done  < schulungen.txt                                                                                                       ###
################################################################################################################################  
rm /var/www/html/zip/enmserver.zip                                                                                           ###
rm /var/www/html/zip/laufbahnplanung.zip                                                                                     ###
################################################################################################################################
######################################################################
# Container neu starten
cd /var/www/html/sh
######################################################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
#
  docker start $STACK-Webserver
done < schulungen.txt
#######################################################################
echo
echo "######################################################"
echo "### Wenom upgedatet und Container neu gestartet!!  ###" 
echo "######################################################"
