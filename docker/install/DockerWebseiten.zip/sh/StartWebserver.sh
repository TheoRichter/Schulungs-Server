#!/bin/bash
STACK=""
###############################################
while read ZEILE; do
  STACK=$(echo $ZEILE | awk -F : '{print $1}')
   docker start $STACK-Webserver
done < schulungen.txt