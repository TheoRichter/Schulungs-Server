<?php
session_start();
if (!isset($_SESSION['benutzer'])) {
    header("Location: inc/login/login.php");
    exit;
}
?>
<html>
<head>
 <title>Container-Status</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row w3-indigo">
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">
   <ul class="nav navbar-nav">
    <li class="active"><a href="container-status.php"><span class="label label-danger">Status/Link</span></a></li>
    <li><a href="index.php"><span class="label label-default">SVWS-Schemata-Update</span></a></li>
    <li><a href="svws-versions-update.php"><span class="label label-default">SVWS-Versions-Update</span></a></li>
    <li><a href="svws-tools-update.php"><span class="label label-default">SVWS-Tools-Update</span></a></li>
    <li><a href="schild3.php"><span class="label label-default">SchILD-NRW-3</span></a></li>
   </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
  </div>
 </nav>
</div>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:20%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:60%">
  <table class="w3-table w3-border" border="0">
   <tr class="">
    <td class="w3-border w3-center">STACK</td>
    <td class="w3-border w3-center">SVWS-Tools</td>
    <td colspan="2" class="w3-border w3-center">SVWS-Status</td>
    <td colspan="2" class="w3-border w3-center">MariaDB-Status</td>
    <td colspan="2" class="w3-border w3-center">WeNoM-Status</td>
   </tr>
<!-- ANFANG PCs -->
<?php include "inc/status-links/pcs.inc.php";  ?>
<!--- ENDE PCs  -->
 </table>
 <br />
 </div>
 <div class="w3-col w3-container" style="width:20%">
  <p> </p>
 </div>
</div>
<!--#################### ANFANG FOOTER##############################################################################################################-->
<section id="footer"><!-- Anfang Footer -->
<?php include 'inc/footer/footer.php' ?>
</section><!-- Ende Footer -->
<!--#################### ENDE FOOTER##############################################################################################################-->
</body>
</html>