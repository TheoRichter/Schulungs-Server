<html>
<head>
 <title>Docker compose Updaten</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/form.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <style>
  .form.w3-arial-gruen {
    background-color: green;
    color: white;
  }

  .form.w3-arial-gray {
    background-color: gray;
    color: white;
  }

  .gruenerrand {
    background-color: lightgreen;
    padding: 10px;
    display: inline-block;
  }

  .gruenerrand input {
    background-color: lightgreen;
    padding: 5px;
  }
  </style>
 </head>
<body>
<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $alt = trim($_POST["alt"] ?? "");
    $neu = trim($_POST["neu"] ?? "");

    $dateipfad = __DIR__ . "/sh/schulungen.txt";
    $svwsDateipfad = __DIR__ . "/sh/SVWSVersion.sh";

    if ($alt !== "" && $neu !== "") {

        // 1. Version in schulungen.txt ersetzen
        if (is_file($dateipfad) && is_writable($dateipfad)) {

            $inhalt = file_get_contents($dateipfad);
            $inhaltNeu = str_replace($alt, $neu, $inhalt);

            file_put_contents($dateipfad, $inhaltNeu);

        } else {
            die("Fehler: schulungen.txt ist nicht vorhanden oder nicht beschreibbar.");
        }

        // 2. Variable AlteSVWSVersion in SVWSVersion.sh ersetzen
        if (is_file($svwsDateipfad) && is_writable($svwsDateipfad)) {

            $inhaltSVWS = file_get_contents($svwsDateipfad);

            $inhaltSVWSNeu = preg_replace(
                '/^(\s*AlteSVWSVersion\s*=\s*).*$/m',
                '${1}' . $neu,
                $inhaltSVWS
            );

            if ($inhaltSVWSNeu === null) {
                die("Fehler beim Bearbeiten von SVWSVersion.sh.");
            }

            if ($inhaltSVWSNeu === $inhaltSVWS) {
                die("Fehler: Variable AlteSVWSVersion wurde nicht gefunden.");
            }

            file_put_contents($svwsDateipfad, $inhaltSVWSNeu);

        } else {
            die("Fehler: SVWSVersion.sh ist nicht vorhanden oder nicht beschreibbar.");
        }

        echo "<p class='echo'>"
           . "Die SVWS-Version wurde in beiden Dateien aktualisiert."
           . "</p>";

        include "close.php";
        exit;

    } else {
         echo "<p class='echo'>Bitte beide Felder ausfüllen.</p>";
    }
}
?>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <form method="post">
   <div class="">
   <label class="form w3-arial-gray" for="alt">Die&nbsp;<b>installierte</b>&nbsp;&nbsp;SVWS-Versions-Nummer&nbsp;Eintragen:</label>
   <input type="text" name="alt" value="" placeholder="z.B. 1.4.1">
   </div>
   <br><br>
   <label class="form w3-arial-gruen" for="neu">Die&nbsp;<b>aktuelle</b>&nbsp;SVWS-Versions-Nummer&nbsp;Eintragen:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
   <input type="text" name="neu" value="" placeholder="z.B. 1.5.1"><br><br>
   <button type="submit">weiter</button>
  </form>
 </div>
</div> 
</body>
</html>