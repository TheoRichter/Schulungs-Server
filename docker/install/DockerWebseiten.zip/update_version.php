<?php
$skriptDatei = "sh/SVWSVersion.sh";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $neueVersion = trim($_POST["version"] ?? "");

    if (preg_match('/^\d+\.\d+\.\d+$/', $neueVersion)) {
        // Lade Datei
        $inhalt = file_get_contents($skriptDatei);

        // Ersetze die Zeile mit AlteSVWSVersion
        $inhaltNeu = preg_replace(
            '/^AlteSVWSVersion="[^"]*"/m',
            'AlteSVWSVersion="' . $neueVersion . '"',
            $inhalt
        );

        // Schreibe Datei zurück
        file_put_contents($skriptDatei, $inhaltNeu);
        echo "<p>Version erfolgreich auf <strong>$neueVersion</strong> aktualisiert.</p>";
        include "close.php";
        exit;		
    } else {
		if (isset($neueVersion) && !empty($neueVersion)) {
         echo "<p style='color:red;'>Ungültiges Versionsformat. Bitte z.B. 1.4.1 eingeben.</p>";
		}
    }
}
?>
<html>
<head>
 <title>Update des SVWS-Servers</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

iframe {
  border-radius: 5px;
  background-color: #f2f2f2;
}

label {
  background-color: yellow;
  color: black;
  padding: 8px;
}

</style>
  </head>
<body>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <iframe src="docker-compose-yml.php" width="98%" height="80" frameborder="0" style="background-color:"></iframe>
 </div>
</div>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
   <form class="form" method="post">
    <input type="text" name="version" id="version" placeholder="Hier die Zahl hinter image: svwsnrw/svws-server:1.4.1 Eingeben.">
    <button type="submit">weiter</button>
  </form>
 </div>
</div>
</body>
</html>
