<?php
session_start();
include '../inc/conf/config.inc.php';
if (!isset($_SESSION['benutzer'])) {
    header("Location: ../inc/login/login.php");
    exit;
}
?>
<html>
<head>
 <title>SVWS-Schemata-Erneuern</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/eigene.css">
  <link rel="stylesheet" href="../css/w3.css">
  <link rel="shortcut icon" href="../ico/favicon.png">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row w3-indigo">
<!--
 <div class="w3-container w3-threequarter w3-padding-16">
   <h1>
    <a href="https://<?php echo "$LOCALEIP"; ?>:9443" target="_blank">
     <img src="::/png/portainer.png" class="w3-round" alt="portainer.io" width="350">
   </a>

   <button class="w3-tooltip" onclick="window.open('https://<?php echo "$LOCALEIP"; ?>:4200', '_blank', 'width=800,height=600')">
     <span style="position:absolute;left:100px;bottom:0" class="w3-text w3-tag">ROOT CONSOLE</span>
	 <img src="../png/terminal.png" class="w3-round" alt="Terminal" width="80" height="80">
   </button> 
  </h1> 
 </div>
 <div class="w3-container w3-quarter w3-right-align w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="../png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
 -->
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="../png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
 <nav class="navbar navbar-inverse" style="border-radius: 0";>
  <div class="container-fluid">
   <ul class="nav navbar-nav">
    <li class="active"><a href="Schemata.php"><span class="label label-danger">Schuljahr-Erhöhen</span></a></li>
    <li><a href="../index.php"><span class="label label-default">SVWS-Schemata-Update</span></a></li>
    <li><a href="../svws-versions-update.php"><span class="label label-default">SVWS-Versions-Update</span></a></li>
    <li><a href="../wenom-versions-update.php"><span class="label label-default">WENOM-Versions-Update</span></a></li>
<!--     <li><a href="../schemata.php"><span class="label label-default">Schemata-Releases-Update</span></a></li> -->
    <li><a href="../schild3.php"><span class="label label-default">SchILD3-Update</span></a></li>
    <li><a href="../container-status.php"><span class="label label-default">Status / Links</span></a></li>
   </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="../inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
  </div>
 </nav>
</div>
<section id="header"><!-- Anfang Header -->
 <?php include '../inc/header/admin.php'; ?>
</section><!-- Ende Header -->
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-xlarge w3-arial" >Jahreszahlen der Schemata um ein Jahr erhöhen.</label>
  <form id="scriptSchemata" method="post" target="outputWindow" action="schuljahr-erhoehung.php">
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="AlleDatenbankSchemata">Alle Schemata werden in das neu Schuljahr gesetzt.</label>&nbsp;<button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="AlleDatenbankSchemata" name="AlleDatenbankSchemata" value="AlleDatenbankSchemata"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Alle Schemata</button><br />
  </form>
 <br /> 
 </div>
</div>
<!-- ### Anfang java Script -->
<script>
  let linkesFenster = null;
  let rechtesFenster = null;
  let checkIntervall = null;
//#######################################################################################################################################################
  document.getElementById('scriptSchemata').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      /////window.open('', 'outputWindow', 'width=600,height=400');
    // Fenstergrößen definieren
    const breiteLinks = 800;
    const hoeheLinks = 600;
    const breiteRechts = 350;
    const hoeheRechts = 160;

    // Positionen berechnen
    const posLinksX = 0;
    const posLinksY = 0;
    const posRechtsX = breiteLinks; // direkt daneben
    const posRechtsY = 0;

    // Linkes Fenster öffnen (Formularziel)
    linkesFenster = window.open('', 'outputWindow',
      `width=${breiteLinks},height=${hoeheLinks},left=${posLinksX},top=${posLinksY}`);

    // Rechtes Fenster öffnen (Hinweis)
    rechtesFenster = window.open('', 'geduldHinweis',
      `width=${breiteRechts},height=${hoeheRechts},left=${posRechtsX},top=${posRechtsY}`);
    
    // Inhalt in Hinweisfenster schreiben
    rechtesFenster.document.write(`
      <html>
        <head><title>Hinweis</title></head>
        <body style='font-family:sans-serif; text-align:center; padding:20px; color:blue;'>
          <h2>Das dauert jetzt etwas!!</h2>
	      <img src="gif/Sanduhr.gif" alt="Bitte warten..." width="48" height="48">
        </body>
      </html>
    `);
    rechtesFenster.document.close();

    // Gegenseitige Überwachung
    if (checkIntervall) clearInterval(checkIntervall);
    checkIntervall = setInterval(() => {
      if (linkesFenster.closed || rechtesFenster.closed) {
        if (linkesFenster && !linkesFenster.closed) linkesFenster.close();
        if (rechtesFenster && !rechtesFenster.closed) rechtesFenster.close();
        clearInterval(checkIntervall);
      }
    }, 500);
  });
</script>
 <!-- ### ENDE java Script -->
</body>
</html>
