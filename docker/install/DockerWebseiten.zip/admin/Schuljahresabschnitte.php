<?php
session_start();
include '../inc/conf/config.inc.php';
if (!isset($_SESSION['benutzer'])) {
    header("Location: ../inc/login/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Schuljahresabschnitte</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/eigene.css">
  <link rel="stylesheet" href="../css/w3.css">
  <link rel="shortcut icon" href="../ico/favicon.png">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row w3-indigo">
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="../png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
 <nav class="navbar navbar-inverse" style="border-radius: 0";>
  <div class="container-fluid">
   <ul class="nav navbar-nav">
    <li class="active"><a href="Schemata.php"><span class="label label-danger">Schuljahr-Erhöhen</span></a></li>
    <li><a href="../index.php"><span class="label label-default">SVWS-Schemata-Update</span></a></li>
    <li><a href="../svws-versions-update.php"><span class="label label-default">SVWS-Versions-Update</span></a></li>
    <li><a href="../wenom-versions-update.php"><span class="label label-default">WENOM-Versions-Update</span></a></li>
<!--     <li><a href="../schemata.php"><span class="label label-default">Schemata-Releases-Update</span></a></li> -->
    <li><a href="../schild3.php"><span class="label label-default">SchILD-NRW-3</span></a></li>
    <li><a href="../container-status.php"><span class="label label-default">Status / Links</span></a></li>
   </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="../inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
  </div>
 </nav>
</div>
<section id="header"><!-- Anfang Header -->
 <?php include '../inc/header/admin.php'; ?>
</section><!-- Ende Header -->
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
<div class="w3-col w3-container" style="width:98%">
<hr class="schuljahr" />
<?php
// Fehleranzeige aktivieren (für Tests)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Liste erlaubter Datenbanken (Whitelist zur Sicherheit)
// wird ueber den include '../inc/conf/config.inc.php'; eingebuden

// Gewählte Schule ermitteln
$schule = $_GET['schule'] ?? 'Grundschule';
$dbPath = $datenbanken[$schule] ?? null;

if (!$dbPath || !file_exists($dbPath)) {
    die("Ungültige oder fehlende Datenbank: $schule");
}

// Verbindung zur SQLite-Datenbank
$db = new SQLite3($dbPath);

// 📆 Geburtstage ändern
if (isset($_POST['jahr_plus_eins'])) {
    $db->exec("UPDATE Schuljahresabschnitte SET Jahr = Jahr + 1");
    echo "<p style='color: green;'>Alle Schuljahresabschnitte wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['jahr_minus_eins'])) {
    $db->exec("UPDATE Schuljahresabschnitte SET Jahr = Jahr - 1");
    echo "<p style='color: orange;'>Alle Schuljahresabschnitte wurden um 1 Jahr verringert.</p>";
}

// ID des Schülers, den du anzeigen möchtest (hier fest auf 1 gesetzt)
$ID = 1;
// SQL-Abfrage mit JOIN
$sql = "
SELECT 
    EigeneSchule.Schuljahresabschnitts_ID,
    Schuljahresabschnitte.ID,
    Schuljahresabschnitte.Jahr
FROM 
    EigeneSchule
JOIN 
    Schuljahresabschnitte ON EigeneSchule.Schuljahresabschnitts_ID = Schuljahresabschnitte.ID
WHERE 
    EigeneSchule.ID = :id
";

// Abfrage vorbereiten
$stmt = $db->prepare($sql);
$stmt->bindValue(':id', $ID, SQLITE3_INTEGER);

// Ausführen und Ergebnis holen
$result = $stmt->execute();
$row = $result->fetchArray(SQLITE3_ASSOC);

// Ausgabe
if ($row) {
    echo "<div class='w3-panel w3-leftbar w3-rightbar w3-khaki w3-xlarge w3-arial w3-center'>Das Datenbankschemata  <b>$schule</b> befindet sich im Schuljahr <b>" . htmlspecialchars($row['Jahr']) . "</b></div>";
} else {
    echo "Kein Schüler mit ID $ID gefunden.";
}
// Daten abrufen
$result = $db->query("SELECT * FROM Schuljahresabschnitte ORDER BY ID ASC");
?>
<hr class="schuljahr" />

<label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-xlarge w3-arial">Schuljahresabschnitte &ndash; <?= htmlspecialchars($schule) ?></label>

<form method="GET">
    <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial">Schule wählen:</label>
    <select name="schule" onchange="this.form.submit()">
        <?php foreach ($datenbanken as $name => $pfad): ?>
            <option value="<?= $name ?>" <?= $schule == $name ? 'selected' : '' ?>><?= $name ?></option>
        <?php endforeach; ?>
    </select>
</form>

<h3>Schuljahresabschnitteliste </h3>
<table border="1" cellpadding="5" cellspacing="0">
<form method="POST" style="margin-top:10px;">
<tr>
 <th style='text-align: center; vertical-align: middle; font-size: 11px; padding: 2px 4px;' >ID</th>
 <th>
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="jahr_plus_eins" value="Schuljahresabschnitte +1 Jahr" onclick="return confirm('Wirklich alle Schuljahresabschnitte um 1 Jahr erhöhen?');"><br />
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="jahr_minus_eins" value="Schuljahresabschnitte -1 Jahr " onclick="return confirm('Wirklich alle Schuljahresabschnitteum 1 Jahr verringern?');">
 </th>
 <th style='text-align: center; vertical-align: middle; font-size: 11px; padding: 2px 4px;' >Halbjahr</th>
 <th style='text-align: center; vertical-align: middle; font-size: 11px; padding: 2px 4px;' >VorigeHalbjahr_ID</th>
 <th style='text-align: center; vertical-align: middle; font-size: 11px; padding: 2px 4px;' >FolgeHalbjahr_ID</th>
</tr>
</form>
<?php while ($row = $result->fetchArray(SQLITE3_ASSOC)): ?>
<tr style="text-align: center; vertical-align: middle;">
 <td><?= $row['ID'] ?><input type="hidden" name="id" value="<?= $row['ID'] ?>"></td>
 <td><?= $row['Jahr'] ?><input type="hidden" name="geburtsdatum" value="<?= $row['Jahr'] ?>"></td>
 <td><?= $row['Abschnitt'] ?><input type="hidden" name="Abschnitt" value="<?= htmlspecialchars($row['Abschnitt']) ?>"></td>
 <td><?= $row['VorigerAbschnitt_ID'] ?><input type="hidden" name="VorigerAbschnitt_ID" value="<?= htmlspecialchars($row['VorigerAbschnitt_ID']) ?>"></td>
 <td><?= $row['FolgeAbschnitt_ID'] ?><input type="hidden" name="FolgeAbschnitt_ID" value="<?= htmlspecialchars($row['FolgeAbschnitt_ID']) ?>"></td>
</tr>
<?php endwhile; ?>
</table>
 </div>
</div>
</body>
</html>
