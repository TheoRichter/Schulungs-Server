<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Liste erlaubter Datenbanken (Whitelist zur Sicherheit)
$datenbanken = [
    'ENM_SVWS' => '/netzlaufwerk/SVWS-TestMDBs/ENM-Json/ENM-Testdaten-01/ENM_SVWS.sqlite',
    'Gesamtschule' => '/netzlaufwerk/OfficelleTestDBS/Gesamtschule/Gesamtschule.sqlite',
    'Grundschule' => '/netzlaufwerk/OfficelleTestDBS/Grundschule/Grundschule.sqlite',
    'Gymnasium_2HJ'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_2HJ.sqlite',
    'Gymnasium_FaecherSek2'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_FaecherSek2.sqlite',
    'Gymnasium_LaufbahnenJG10'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_LaufbahnenJG10.sqlite',
    'Gymnasium_LaufbahnenJGEF'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_LaufbahnenJGEF.sqlite',
    'Gymnasium_LaufbahnenJGEFMitBlockung'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_LaufbahnenJGEFMitBlockung.sqlite',
    'Gymnasium_LaufbahnenJGEFvollst'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_LaufbahnenJGEFvollst.sqlite'
];

// Gewählte Schule ermitteln
$schule = $_GET['schule'] ?? 'Grundschule';
$dbPath = $datenbanken[$schule] ?? null;

if (!$dbPath || !file_exists($dbPath)) {
    die("Ungültige oder fehlende Datenbank: $schule");
}

// Verbindung zur SQLite-Datenbank
$db = new SQLite3($dbPath);
if (!$db) {
    die("Fehler beim Öffnen der Datenbank.");
}
// ID des Schülers, den du anzeigen möchtest (hier fest auf 1 gesetzt)
$schuelerId = 1;
// SQL-Abfrage mit JOIN
$sql = "
SELECT 
    EigeneSchule.Schuljahresabschnitts_ID,
    Schuljahresabschnitte.ID,
    Schuljahresabschnitte.Jahr
FROM 
    EigeneSchule
JOIN 
    Schuljahresabschnitte ON EigeneSchule.Schuljahresabschnitts_ID = Schuljahresabschnitte.ID
WHERE 
    EigeneSchule.ID = :id
";

// Abfrage vorbereiten
$stmt = $db->prepare($sql);
$stmt->bindValue(':id', $schuelerId, SQLITE3_INTEGER);

// Ausführen und Ergebnis holen
$result = $stmt->execute();
$row = $result->fetchArray(SQLITE3_ASSOC);

// Ausgabe
if ($row) {
    echo "<p>Schuljahr: " . htmlspecialchars($row['Jahr']) . "</p>";
} else {
    echo "Kein Schüler mit ID $schuelerId gefunden.";
}
?>