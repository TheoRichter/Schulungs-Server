<?php
session_start();
include '../inc/conf/config.inc.php'; 
if (!isset($_SESSION['benutzer'])) {
    header("Location: ../inc/login/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Schemata</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/eigene.css">
  <link rel="stylesheet" href="../css/w3.css">
  <link rel="shortcut icon" href="../ico/favicon.png">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row w3-indigo">
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="../png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
 <nav class="navbar navbar-inverse" style="border-radius: 0";>
  <div class="container-fluid">
   <ul class="nav navbar-nav">
<!--    <li class="active"><a href="Schemata.php"><span class="label label-danger">Schuljahr-Erhöhen</span></a></li>
    <li><a href="../index.php"><span class="label label-default">SVWS-Schemata-Update</span></a></li>
    <li><a href="../svws-versions-update.php"><span class="label label-default">SVWS-Versions-Update</span></a></li>
    <li><a href="../wenom-versions-update.php"><span class="label label-default">WENOM-Versions-Update</span></a></li>
     <li><a href="../schemata.php"><span class="label label-default">Schemata-Releases-Update</span></a></li> 
    <li><a href="../schild3.php"><span class="label label-default">SchILD-NRW-3</span></a></li>
    <li><a href="../container-status.php"><span class="label label-default">Status / Links</span></a></li> -->
   </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
<!--    <li class=""><a href="../inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>-->
   </ul>
  </div>
 </nav>
</div>
<section id="header"><!-- Anfang Header -->
 <?php include '../inc/header/admin.php'; ?>
</section><!-- Ende Header -->
<?php
// Fehleranzeige aktivieren (für Tests)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Liste erlaubter Datenbanken (Whitelist zur Sicherheit)
// wird ueber den include '../inc/conf/config.inc.php'; eingebuden

// Gewählte Schule ermitteln
$schule = $_GET['schule'] ?? 'Grundschule';
$dbPath = $datenbanken[$schule] ?? null;

if (!$dbPath || !file_exists($dbPath)) {
    die("Ungültige oder fehlende Datenbank: $schule");
}

// Verbindung zur SQLite-Datenbank
$db = new SQLite3($dbPath);

// Jahreswerte ändern
if (isset($_POST['jahr_plus_eins'])) {
	$db->exec("UPDATE K_Lehrer SET Geburtsdatum = DATE(Geburtsdatum, '+1 year')");
	// Schuljahresabschnitte – Offset-Technik gegen UNIQUE-Konflikte
    	$db->exec("UPDATE Schuljahresabschnitte SET Jahr = Jahr + 1000");
    	$db->exec("UPDATE Schuljahresabschnitte SET Jahr = Jahr - 999");
	$db->exec("UPDATE Schueler SET Geburtsdatum = date(Geburtsdatum, '+1 year')");
	$db->exec("UPDATE Schueler SET Aufnahmedatum = DATE(Aufnahmedatum, '+1 year')");
	$db->exec("UPDATE Schueler SET AnmeldeDatum = DATE(AnmeldeDatum, '+1 year')");
	$db->exec("UPDATE Schueler SET Einschulungsjahr = Einschulungsjahr + 1");
	$db->exec("UPDATE Schueler SET LSSchulEntlassDatum = DATE(LSSchulEntlassDatum, '+1 year')");
	$db->exec("UPDATE Schueler SET Religionsabmeldung = date(Religionsabmeldung, '+1 year') WHERE Religionsabmeldung IS NOT NULL AND Religionsabmeldung != ''");
	$db->exec("UPDATE Schueler SET Religionsanmeldung = date(Religionsanmeldung, '+1 year') WHERE Religionsanmeldung IS NOT NULL AND Religionsanmeldung != ''");
	$db->exec("UPDATE Schueler SET JahrWechsel_SI = JahrWechsel_SI + 1 WHERE JahrWechsel_SI IS NOT NULL");
	$db->exec("UPDATE Schueler SET JahrWechsel_SII = JahrWechsel_SII + 1 WHERE JahrWechsel_SII IS NOT NULL");
	$db->exec("UPDATE Schueler SET JahrZuzug = JahrZuzug + 1 WHERE JahrZuzug IS NOT NULL");
	echo "<div class='w3-row'>";
     echo "<div class='w3-col w3-container' style='width:1%'>";
      echo "<p> </p>";
     echo "</div>";
     echo "<div class='w3-col w3-container' style='width:98%'>";
      echo "<hr class='status' />";
       echo "<div align='center'>";
       echo "<p style='font-size: 30px; padding: 2px 4px; color: green;'>Alle Jahreswerte wurden um 1 Jahr erhöht.</p>";
       echo "<a href='Schemata.php?schule=$schule' class='w3-button w3-yellow w3-large w3-round w3-arial '>Anzeigen</a>";
       echo "</div>";
      echo "<hr class='status' />";
     echo "</div>";
    echo "</div>";
	echo "<script src='../js/schemata.js'></script>";
	exit;
}
if (isset($_POST['jahr_minus_eins'])) {
    $db->exec("UPDATE Schuljahresabschnitte SET Jahr = Jahr - 1");
    echo "<p style='color: orange;'>Alle Jahreswerte wurden um 1 Jahr verringert.</p>";
}



?>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:1%">
  <p> </p>
 </div>
<div class="w3-col w3-container" style="width:98%">
<label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-xlarge w3-arial">Schemata &ndash; <?= htmlspecialchars($schule) ?></label>

<form method="GET">
    <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial">Schule wählen:</label>
    <select name="schule" onchange="this.form.submit()">
        <?php foreach ($datenbanken as $name => $pfad): ?>
            <option value="<?= $name ?>" <?= $schule == $name ? 'selected' : '' ?>><?= $name ?></option>
        <?php endforeach; ?>
    </select>
</form>
<hr class="schuljahr" />
<?php

// ID des Schülers, den du anzeigen möchtest (hier fest auf 1 gesetzt)
$ID = 1;
// SQL-Abfrage mit JOIN
$sql = "
SELECT 
    EigeneSchule.Schuljahresabschnitts_ID,
    Schuljahresabschnitte.ID,
    Schuljahresabschnitte.Jahr
FROM 
    EigeneSchule
JOIN 
    Schuljahresabschnitte ON EigeneSchule.Schuljahresabschnitts_ID = Schuljahresabschnitte.ID
WHERE 
    EigeneSchule.ID = :id
";

// Abfrage vorbereiten
$stmt = $db->prepare($sql);
$stmt->bindValue(':id', $ID, SQLITE3_INTEGER);

// Ausführen und Ergebnis holen
$result = $stmt->execute();
$row = $result->fetchArray(SQLITE3_ASSOC);

// Ausgabe
if ($row) {
    echo "<div class='w3-panel w3-leftbar w3-rightbar w3-khaki w3-xlarge w3-arial w3-center'>Das Datenbankschemata  <b>$schule</b> befindet sich im Schuljahr <b>" . htmlspecialchars($row['Jahr']) . "</b></div>";
} else {
    echo "Kein Eintrag mit ID $ID gefunden.";
}
// Daten abrufen Lehrer
$resultLehrer = $db->query("SELECT * FROM K_Lehrer ORDER BY ID ASC");
// Daten abrufen Schueler
$resultSchueler = $db->query("SELECT * FROM Schueler ORDER BY ID ASC");
// Daten abrufen Schuljahresabschnitte
$resultSchuljahresabschnitte = $db->query("SELECT * FROM Schuljahresabschnitte ORDER BY ID ASC");
?>
<hr class="schuljahr" />
<div align="center">
<form method="POST" style="margin-top:10px; ">
  <input class="w3-button w3-black w3-xlarge w3-round-xxlarge w3-arial"  type="submit" name="jahr_plus_eins" value="Jahreswerte des DatenbankSchemata <?php echo"&lt;$schule&gt;"; ?> um ein Jahr erhöhen." onclick="return confirm('Wirklich alle Schuljahresabschnitte um 1 Jahr erhöhen?');" /><br />
</form>
</div>
<hr class="schuljahr" />
 </div>
</div>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:1%">
  <p> </p>
 </div>
<!-- ANFANG Lehrer Spalte -->
<div class="w3-col w3-container" style="width:30%">
<table border="1" cellpadding="5" cellspacing="0">
<tr>
 <th style='text-align: center; vertical-align: middle; font-size: 20px; padding: 2px 4px;' colspan="4">Lehrer</th>
</tr>
<tr>
 <th style='text-align: center; vertical-align: middle; font-size: 15px; padding: 2px 4px;'>ID</th>
 <th style='text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;'>Vorname</th>
 <th style='text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;'>Nachname</th>
 <th style="text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;">Geburtstag</th>
</tr>
<?php while ($row = $resultLehrer->fetchArray(SQLITE3_ASSOC)): ?>
<tr>
 <td style="text-align: center; vertical-align: middle; font-size: 12px; padding: 1px 2px;"><?= $row['ID'] ?></td>
 <td style='font-size: 15px; padding: 1px 2px;'><?= $row['Vorname'] ?></td>
 <td style='font-size: 15px; padding: 1px 2px;'><?= $row['Nachname'] ?></td>
 <td style='font-size: 15px; padding: 1px 2px;'><?php $Geburtsdatum=explode("-",$row['Geburtsdatum']); echo"$Geburtsdatum[2].$Geburtsdatum[1].$Geburtsdatum[0]"; ?></td>
</tr>
<?php endwhile; ?>
</table>
 </div>
<!-- ENDE Lehrer Spalte -->
<!-- ANFANG Schueler Spalte -->
<div class="w3-col w3-container" style="width:40%">
<table class="w3-table" style="width: 250px" border="1">
<!-- Buttons: Jahr ändern + Export -->
<tr>
 <th style='text-align: center; vertical-align: middle; font-size: 20px; padding: 2px 4px;' colspan="4">Schüler</th>
</tr>
<tr>
 <th style="text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;">ID</th>
 <th style="text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;">Vorname</th>
 <th style="text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;">Nachname</th>
 <th style="text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;">Geburtstag</th>
</tr>
<?php while ($row = $resultSchueler->fetchArray(SQLITE3_ASSOC)): ?>
<tr>
 <td style="text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;"><?= $row['ID']; ?></td>
 <td style='font-size: 15px; padding: 1px 2px;'><?= $row['Vorname'] ?></td>
 <td style='font-size: 15px; padding: 1px 2px;'><?= $row['Name'] ?></td>
 <td style='font-size: 15px; padding: 1px 2px;'><?php $Geburtsdatum=explode("-",$row['Geburtsdatum']); echo"$Geburtsdatum[2].$Geburtsdatum[1].$Geburtsdatum[0]"; ?></td>
</tr>
<?php endwhile; ?>
</table>
 </div>
<!-- ENDE Schueler Spalte -->
<!-- ANFANG Schuljahresabschnitte Spalte -->
<div class="w3-col w3-container" style="width:20%">
<table border="1" cellpadding="5" cellspacing="0">
<tr>
 <th style='text-align: center; vertical-align: middle; font-size: 20px; padding: 2px 4px;' colspan="3">Schuljahresabschnitte</th>
</tr>
<tr>
 <th style='text-align: center; vertical-align: middle; font-size: 15px; padding: 2px 4px;'>ID</th>
 <th style='text-align: center; vertical-align: middle; font-size: 15px; padding: 2px 4px;'>Schuljahr</th>
 <th style='text-align: center; vertical-align: middle; font-size: 15px; padding: 2px 4px;'>Halbjahr</th>
</form>
<?php while ($row = $resultSchuljahresabschnitte->fetchArray(SQLITE3_ASSOC)): ?>
<tr>
 <td style="text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;"><?= $row['ID'] ?></td>
 <td style="text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;"><?= $row['Jahr'] ?></td>
 <td style="text-align: center; vertical-align: middle; font-size: 15px; padding: 1px 2px;"><?= $row['Abschnitt'] ?></td>
</tr>
<?php endwhile; ?>
</table>
 </div>
<!-- ENDE Schuljahresabschnitte Spalte -->
</div> <!-- ANFANG row -->
</body>
</html>
