<?php
session_start();
include '../inc/conf/config.inc.php';
if (!isset($_SESSION['benutzer'])) {
    header("Location: ../inc/login/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Sch&uuml;ler</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/eigene.css">
  <link rel="stylesheet" href="../css/w3.css">
  <link rel="shortcut icon" href="../ico/favicon.png">
  <script src="../js/jquery.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row w3-indigo">
<!--
 <div class="w3-container w3-threequarter w3-padding-16">
   <h1>
    <a href="https://<?php echo "$LOCALEIP"; ?>:9443" target="_blank">
     <img src="::/png/portainer.png" class="w3-round" alt="portainer.io" width="350">
   </a>

   <button class="w3-tooltip" onclick="window.open('https://<?php echo "$LOCALEIP"; ?>:4200', '_blank', 'width=800,height=600')">
     <span style="position:absolute;left:100px;bottom:0" class="w3-text w3-tag">ROOT CONSOLE</span>
	 <img src="../png/terminal.png" class="w3-round" alt="Terminal" width="80" height="80">
   </button> 
  </h1> 
 </div>
 <div class="w3-container w3-quarter w3-right-align w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="../png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
 -->
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="../png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
 <nav class="navbar navbar-inverse" style="border-radius: 0";>
  <div class="container-fluid">
   <ul class="nav navbar-nav">
    <li class="active"><a href="Schemata.php"><span class="label label-danger">Schuljahr-Erhöhen</span></a></li>
    <li><a href="../index.php"><span class="label label-default">SVWS-Schemata-Update</span></a></li>
    <li><a href="../svws-versions-update.php"><span class="label label-default">SVWS-Versions-Update</span></a></li>
    <li><a href="../wenom-versions-update.php"><span class="label label-default">WENOM-Versions-Update</span></a></li>
<!--     <li><a href="../schemata.php"><span class="label label-default">Schemata-Releases-Update</span></a></li> -->
    <li><a href="../schild3.php"><span class="label label-default">SchILD3-Update</span></a></li>
    <li><a href="../container-status.php"><span class="label label-default">Status / Links</span></a></li>
   </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="../inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
  </div>
 </nav>
</div>
<section id="header"><!-- Anfang Header -->
 <?php include '../inc/header/admin.php'; ?>
</section><!-- Ende Header -->
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
<div class="w3-col w3-container" style="width:98%">
<hr class="schuljahr" />
<?php
// Fehleranzeige aktivieren (für Tests)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Liste erlaubter Datenbanken (Whitelist zur Sicherheit)
// wird ueber den include '../inc/conf/config.inc.php'; eingebuden
/*
$datenbanken = [
    'ENM_SVWS' => '/netzlaufwerk/SVWS-TestMDBs/ENM-Json/ENM-Testdaten-01/ENM_SVWS.sqlite',
    'Gesamtschule' => '/netzlaufwerk/OfficelleTestDBS/Gesamtschule/Gesamtschule.sqlite',
    'Grundschule' => '/netzlaufwerk/OfficelleTestDBS/Grundschule/Grundschule.sqlite',
    'Gymnasium_2HJ'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_2HJ.sqlite',
    'Gymnasium_FaecherSek2'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_FaecherSek2.sqlite',
    'Gymnasium_LaufbahnenJG10'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_LaufbahnenJG10.sqlite',
    'Gymnasium_LaufbahnenJGEF'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_LaufbahnenJGEF.sqlite',
    'Gymnasium_LaufbahnenJGEFMitBlockung'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_LaufbahnenJGEFMitBlockung.sqlite',
    'Gymnasium_LaufbahnenJGEFvollst'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/Gymnasium_LaufbahnenJGEFvollst.sqlite'
];
*/

// Gewählte Schule ermitteln
$schule = $_GET['schule'] ?? 'Grundschule';
$dbPath = $datenbanken[$schule] ?? null;

if (!$dbPath || !file_exists($dbPath)) {
    die("Ungültige oder fehlende Datenbank: $schule");
}

// Verbindung zur SQLite-Datenbank
$db = new SQLite3($dbPath);


//#########################################################################################################################################################
// SQL                                                                                                                                                  ###
// Lehrer                                                                                                                                               ### 
// UPDATE K_Lehrer SET Geburtsdatum = DATE(Geburtsdatum, '+1 year');                                                                                    ###
//#########################################################################################################################################################
// Schueler                                                                                                                                             ###
// OKAY UPDATE Schueler SET Geburtsdatum = DATE(Geburtsdatum, '+1 year');                                                                               ###
// OKAY UPDATE Schueler SET Aufnahmedatum = DATE(Aufnahmedatum, '+1 year');                                                                             ###
// OKAY UPDATE Schueler SET AnmeldeDatum = DATE(AnmeldeDatum, '+1 year');                                                                               ###
// OKAY UPDATE Schueler SET Einschulungsjahr = Einschulungsjahr + 1;                                                                                    ###
// OKAY UPDATE Schueler SET LSSchulEntlassDatum = DATE(LSSchulEntlassDatum, '+1 year');                                                                 ###
// OKAY UPDATE Schueler SET Religionsabmeldung = date(Religionsabmeldung, '+1 year') WHERE Religionsabmeldung IS NOT NULL AND Religionsabmeldung != ''; ###
// OKAY UPDATE Schueler SET Religionsanmeldung = date(Religionsanmeldung, '+1 year') WHERE Religionsanmeldung IS NOT NULL AND Religionsanmeldung != ''; ###
// OKAY UPDATE Schueler SET JahrWechsel_SI = JahrWechsel_SI + 1 WHERE JahrWechsel_SI IS NOT NULL;                                                       ###
// OKAY UPDATE Schueler SET JahrWechsel_SII = JahrWechsel_SII + 1 WHERE JahrWechsel_SII IS NOT NULL;                                                    ###
// OKAY UPDATE Schueler SET JahrZuzug = JahrZuzug + 1 WHERE JahrZuzug IS NOT NULL;                                                                      ###
###########################################################################################################################################################
// Schuljahresabschnitte                                                                                                                                ###
// UPDATE Schuljahresabschnitte SET Jahr = Jahr + 1;                                                                                                    ###
//#########################################################################################################################################################
// 📆 Geburtstage ändern
if (isset($_POST['geburtsdatum_plus_eins'])) {
    $db->exec("UPDATE Schueler SET Geburtsdatum = date(Geburtsdatum, '+1 year')");
    echo "<p style='color: green;'>Alle Geburtsdaten wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['geburtsdatum_minus_eins'])) {
    $db->exec("UPDATE Schueler SET Geburtsdatum = date(Geburtsdatum, '-1 year')");
    echo "<p style='color: orange;'>Alle Geburtsdaten wurden um 1 Jahr verringert.</p>";
}
// Aufnahmedatum ändern
if (isset($_POST['aufnahmedatum_plus_eins'])) {
    $db->exec("UPDATE Schueler SET Aufnahmedatum = DATE(Aufnahmedatum, '+1 year')");
    echo "<p style='color: green;'>Alle Aufnahmedaten wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['aufnahmedatum_minus_eins'])) {
    $db->exec("UPDATE Schueler SET Aufnahmedatum = DATE(Aufnahmedatum, '-1 year')");
    echo "<p style='color: orange;'>Alle Aufnahmedaten wurden um 1 Jahr verringert.</p>";
}
// AnmeldeDatum ändern
if (isset($_POST['anmeldedatum_plus_eins'])) {
    $db->exec("UPDATE Schueler SET AnmeldeDatum = DATE(AnmeldeDatum, '+1 year')");
    echo "<p style='color: green;'>Alle Anmeldedaten wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['anmeldedatum_minus_eins'])) {
    $db->exec("UPDATE Schueler SET AnmeldeDatum = DATE(AnmeldeDatum, '-1 year')");
    echo "<p style='color: orange;'>Alle Anmeldedaten wurden um 1 Jahr verringert.</p>";
}
//Einschulungsjahr
if (isset($_POST['einschulungsjahr_plus_eins'])) {
    $db->exec("UPDATE Schueler SET Einschulungsjahr = Einschulungsjahr + 1");
    echo "<p style='color: green;'>Alle Einschulungsdaten wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['einschulungsjahr_minus_eins'])) {
    $db->exec("UPDATE Schueler SET Einschulungsjahr = Einschulungsjahr - 1");
    echo "<p style='color: orange;'>Alle Einschulungsdaten wurden um 1 Jahr verringert.</p>";
}
//LSSchulEntlassDatum
if (isset($_POST['lsschulentlassdatum_plus_eins'])) {
    $db->exec("UPDATE Schueler SET LSSchulEntlassDatum = DATE(LSSchulEntlassDatum, '+1 year')");
    echo "<p style='color: green;'>Alle LSSchulEntlassdaten wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['lsschulentlassdatum_minus_eins'])) {
    $db->exec("UPDATE Schueler SET LSSchulEntlassDatum = DATE(LSSchulEntlassDatum, '-1 year')");
    echo "<p style='color: orange;'>Alle LSSchulEntlassdaten wurden um 1 Jahr verringert.</p>";
}
//Religionsabmeldung
if (isset($_POST['religionsabmeldung_plus_eins'])) {
    $db->exec("UPDATE Schueler SET Religionsabmeldung = date(Religionsabmeldung, '+1 year') WHERE Religionsabmeldung IS NOT NULL AND Religionsabmeldung != ''");
    echo "<p style='color: green;'>Alle Religionsabmeldung wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['religionsabmeldung_minus_eins'])) {
    $db->exec("UPDATE Schueler SET Religionsabmeldung = date(Religionsabmeldung, '-1 year') WHERE Religionsabmeldung IS NOT NULL AND Religionsabmeldung != ''");
    echo "<p style='color: orange;'>Alle Religionsabmeldung wurden um 1 Jahr verringert.</p>";
}
//Religionsanmeldung
if (isset($_POST['religionsanmeldung_plus_eins'])) {
    $db->exec("UPDATE Schueler SET Religionsanmeldung = date(Religionsanmeldung, '+1 year') WHERE Religionsanmeldung IS NOT NULL AND Religionsanmeldung != ''");
    echo "<p style='color: green;'>Alle Religionsanmeldung wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['religionsanmeldung_minus_eins'])) {
    $db->exec("UPDATE Schueler SET Religionsanmeldung = date(Religionsanmeldung, '-1 year') WHERE Religionsanmeldung IS NOT NULL AND Religionsanmeldung != ''");
    echo "<p style='color: orange;'>Alle Religionsanmeldung wurden um 1 Jahr verringert.</p>";
}
//JahrWechsel_SI
if (isset($_POST['jahrwechsel_si_plus_eins'])) {
    $db->exec("UPDATE Schueler SET JahrWechsel_SI = JahrWechsel_SI + 1 WHERE JahrWechsel_SI IS NOT NULL");
    echo "<p style='color: green;'>Alle JahrWechsel_SI wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['jahrwechsel_si_minus_eins'])) {
    $db->exec("UPDATE Schueler SET JahrWechsel_SI = JahrWechsel_SI - 1 WHERE JahrWechsel_SI IS NOT NULL");
    echo "<p style='color: orange;'>Alle JahrWechsel_SI wurden um 1 Jahr verringert.</p>";
}
//JahrWechsel_SII
if (isset($_POST['jahrwechsel_sii_plus_eins'])) {
    $db->exec("UPDATE Schueler SET JahrWechsel_SII = JahrWechsel_SII + 1 WHERE JahrWechsel_SII IS NOT NULL");
    echo "<p style='color: green;'>Alle JahrWechsel_SII wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['jahrwechsel_sii_minus_eins'])) {
    $db->exec("UPDATE Schueler SET JahrWechsel_SII = JahrWechsel_SII - 1 WHERE JahrWechsel_SII IS NOT NULL");
    echo "<p style='color: orange;'>Alle JahrWechsel_SII wurden um 1 Jahr verringert.</p>";
}
// JahrZuzug
if (isset($_POST['jahrzuzug_plus_eins'])) {
    $db->exec("UPDATE Schueler SET JahrZuzug = JahrZuzug + 1 WHERE JahrZuzug IS NOT NULL");
    echo "<p style='color: green;'>Alle JahrZuzug wurden um 1 Jahr erhöht.</p>";
}
if (isset($_POST['jahrzuzug_minus_eins'])) {
    $db->exec("UPDATE Schueler SET JahrZuzug = JahrZuzug - 1 WHERE JahrZuzug IS NOT NULL");
    echo "<p style='color: orange;'>Alle JahrZuzug wurden um 1 Jahr verringert.</p>";
}


// ID des Schülers, den du anzeigen möchtest (hier fest auf 1 gesetzt)
$ID = 1;
// SQL-Abfrage mit JOIN
$sql = "
SELECT 
    EigeneSchule.Schuljahresabschnitts_ID,
    Schuljahresabschnitte.ID,
    Schuljahresabschnitte.Jahr
FROM 
    EigeneSchule
JOIN 
    Schuljahresabschnitte ON EigeneSchule.Schuljahresabschnitts_ID = Schuljahresabschnitte.ID
WHERE 
    EigeneSchule.ID = :id
";

// Abfrage vorbereiten
$stmt = $db->prepare($sql);
$stmt->bindValue(':id', $ID, SQLITE3_INTEGER);

// Ausführen und Ergebnis holen
$result = $stmt->execute();
$row = $result->fetchArray(SQLITE3_ASSOC);

// Ausgabe
if ($row) {
    echo "<div class='w3-panel w3-leftbar w3-rightbar w3-khaki w3-xlarge w3-arial w3-center'>Das Datenbankschemata  <b>$schule</b> befindet sich im Schuljahr <b>" . htmlspecialchars($row['Jahr']) . "</b></div>";
} else {
    echo "Kein Schüler mit ID $ID gefunden.";
}
// Daten abrufen

// 📋 Schülerdaten abrufen
//$result = $db->query("SELECT ID, Vorname, Name, Geburtsdatum, Aufnahmedatum, Einschulungsjahr, Religionsabmeldung, Religionsanmeldung, LSSchulEntlassDatum, JahrWechsel_SI, JahrWechsel_SII, AnmeldeDatum, JahrZuzug  FROM Schueler ORDER BY ID ASC");
$result = $db->query("SELECT * FROM Schueler ORDER BY ID ASC");
?>
<hr class="schuljahr" />

<!-- HTML-Frontend -->

<label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-xlarge w3-arial">Schülerverwaltung – <?= htmlspecialchars($schule) ?></label>

<!-- Auswahl Schule -->
<form method="GET">
    <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial">Schule wählen:</label>
    <select name="schule" onchange="this.form.submit()">
        <?php foreach ($datenbanken as $name => $pfad): ?>
            <option value="<?= $name ?>" <?= $schule == $name ? 'selected' : '' ?>><?= $name ?></option>
        <?php endforeach; ?>
    </select>

    <!-- Suche 
    <input type="text" name="suche" placeholder="Suche nach Name..." value="<?= htmlspecialchars($suche) ?>">
    <input type="submit" value="Suchen">
	-->
</form>


<!-- ANFANG Neuer Schüler -->
<!--<h3>Neuen Schüler hinzufügen</h3>
<form method="POST">
    <input type="text" name="vorname" placeholder="Vorname" required>
    <input type="text" name="name" placeholder="Nachname" required>
    <input type="date" name="geburtsdatum" required>
    <input type="submit" name="neu" value="Hinzufügen">
</form>
-->
<!-- ENDE Neuer Schüler -->
<?php
// 📊 Statistik: Anzahl Schüler pro Geburtsjahr
$statistik = [];
$res = $db->query("SELECT strftime('%Y', Geburtsdatum) AS Jahrgang, COUNT(*) AS Anzahl FROM Schueler GROUP BY Jahrgang ORDER BY Jahrgang DESC");
while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
    $statistik[] = $row;
}
?>
<!--<h3>📊 Statistik: Anzahl Schüler pro Jahrgang</h3>
<table border="1" cellpadding="5" cellspacing="0">
    <tr><th>Jahrgang</th><th>Anzahl Schüler</th></tr>
    <?php foreach ($statistik as $eintrag): ?>
        <tr>
            <td><?= htmlspecialchars($eintrag['Jahrgang']) ?></td>
            <td><?= htmlspecialchars($eintrag['Anzahl']) ?></td>
        </tr>
    <?php endforeach; ?>
</table>
-->
<!-- Tabelle -->
<h3>Schülerliste</h3>
<table class="w3-table" style="width: 250px" border="1">
<!-- Buttons: Jahr ändern + Export -->
<form method="POST" style="margin-top:10px;">
<tr>
 <th style="text-align: center; vertical-align: middle; font-size: 10px; padding: 1px 2px;">ID</th>
 <th style="text-align: center; vertical-align: middle; font-size: 10px; padding: 1px 2px;">Vorname</th>
 <th style="text-align: center; vertical-align: middle; font-size: 10px; padding: 1px 2px;">Nachname</th>
 <th>
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="geburtsdatum_plus_eins" value="Geburtsdatum +1 Jahr" onclick="return confirm('Wirklich alle Geburtsdaten um 1 Jahr erhöhen?');">
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="geburtsdatum_minus_eins" value="Geburtsdatum -1 Jahr " onclick="return confirm('Wirklich alle Geburtsdaten um 1 Jahr verringern?');">
 </th>
 <th>
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="aufnahmedatum_plus_eins" value="Aufnahmedatum +1 Jahr" onclick="return confirm('Wirklich alle Aufnahmedaten um 1 Jahr erhöhen?');">
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="aufnahmedatum_minus_eins" value="Aufnahmedatum -1 Jahr " onclick="return confirm('Wirklich alle Aufnahmedaten um 1 Jahr verringern?');">
 </th>
 <th>
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="anmeldedatum_plus_eins" value="AnmeldeDatum +1 Jahr" onclick="return confirm('Wirklich alle Anmeldedaten um 1 Jahr erhöhen?');">
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="anmeldedatum_minus_eins" value="AnmeldeDatum -1 Jahr " onclick="return confirm('Wirklich alle Anmeldedaten um 1 Jahr verringern?');">
 </th>
 <th>
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="einschulungsjahr_plus_eins" value="Einschulungsjahr +1 Jahr" onclick="return confirm('Wirklich alle Einschulungsdaten um 1 Jahr erhöhen?');">
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="einschulungsjahr_minus_eins" value="Einschulungsjahr -1 Jahr " onclick="return confirm('Wirklich alle Einschulungsdaten um 1 Jahr verringern?');">
 </th>
 <th> 
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="lsschulentlassdatum_plus_eins" value="LSSchulEntlassDatum +1 Jahr" onclick="return confirm('Wirklich alle LSSchulEntlassDatum um 1 Jahr erhöhen?');">
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="lsschulentlassdatum_plus_eins" value="LSSchulEntlassDatum -1 Jahr " onclick="return confirm('Wirklich alleLSSchulEntlassDatum um 1 Jahr verringern?');">
 </th>
 <th>
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="religionsabmeldung_plus_eins" value="Religionsabmeldung +1 Jahr" onclick="return confirm('Wirklich alle Religionsabmeldung um 1 Jahr erhöhen?');">
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="religionsabmeldung_minus_eins" value="Religionsabmeldung -1 Jahr " onclick="return confirm('Wirklich Religionsabmeldung um 1 Jahr verringern?');">
 </th>
 <th>
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="religionsanmeldung_plus_eins" value="Religionsanmeldung +1 Jahr" onclick="return confirm('Wirklich alle Religionsanmeldung um 1 Jahr erhöhen?');">
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="religionsanmeldung_minus_eins" value="Religionsanmeldung -1 Jahr " onclick="return confirm('Wirklich Religionsanmeldung um 1 Jahr verringern?');">
 </th>
 <th>
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="jahrzuzug_plus_eins" value="JahrZuzug +1 Jahr" onclick="return confirm('Wirklich alle JahrZuzug um 1 Jahr erhöhen?');">
  <input style="font-size: 9px; padding: 1px 2px;" type="submit" name="jahrzuzug_minus_eins" value="JahrZuzug -1 Jahr " onclick="return confirm('Wirklich JahrZuzug um 1 Jahr verringern?');">
 </th> 
<?php 
if ($schule <> "Grundschule"){
 echo"
  <th>
   <input style='font-size: 9px; padding: 1px 2px;' type='submit' name='jahrwechsel_si_plus_eins' value='JahrWechsel_SI +1 Jahr' onclick='return confirm('Wirklich alle JahrWechsel_SI um 1 Jahr erhöhen?');'>
   <input style='font-size: 9px; padding: 1px 2px;' type='submit' name='jahrwechsel_si_minus_eins' value='JahrWechsel_SI -1 Jahr' onclick='return confirm('Wirklich JahrWechsel_SI um 1 Jahr verringern?');'>
  </th>
 ";
 echo"
  <th>
   <input style='font-size: 9px; padding: 1px 2px;' type='submit' name='jahrwechsel_sii_plus_eins' value='JahrWechsel_SII +1 Jahr' onclick='return confirm('Wirklich alle JahrWechsel_SII um 1 Jahr erhöhen?');'>
   <input style='font-size: 9px; padding: 1px 2px;' type='submit' name='jahrwechsel_sii_minus_eins' value='JahrWechsel_SII -1 Jahr' onclick='return confirm('Wirklich JahrWechsel_SII um 1 Jahr verringern?');'>
  </th>
 ";
 }
 ?>
</tr>
</form>
<?php while ($row = $result->fetchArray(SQLITE3_ASSOC)): ?>
<tr style='font-size: 10px; padding: 1px 2px;' >
 <td><?= $row['ID']; ?><input type="hidden" name="id" value="<?= $row['ID'] ?>"></td>
 <td><?= $row['Vorname'] ?><input type="hidden" name="vorname" value="<?= htmlspecialchars($row['Vorname']) ?>"></td>
 <td><?= $row['Name'] ?><input type="hidden" name="name" value="<?= htmlspecialchars($row['Name']) ?>"></td>
 <td><?//= $row['Geburtsdatum'] ?><input type="date" name="geburtsdatum" value="<?= $row['Geburtsdatum'] ?>"></td>
 <td><?//= $row['Aufnahmedatum'] ?><input type="date" name="Aufnahmedatum" value="<?= $row['Aufnahmedatum'] ?>"></td>
 <td><?//= $row['AnmeldeDatum'] ?><input type="date" name="AnmeldeDatum" value="<?= $row['AnmeldeDatum'] ?>"></td>
 <td><?= $row['Einschulungsjahr'] ?><input type="hidden" name="Einschulungsjahr" value="<?= $row['Einschulungsjahr'] ?>"></td>
 <td><?//= $row['LSSchulEntlassDatum'] ?><input type="date" name="LSSchulEntlassDatum" value="<?= $row['LSSchulEntlassDatum'] ?>"></td>
 <td><?//= $row['Religionsabmeldung']  ?><input type="date" name="Religionsabmeldung" value="<?= $row['Religionsabmeldung'] ?>"></td>
 <td><?//= $row['Religionsanmeldung'] ?><input type="date" name="Religionsanmeldung" value="<?= $row['Religionsanmeldung'] ?>"></td>
 <td><?= $row['JahrZuzug'] ?><input type="hidden" name="JahrZuzug" value="<?= $row['JahrZuzug'] ?>"></td>
<?php 
if ($schule <> "Grundschule"){
  echo "<td>$row[JahrWechsel_SI] <input type='hidden' name='JahrWechsel_SI' value='$row[JahrWechsel_SI]'></td>";
  echo "<td>$row[JahrWechsel_SII] <input type='hidden' name='JahrWechsel_SII' value='$row[JahrWechsel_SII]'></td>";
 }
 ?>            
</tr>
<?php endwhile; ?>
</table>
 </div>
</div>
</body>
</html>
