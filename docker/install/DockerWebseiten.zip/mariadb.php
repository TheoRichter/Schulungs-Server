<?php
if (class_exists('mysqli')) {
    echo "MySQLi ist verfügbar!";
} else {
    echo "MySQLi fehlt!";
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = "192.168.101.27";
$port = "3004";
$adminUser = "root"; // Benutzer mit passenden Rechten
$adminPass = "05Richter61";
$db = "mysql";

$mysqli = new mysqli($host, $adminUser, $adminPass, $db);

if ($mysqli->connect_error) {
    die("Verbindung fehlgeschlagen: " . $mysqli->connect_error);
}

// Name des Benutzers, dessen Hash du auslesen willst
$targetUser = 'Grundschule';
$targetHost = 'localhost';

$query = "
    SELECT plugin, authentication_string
    FROM mysql.user
    WHERE user = '$targetUser' AND host = '$targetHost';
";

$result = $mysqli->query($query);

if ($result && $row = $result->fetch_assoc()) {
    echo "Plugin: " . $row['plugin'] . "\n";
    echo "Passwort-Hash: " . $row['authentication_string'] . "\n";
} else {
    echo "Benutzer nicht gefunden oder keine Berechtigung.";
}

$mysqli->close();
?>
