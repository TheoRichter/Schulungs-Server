<html>
<head>
 <title>Offizielle DatenbankSchemata Upload</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/upload.css">
  <link rel="shortcut icon" href="ico/favicon.png">
</head>
<body>
<?php
$uploadDir = '/var/www/html/zip/';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['zipfile']) && $_FILES['zipfile']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['zipfile']['tmp_name'];
        $fileName = basename($_FILES['zipfile']['name']);
        $destPath = $uploadDir . $fileName;

        // Prüfen ob es wirklich eine ZIP-Datei ist
        $fileType = mime_content_type($fileTmpPath);
        if ($fileType === 'application/zip' || pathinfo($fileName, PATHINFO_EXTENSION) === 'zip') {
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                echo "Datei erfolgreich hochgeladen nach: $destPath";
				include "close.php";  
            } else {
                echo "<p class='ok'>Fehler beim Verschieben der Datei.</p>";
            }
        } else {
            echo "<p class='nein'>Nur ZIP-Dateien sind erlaubt.</p>";
        }
    } else {
     echo "<p class='fehler'>Datei-Upload fehlgeschlagen. Fehlercode: " . $_FILES['zipfile']['error'] . "</p>";
    }
}
?>
</body>
</html>