<html>
<head>
 <title>SchILD3 Version Updaten</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/form.css">
  <link rel="shortcut icon" href="ico/favicon.png">
</head>
<body>
<?php
$skriptDatei = "sh/Schild3Download.sh";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $neueVersion = trim($_POST["version"] ?? "");

    if (preg_match('/^\d+\.\d+\.\d+$/', $neueVersion)) {
        // Lade Datei
        $inhalt = file_get_contents($skriptDatei);

        // Ersetze die Zeile mit SCHILD_VERSIONSNR
        $inhaltNeu = preg_replace(
            '/^SCHILD_VERSIONSNR="[^"]*"/m',
            'SCHILD_VERSIONSNR="' . $neueVersion . '"',
            $inhalt
        );

        // Schreibe Datei zurück
        file_put_contents($skriptDatei, $inhaltNeu);
        echo "<p class='echo'>Version erfolgreich auf <strong>$neueVersion</strong> weiter.</p>";
        include "close.php";
        exit;
    } else {
	 if (isset($inhaltNeu) && !empty($inhaltNeu)) {
      echo "<p style='color:red;'>Ungültiges Versionsformat. Bitte z.B. 3.5.0 eingeben.</p>";
	 } 
    }
}
?>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <form method="post">
    <label class="form" for="version">SchILD3-Release-Nummer: z.B. 3.5.0 Eingeben.</label><input type="text" name="version" id="version" required><br><br>
    <button type="submit">weiter</button>
  </form>
 </div>
</div> 
</body>
</html>
