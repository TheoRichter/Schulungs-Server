<html>
<head>
 <title>SchILD3-Reports</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/sh.css">
  <link rel="shortcut icon" href="ico/favicon.png">
</head>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $scriptPath = "sh/Schild3Reports.sh";

    if (file_exists($scriptPath)) {
        $output = shell_exec("bash " . escapeshellarg($scriptPath) . " 2>&1");
        echo "<pre class='start'>" . htmlspecialchars($output) . "</pre>";
		include "close.php";  
    } else {
        echo "<p style='color:red;'>Skript nicht gefunden: " . htmlspecialchars($scriptPath) . "</p>";
    }
}
?>
</body>
</html>
