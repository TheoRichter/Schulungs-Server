
<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

// Download-Adresse entgegennehmen
$url = trim($_POST['download'] ?? '');

// Prüfen
if (empty($url)) {
    die("Keine Download-Adresse übergeben.");
}

// Nur HTTPS zulassen
if (!filter_var($url, FILTER_VALIDATE_URL) ||
    parse_url($url, PHP_URL_SCHEME) !== 'https') {
    die("Ungültige Download-Adresse.");
}

// Zielverzeichnis
$zipDir = '/var/www/html/zip/';

// Verzeichnis prüfen
if (!is_dir($zipDir)) {
    mkdir($zipDir, 0755, true);
}

// Dateiname ermitteln
$filename = basename(parse_url($url, PHP_URL_PATH));

if (empty($filename)) {
    die("Kein Dateiname gefunden.");
}

$target = $zipDir . $filename;

// Download durchführen
$ch = curl_init($url);
$fp = fopen($target, 'wb');

curl_setopt_array($ch, [
    CURLOPT_FILE => $fp,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 5,
    CURLOPT_TIMEOUT => 300,
    CURLOPT_FAILONERROR => true,
    CURLOPT_USERAGENT => 'SVWS-Tools'
]);

$success = curl_exec($ch);
$error = curl_error($ch);

curl_close($ch);
fclose($fp);

if ($success) {
    echo "Download erfolgreich!<br>";
    echo "Datei: " . htmlspecialchars($filename);
} else {
    if (file_exists($target)) {
        unlink($target);
    }

    echo "Download fehlgeschlagen: " . htmlspecialchars($error);
}

?>