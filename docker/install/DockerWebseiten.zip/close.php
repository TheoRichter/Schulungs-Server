<?php
echo "
 <!DOCTYPE html>
  <html>
   <head>
    <title>Automatisches Schließen</title>
     <script>
      // Warte 3 Sekunden und schließe dann das Fenster
      setTimeout(function () {
      window.close();
      }, 3000);
     </script>
    </head>
    <body>
     <p style='color:green;'>Diese Seite wird in 3 Sekunden automatisch geschlossen.</p>
    </body>
   </html>
"; 
?>