<?php
session_start();
if (!isset($_SESSION['benutzer'])) {
    header("Location: inc/login/login.php");
    exit;
}
?>
<html>
<head>
 <title>Schemata-Updaten</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row w3-indigo">
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
<nav class="navbar navbar-inverse" style="border-radius: 0";>
  <div class="container-fluid">
    <ul class="nav navbar-nav">
     <li class="active"><a href="schemata.php"><span class="label label-danger">Schemata-Releases-Update</span></a></li>
     <li><a href="index.php"><span class="label label-default">SVWS-Schemata-Update</span></a></li>
     <li><a href="svws-versions-update.php"><span class="label label-default">SVWS-Versions-Update</span></a></li>
     <li><a href="wenom-versions-update.php"><span class="label label-default">WENOM-Versions-Update</span></a></li>
     <li><a href="schild3.php"><span class="label label-default">SchILD-NRW-3</span></a></li>
     <li><a href="container-status.php"><span class="label label-default">Status/Link</span></a></li>
    </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
  </div>
</nav>
</div>
<div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
	<h2 class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-arial w3-center">Releases Update</h2>
    <h3 class="w3-arial">1. Schritt</h3>
	<iframe src="https://10.1.0.200/bauanleitung/downloads/linux/zip/SchulungsSchematas/" width="98%" height="300" frameborder="0" style="background-color:"></iframe>
    <font color="green">(Standartmäßig werden die Dateien im Downloads-Ordner des PCs gespeichert.)</font>
  </div>
 </div>
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
    <h3 class="w3-arial">2. Schritt</h3>
    <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial">&nbsp;ZIP-Datei hochladen</label>   
    <form id="scriptUpload" target="outputWindow" action="upload.php" method="POST" enctype="multipart/form-data">
        <input class="w3-large w3-arial" type="file" name="zipfile" accept=".zip" required>
        <button class="w3-tooltip w3-leftbar w3-rightbar w3-large w3-arial" type="submit">Hochladen</button>
    </form>
  </div>
 </div>
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
   <h3 class="w3- w3-">3. Schritt</h3>
   <form id="scriptDatenbankSchemata" method="post" target="outputWindow" action="datenbankschemata-update.php">
    <!--<label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="DatenbankSchemata">Release Update durchführen.</label>&nbsp;-->
	<button class="w3-tooltip w3-leftbar w3-rightbar w3-large w3-arial" type="submit" id="DatenbankSchemata" name="DatenbankSchemata" value="DatenbankSchemata"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Release Update durchführen</button>
   </form>
   <br />
  </div>
 </div>
</div>
<!--#################### ANFANG FOOTER##############################################################################################################-->
<section id="footer"><!-- Anfang Footer -->
<?php include 'inc/footer/footer.php' ?>
</section><!-- Ende Footer -->
<!--#################### ENDE FOOTER##############################################################################################################-->
  <script>
    document.getElementById('scriptUpload').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=600');
    });
  </script>
  <script>
    document.getElementById('scriptDatenbankSchemata').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=600');
    });
  </script>
</body>
</html>
