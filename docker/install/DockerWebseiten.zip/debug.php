<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "Start<br>";
include 'inc/conf/config.inc.php';
echo "IP: $LOCALEIP<br>";