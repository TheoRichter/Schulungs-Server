<html>
<head>
 <title>Statusanzeiger-Docker-Container</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/eigene.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
 <h2 class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-arial w3-center" >Statusanzeiger der Docker-Container.</h2>
 <!--################# ANFANG REM ########################-->
 <!-- <div class="w3-col w3-container" style="width:35%"> -->
 <!--################# ENDE REM ##########################-->
 <table class="w3-border" align="center" border="0">
 	<form id="scriptDocker" method="post" target="outputWindow" action="docker-status.php">
    <tr class="">
	<td class="w3-border w3-center"><font size="2">STACK</font></td>
	<td colspan="2" class="w3-border w3-center">
      <button class="w3-tooltip" type="submit" name="StartSVWSmariaDB" value="StartSVWSmariaDB"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Start</button>
      <button class="w3-tooltip" type="submit" name="StopSVWSmariaDB" value="StopSVWSmariaDB"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Stop</button>
     <br />
	 &nbsp;&nbsp;<font color="">SVWS-Status</font>&nbsp;&nbsp;
	</td>
 	<td colspan="1" class="w3-border w3-center">
      <button class="w3-tooltip" type="submit" name="StartWebserver" value="StartWebserver"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Start</button>
      <button class="w3-tooltip" type="submit" name="StopWebserver" value="StopWebserver"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Stop</button>
     <br />
	 &nbsp;&nbsp;WeNoM-Status&nbsp;&nbsp;
</td>
   </tr>
   </form>
   <tr>
    <td class="w3-border w3-center">pc-01</td>   
	<td class="w3-border w3-center"><iframe src="docker/pc-01/svws-server.html" width="45" height="40" frameborder="0" style="background-color:"></iframe></td>
	<td class="w3-border w3-center"><iframe src="docker/pc-01/mariadb.html" width="45" height="40" frameborder="0" style="background-color:"></iframe></td>
	<td class="w3-border w3-center"><iframe src="docker/pc-01/webserver.html" width="45" height="40" frameborder="0" style="background-color:"></iframe></td>
  </tr>
   <tr>
    <td class="w3-border w3-center"><?php include 'inc/conf/config.inc.php'; echo "$letzteZeile"; ?></td>   
	<td class="w3-border w3-center"><iframe src="docker/<?php include 'inc/conf/config.inc.php'; echo "$letzteZeile"; ?>/svws-server.html" width="45" height="40" frameborder="0" style="background-color:"></iframe></td>
	<td class="w3-border w3-center"><iframe src="docker/<?php include 'inc/conf/config.inc.php'; echo "$letzteZeile"; ?>/mariadb.html" width="45" height="40" frameborder="0" style="background-color:"></iframe></td>
	<td class="w3-border w3-center"><iframe src="docker/<?php include 'inc/conf/config.inc.php'; echo "$letzteZeile"; ?>/webserver.html" width="45" height="40" frameborder="0" style="background-color:"></iframe></td>
   </tr>
  </table>
 </div>
</div>
 <script src="js/docker.js"></script>
 </body>
 </html>