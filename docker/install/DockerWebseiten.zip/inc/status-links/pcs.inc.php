<!-- ANFANG pc-$pcNummer -->
<tr> 
  <td class="w3-border"><b>pc-$pcNummer</b></td>
  <td class="w3-border"><a href="https://LOCALEIP:810$pcNummer/app/start" target="_blank">&nbsp;&nbsp;<img src="png/wenom_neu.png" class="w3-round" alt="wenom_neu.png"></a></td>
  <td class="w3-border"><a href="https://LOCALEIP:1000$pcNummer/" target="_blank">&nbsp;<img src="png/svws_neu.png" class="w3-round" alt="svws_neu.png"></a></td>
  <td class="w3-border"><iframe src="docker/pc-$pcNummer/svws-server.html" width="45" height="40" frameborder="0"></iframe></td>
  <td class="w3-border"><iframe src="docker/pc-$pcNummer/svws-server_start_stop.php" width="245" height="40" frameborder="1"></iframe></td>
  <td class="w3-border"><iframe src="docker/pc-$pcNummer/mariadb.html" width="45" height="40" frameborder="0"></iframe></td>
  <td class="w3-border"><iframe src="docker/pc-$pcNummer/mariadb_start_stop.php" width="245" height="40" frameborder="1"></iframe></td>
  <td class="w3-border"><iframe src="docker/pc-$pcNummer/webserver.html" width="45" height="40" frameborder="0"></iframe></td>
  <td class="w3-border"><iframe src="docker/pc-$pcNummer/webserver_start_stop.php" width="245" height="40" frameborder="1"></iframe></td>
</tr>
<!-- ENDE pc-$pcNummer -->
