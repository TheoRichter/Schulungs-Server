
<?php

$db = new SQLite3('/var/www/html/sqlite/tools.sqlite');
$db->busyTimeout(5000);

$tools = [
    'conference' => 'Conference',
    'gradehub'   => 'Gradehub',
    'import'     => 'Import',
    'laufbahn'   => 'WebLupo',
    'prognos'    => 'Prognos',
    'wenom'      => 'WeNoM'
];

?>
<table class="svws-table">
    <thead>
        <tr>
            <th><h3>Tools</h3></th>
            <th><h3>Installiert</h3></th>
            <th><h3>Aktuell</h3></th>
<!--            <th><h3>Manueller</h3></th> -->
        </tr>
    </thead>
    <tbody>

    <?php foreach ($tools as $table => $name): ?>

        <?php
        $stmt = $db->prepare(
            "SELECT Installiert, Aktuell, Download FROM \"$table\" LIMIT 1"
        );

        $result = $stmt->execute();
        $row = $result->fetchArray(SQLITE3_ASSOC);
        ?>

        <tr>
            <td><?= htmlspecialchars($name) ?></td>

            <td>
                <span class="version">
                    <?= htmlspecialchars($row['Installiert'] ?? '') ?>
                </span>
            </td>

            <td>
                <span class="version">
                    <?= htmlspecialchars($row['Aktuell'] ?? '') ?>
                </span>
            </td>
<!--
            <th>
                <span class="">

                <form action="download.php" method="post">
                  <input type="hidden" name="download"
                   value="<?= htmlspecialchars($row['Download'], ENT_QUOTES, 'UTF-8') ?>">

                 <button type="submit" class="w3-button w3-white">
                  Download
                 </button>
                 </form>
                </span>
            </th>
-->			
        </tr>

    <?php endforeach; ?>

    </tbody>
</table>

<?php $db->close(); ?>
