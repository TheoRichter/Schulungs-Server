
<?php

$db = new SQLite3('/var/www/html/sqlite/tools.sqlite');
$db->busyTimeout(5000);

$tools = [
    'conference' => 'Conference',
    'gradehub'   => 'Gradehub',
    'import'     => 'Import',
    'laufbahn'   => 'WebLupo',
    'prognos'    => 'Prognos',
    'wenom'      => 'WeNoM'
];

?>
<meta http-equiv="refresh" content="10">
<table class="svws-table">
    <thead>
        <tr>
            <th><h3>Tools</h3></th>
            <th><h3>Installiert</h3></th>
            <th><h3>Aktuell</h3></th>
        </tr>
    </thead>
    <tbody>

    <?php foreach ($tools as $table => $name): ?>

        <?php
        $stmt = $db->prepare(
            "SELECT Installiert, Aktuell FROM \"$table\" LIMIT 1"
        );

        $result = $stmt->execute();
        $row = $result->fetchArray(SQLITE3_ASSOC);
        ?>

        <tr>
            <td><?= htmlspecialchars($name) ?></td>

            <td>
                <span class="version">
                    <?= htmlspecialchars($row['Installiert'] ?? '') ?>
                </span>
            </td>

            <td>
                <span class="version">
                    <?= htmlspecialchars($row['Aktuell'] ?? '') ?>
                </span>
            </td>
        </tr>

    <?php endforeach; ?>

    </tbody>
</table>

<?php $db->close(); ?>
