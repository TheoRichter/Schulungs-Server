
<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ==================================================
// SVWS Versionsprüfung
// GitHub-Abfrage maximal alle 24 Stunden
//
// SQLite:
// Aktuell  = Versionsnummer
// Download = Passender ZIP-Download
// ==================================================

echo "<h2>SVWS Versionsprüfung</h2>";

// --------------------------------------------------
// GitHub-Repositories und Tabellen
// --------------------------------------------------

$tools = [

    "svws" => [
        "repository" => "SVWS-Server",
        "download" => null
    ],

    "laufbahn" => [
        "repository" => "SVWS-Server",
        "download" => "SVWS-Laufbahnplanung-{VERSION}.zip"
    ],

    "wenom" => [
        "repository" => "SVWS-Server",
        "download" => "WeNoM-{VERSION}.zip"
    ],

    "conference" => [
        "repository" => "SVWS-Conference",
        "download" => "svws-conference-{VERSION}-webserver.zip"
    ],

    "import" => [
        "repository" => "SVWS-Import",
        "download" => "SVWS-Import-{VERSION}-webapp.zip"
    ],

    "prognos" => [
        "repository" => "SVWS-Prognos",
        "download" => "SVWS-Prognos-{VERSION}-webserver.zip"
    ],

    "gradehub" => [
        "repository" => "SVWS-GradeHub",
        "download" => "gradehub-{VERSION}-webserver.zip"
    ]

];

// --------------------------------------------------
// Einstellungen
// --------------------------------------------------

$githubBase = "https://api.github.com/repos/SVWS-NRW/";

$cacheFile = "/var/www/html/sqlite/svws-versions-cache.json";

$updateInterval = 24 * 60 * 60;

// --------------------------------------------------
// GitHub Release auslesen
// --------------------------------------------------

function getGitHubRelease($repository)
{

    global $githubBase;

    $url = $githubBase .
           rawurlencode($repository) .
           "/releases/latest";

    $options = [
        "http" => [
            "header" =>
                "User-Agent: SVWS-Tools\r\n" .
                "Accept: application/vnd.github+json\r\n",

            "timeout" => 20,
            "ignore_errors" => true
        ]
    ];

    $context = stream_context_create($options);

    $response = @file_get_contents(
        $url,
        false,
        $context
    );

    if ($response === false) {

        throw new Exception(
            "GitHub konnte nicht erreicht werden: " . $repository
        );

    }

    // HTTP-Status prüfen

    $httpStatus = $http_response_header[0] ?? "";

    if (strpos($httpStatus, "200") === false) {

        throw new Exception(
            "GitHub API Fehler: " . $httpStatus
        );

    }

    // JSON auslesen

    $data = json_decode($response, true);

    if (!isset($data["tag_name"])) {

        throw new Exception(
            "Keine Release-Version gefunden: " . $repository
        );

    }

    // Versionsnummer ohne führendes v

    $version = preg_replace(
        '/^v/',
        '',
        $data["tag_name"]
    );

    // Alle Release-Dateien speichern

    $assets = [];

    foreach (($data["assets"] ?? []) as $asset) {

        if (
            !empty($asset["name"]) &&
            !empty($asset["browser_download_url"])
        ) {

            $assets[$asset["name"]] =
                $asset["browser_download_url"];

        }

    }

    return [
        "version" => $version,
        "assets" => $assets
    ];

}

// --------------------------------------------------
// Cache laden
// --------------------------------------------------

$cache = [];

if (file_exists($cacheFile)) {

    $cacheContent = @file_get_contents($cacheFile);

    if ($cacheContent !== false) {

        $cache = json_decode(
            $cacheContent,
            true
        ) ?? [];

    }

}

// --------------------------------------------------
// SQLite öffnen
// --------------------------------------------------

try {

    $db = new PDO(
        "sqlite:/var/www/html/sqlite/tools.sqlite"
    );

    $db->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

    echo "<p>Datenbank erfolgreich geöffnet.</p>";

    // --------------------------------------------------
    // GitHub-Versionen ermitteln
    // --------------------------------------------------

    $releases = [];

    // Jedes Repository nur einmal abfragen

    $repositories = array_unique(
        array_column($tools, "repository")
    );

    foreach ($repositories as $repository) {

        try {

            $lastUpdate =
                $cache[$repository]["last_update"] ?? 0;

            // Cache verwenden

            if (
                (time() - $lastUpdate) < $updateInterval &&
                isset($cache[$repository]["version"]) &&
                isset($cache[$repository]["assets"])
            ) {

                $releases[$repository] = [
                    "version" => $cache[$repository]["version"],
                    "assets" => $cache[$repository]["assets"]
                ];

                echo "<p>Cache verwendet: " .
                     htmlspecialchars($repository) .
                     "</p>";

            } else {

                // GitHub neu abfragen

                $release = getGitHubRelease($repository);

                $releases[$repository] = $release;

                // Cache aktualisieren

                $cache[$repository] = [
                    "version" => $release["version"],
                    "assets" => $release["assets"],
                    "last_update" => time()
                ];

                echo "<p>GitHub abgefragt: " .
                     htmlspecialchars($repository) .
                     " – Version " .
                     htmlspecialchars($release["version"]) .
                     "</p>";

            }

        } catch (Throwable $e) {

            // Vorhandenen Cache verwenden

            if (
                isset($cache[$repository]["version"]) &&
                isset($cache[$repository]["assets"])
            ) {

                $releases[$repository] = [
                    "version" => $cache[$repository]["version"],
                    "assets" => $cache[$repository]["assets"]
                ];

                echo "<p style='color:orange;'>";
                echo "GitHub-Fehler bei " .
                     htmlspecialchars($repository) .
                     ". Cache wird verwendet.";
                echo "</p>";

            } else {

                throw $e;

            }

        }

    }

    // --------------------------------------------------
    // Cache speichern
    // --------------------------------------------------

    $cacheResult = @file_put_contents(
        $cacheFile,
        json_encode(
            $cache,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
        ),
        LOCK_EX
    );

    if ($cacheResult === false) {

        echo "<p style='color:orange;'>";
        echo "Cache konnte nicht gespeichert werden.";
        echo "</p>";

    }

    // --------------------------------------------------
    // SQLite aktualisieren
    // --------------------------------------------------

    $db->beginTransaction();

    // --------------------------------------------------
    // Fehlende Download-Spalten anlegen
    // --------------------------------------------------

    foreach ($tools as $table => $config) {

        // Tabellenstruktur ermitteln

        $columns = $db->query(
            "PRAGMA table_info(\"$table\")"
        )->fetchAll(PDO::FETCH_ASSOC);

        if (empty($columns)) {

            throw new Exception(
                "Tabelle nicht gefunden: " . $table
            );

        }

        $columnNames = array_column(
            $columns,
            "name"
        );

        // Download-Spalte anlegen

        if (!in_array("Download", $columnNames)) {

            $db->exec(
                "ALTER TABLE \"$table\" ADD COLUMN Download TEXT"
            );

            echo "<p>Download-Spalte angelegt: " .
                 htmlspecialchars($table) .
                 "</p>";

            // Alte Schreibweise übernehmen

            if (in_array("Downlaod", $columnNames)) {

                $db->exec(
                    "UPDATE \"$table\"
                     SET Download = Downlaod
                     WHERE Downlaod IS NOT NULL"
                );

            }

        }

        // Aktuell muss vorhanden sein

        if (!in_array("Aktuell", $columnNames)) {

            throw new Exception(
                "Spalte Aktuell fehlt in Tabelle: " . $table
            );

        }

    }

    // --------------------------------------------------
    // Versionsnummern in SQLite speichern
    // --------------------------------------------------

    foreach ($tools as $table => $config) {

        $repository = $config["repository"];

        $version = $releases[$repository]["version"];

        // Datensätze ermitteln

        $count = $db->query(
            "SELECT COUNT(*) FROM \"$table\""
        )->fetchColumn();

        if ($count > 0) {

            // Vorhandene Version aktualisieren

            $stmt = $db->prepare(
                "UPDATE \"$table\"
                 SET Aktuell = :version"
            );

            $stmt->execute([
                ":version" => $version
            ]);

        } else {

            // Falls Tabelle leer ist

            $stmt = $db->prepare(
                "INSERT INTO \"$table\"
                 (Installiert, Aktuell, Download)
                 VALUES (NULL, :version, '')"
            );

            $stmt->execute([
                ":version" => $version
            ]);

        }

        echo "<p>Version " .
             htmlspecialchars($table) .
             ": <strong>" .
             htmlspecialchars($version) .
             "</strong></p>";

    }

    // --------------------------------------------------
    // Download-Links anhand von Aktuell ermitteln
    // --------------------------------------------------

    echo "<h3>Download-Zuordnung</h3>";

    foreach ($tools as $table => $config) {

        // SVWS erhält keinen Download

        if ($config["download"] === null) {

            $stmt = $db->prepare(
                "UPDATE \"$table\" SET Download = ''"
            );

            $stmt->execute();

            echo "<p><strong>" .
                 htmlspecialchars($table) .
                 "</strong><br>";

            echo "Kein Download vorgesehen.</p>";

            continue;

        }

        // Aktuelle Versionsnummer aus SQLite lesen

        $stmt = $db->query(
            "SELECT Aktuell FROM \"$table\" LIMIT 1"
        );

        $version = $stmt->fetchColumn();

        if (
            $version === false ||
            $version === null ||
            $version === ""
        ) {

            throw new Exception(
                "Keine Versionsnummer in Aktuell: " . $table
            );

        }

        // ZIP-Dateinamen bilden

        $filename = str_replace(
            "{VERSION}",
            $version,
            $config["download"]
        );

        $repository = $config["repository"];

        // Passende Datei im GitHub-Release suchen

        $assets = $releases[$repository]["assets"];

        $download = $assets[$filename] ?? "";

        // Download-Link speichern

        $stmt = $db->prepare(
            "UPDATE \"$table\"
             SET Download = :download"
        );

        $stmt->execute([
            ":download" => $download
        ]);

        echo "<p><strong>" .
             htmlspecialchars($table) .
             "</strong><br>";

        echo "Version: " .
             htmlspecialchars($version) .
             "<br>";

        echo "Gesuchte Datei: " .
             htmlspecialchars($filename) .
             "<br>";

        if ($download !== "") {

            echo "<span style='color:green;'>";
            echo "Download gefunden.";
            echo "</span>";

        } else {

            echo "<span style='color:red;'>";
            echo "Download-Datei nicht gefunden!";
            echo "</span>";

        }

        echo "</p>";

    }

    // --------------------------------------------------
    // Transaktion abschließen
    // --------------------------------------------------

    $db->commit();

    echo "<hr>";

    echo "<h3 style='color:green;'>";
    echo "Alle SVWS-Tools erfolgreich aktualisiert!";
    echo "</h3>";

} catch (Throwable $e) {

    // Bei Fehlern zurückrollen

    if (
        isset($db) &&
        $db->inTransaction()
    ) {

        $db->rollBack();

    }

    echo "<h3 style='color:red;'>Fehler:</h3>";

    echo htmlspecialchars(
        $e->getMessage(),
        ENT_QUOTES,
        'UTF-8'
    );

}

?>