<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ==================================================
// SVWS-Tools Versionsprüfung und ZIP-Download
// GitHub-Abfrage maximal alle 24 Stunden
// ==================================================

echo "<h2>SVWS-Tools Versionsprüfung</h2>";

// --------------------------------------------------
// GitHub Release URLs
// --------------------------------------------------

$url_SVWS      = "https://api.github.com/repos/SVWS-NRW/SVWS-Server/releases/latest";
$url_Import    = "https://api.github.com/repos/SVWS-NRW/SVWS-Import/releases/latest";
$url_Prognos   = "https://api.github.com/repos/SVWS-NRW/SVWS-Prognos/releases/latest";
$url_Conference = "https://api.github.com/repos/SVWS-NRW/SVWS-Conference/releases/latest";
$url_GradeHub  = "https://api.github.com/repos/SVWS-NRW/SVWS-GradeHub/releases/latest";

// --------------------------------------------------
// Tabellen, GitHub-URLs und ZIP-Dateinamen
// zip = null bedeutet: nur SQLite-Version aktualisieren
// --------------------------------------------------

$tools = [
    "svws" => [
        "url" => $url_SVWS,
        "zip" => null
    ],
    "laufbahn" => [
        "url" => $url_SVWS,
        "zip" => "SVWS-Laufbahnplanung-%s.zip"
    ],
    "wenom" => [
        "url" => $url_SVWS,
        "zip" => "WeNoM-%s.zip"
    ],
    "import" => [
        "url" => $url_Import,
        "zip" => "SVWS-Import-%s-webapp.zip"
    ],
    "prognos" => [
        "url" => $url_Prognos,
        "zip" => "SVWS-Prognos-%s-webserver.zip"
    ],
    "conference" => [
        "url" => $url_Conference,
        "zip" => "svws-conference-%s-webserver.zip"
    ],
    "gradehub" => [
        "url" => $url_GradeHub,
        "zip" => "gradehub-%s-webserver.zip"
    ]
];

// --------------------------------------------------
// Verzeichnisse und Cache-Einstellungen
// --------------------------------------------------

$zipDir = "/var/www/html/zip/";
$cacheFile = "/var/www/html/sqlite/versions-download-cache.json";
$dbFile = "/var/www/html/sqlite/tools.sqlite";
$updateInterval = 24 * 60 * 60;

if (!is_dir($zipDir)) {
    if (!mkdir($zipDir, 0775, true) && !is_dir($zipDir)) {
        throw new Exception("Download-Verzeichnis konnte nicht erstellt werden: " . $zipDir);
    }
}

// --------------------------------------------------
// GitHub Release auslesen
// --------------------------------------------------

function getGitHubRelease($url)
{
    $options = [
        "http" => [
            "header" =>
                "User-Agent: SVWS-Tools\r\n" .
                "Accept: application/vnd.github+json\r\n",
            "timeout" => 30,
            "ignore_errors" => true
        ]
    ];

    $context = stream_context_create($options);
    $response = @file_get_contents($url, false, $context);

    if ($response === false) {
        throw new Exception("GitHub konnte nicht erreicht werden: " . $url);
    }

    $httpStatus = $http_response_header[0] ?? "";

    if (strpos($httpStatus, "200") === false) {
        throw new Exception("GitHub API Fehler: " . $httpStatus);
    }

    $data = json_decode($response, true);

    if (!isset($data["tag_name"])) {
        throw new Exception("Keine Release-Version gefunden: " . $url);
    }

    return [
        "version" => preg_replace('/^v/', '', $data["tag_name"]),
        "assets" => $data["assets"] ?? []
    ];
}

// --------------------------------------------------
// Exakt passende ZIP-Datei herunterladen
// --------------------------------------------------

function downloadZip($release, $zipName, $zipDir)
{
    $downloadUrl = null;

    foreach ($release["assets"] as $asset) {
        if (($asset["name"] ?? "") === $zipName) {
            $downloadUrl = $asset["browser_download_url"] ?? null;
            break;
        }
    }

    if ($downloadUrl === null) {
        throw new Exception("ZIP-Datei nicht im GitHub-Release gefunden: " . $zipName);
    }

    $target = $zipDir . $zipName;
    $temp = $target . ".tmp";

    // Bereits vorhandene ZIP-Datei nicht erneut herunterladen
    if (file_exists($target) && filesize($target) > 0) {
        return filesize($target);
    }

    $options = [
        "http" => [
            "header" => "User-Agent: SVWS-Tools\r\n",
            "timeout" => 180,
            "follow_location" => 1,
            "max_redirects" => 10
        ]
    ];

    $context = stream_context_create($options);
    $input = @fopen($downloadUrl, "rb", false, $context);

    if ($input === false) {
        throw new Exception("Download fehlgeschlagen: " . $downloadUrl);
    }

    $output = @fopen($temp, "wb");

    if ($output === false) {
        fclose($input);
        throw new Exception("ZIP-Datei kann nicht angelegt werden: " . $temp);
    }

    $bytes = stream_copy_to_stream($input, $output);
    fclose($input);
    fclose($output);

    if ($bytes === false || $bytes === 0) {
        @unlink($temp);
        throw new Exception("ZIP-Download fehlgeschlagen: " . $zipName);
    }

    if (!rename($temp, $target)) {
        @unlink($temp);
        throw new Exception("ZIP-Datei konnte nicht gespeichert werden: " . $target);
    }

    return $bytes;
}

// --------------------------------------------------
// Hauptprogramm
// --------------------------------------------------

try {
    // SQLite-Datenbank öffnen
    $db = new PDO("sqlite:" . $dbFile);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "<p>Datenbank erfolgreich geöffnet.</p>";

    // Cache laden
    $cache = [];

    if (file_exists($cacheFile)) {
        $cacheContent = @file_get_contents($cacheFile);
        if ($cacheContent !== false) {
            $cache = json_decode($cacheContent, true) ?? [];
        }
    }

    $lastUpdate = $cache["last_update"] ?? 0;
    $releases = $cache["releases"] ?? [];
    $cacheValid = ((time() - $lastUpdate) < $updateInterval) && !empty($releases);

    // GitHub-Releases abrufen oder Cache verwenden
    if ($cacheValid) {
        echo "<p>Gespeicherter GitHub-Cache wird verwendet.</p>";
    } else {
        echo "<p>GitHub-Releases werden aktualisiert.</p>";

        $allRequestsSuccessful = true;

        // Jede unterschiedliche GitHub-URL nur einmal abfragen
        $uniqueUrls = array_unique(array_column($tools, "url"));

        foreach ($uniqueUrls as $url) {
            try {
                $releases[$url] = getGitHubRelease($url);
                echo "<p style='color:green;'>GitHub-Abfrage erfolgreich: " .
                     htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . "</p>";
            } catch (Throwable $e) {
                $allRequestsSuccessful = false;
                echo "<p style='color:orange;'>GitHub-Abfrage fehlgeschlagen: " .
                     htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . "</p>";

                // Ein eventuell vorhandener Cache-Eintrag bleibt erhalten.
            }
        }

        // Cache-Zeitpunkt nur erneuern, wenn alle GitHub-Abfragen erfolgreich waren
        if ($allRequestsSuccessful) {
            $cache = [
                "last_update" => time(),
                "releases" => $releases
            ];

            if (@file_put_contents(
                $cacheFile,
                json_encode($cache, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES),
                LOCK_EX
            ) === false) {
                echo "<p style='color:orange;'>GitHub-Cache konnte nicht gespeichert werden.</p>";
            } else {
                echo "<p style='color:green;'>GitHub-Cache erfolgreich aktualisiert.</p>";
            }
        } else {
            echo "<p style='color:orange;'>Vorhandene Cache-Versionen werden soweit möglich weiterverwendet.</p>";
        }
    }

    // Datenbank aktualisieren
    $db->beginTransaction();

    foreach ($tools as $table => $tool) {
        echo "<hr><h3>" . htmlspecialchars($table, ENT_QUOTES, 'UTF-8') . "</h3>";

        $url = $tool["url"];

        if (!isset($releases[$url]["version"])) {
            echo "<span style='color:red;'>Keine Release-Version verfügbar.</span><br>";
            continue;
        }

        $release = $releases[$url];
        $aktuell = $release["version"];

        // Installierte Version aus SQLite lesen
        $stmt = $db->query("SELECT Installiert FROM \"$table\" LIMIT 1");
        $installiert = $stmt->fetchColumn();

        echo "Installiert: " . htmlspecialchars($installiert ?: "Nicht vorhanden", ENT_QUOTES, 'UTF-8') . "<br>";
        echo "Aktuell: " . htmlspecialchars($aktuell, ENT_QUOTES, 'UTF-8') . "<br>";

        // ZIP-Download nur für Tools mit konfiguriertem ZIP-Namen
        if ($tool["zip"] !== null) {
            $zipName = sprintf($tool["zip"], $aktuell);
            echo "ZIP-Datei: " . htmlspecialchars($zipName, ENT_QUOTES, 'UTF-8') . "<br>";

            if (!empty($installiert) && version_compare($aktuell, $installiert, '>')) {
                echo "<strong>Neue Version gefunden!</strong><br>";

                $bytes = downloadZip($release, $zipName, $zipDir);

                echo "<span style='color:green;'>ZIP erfolgreich vorhanden!</span><br>";
                echo "Dateigröße: " . number_format($bytes / 1024 / 1024, 2, ',', '.') . " MB<br>";
            } else {
                echo "Keine neue Version vorhanden.<br>";
            }
        } else {
            echo "Für diese Tabelle ist kein ZIP-Download vorgesehen.<br>";
        }

        // Aktuelle Version aktualisieren; falls die Tabelle leer ist, Datensatz anlegen
        $count = (int)$db->query("SELECT COUNT(*) FROM \"$table\"")->fetchColumn();

        if ($count > 0) {
            $stmt = $db->prepare("UPDATE \"$table\" SET Aktuell = :version");
            $stmt->execute([":version" => $aktuell]);
        } else {
            $stmt = $db->prepare(
                "INSERT INTO \"$table\" (Installiert, Aktuell) VALUES (NULL, :version)"
            );
            $stmt->execute([":version" => $aktuell]);
        }

        echo "<span style='color:green;'>SQLite erfolgreich aktualisiert.</span><br>";
    }

    $db->commit();
    echo "<hr><h2>Versionsprüfung abgeschlossen!</h2>";

} catch (Throwable $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }

    echo "<h3 style='color:red;'>Fehler:</h3>";
    echo htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
}

?>