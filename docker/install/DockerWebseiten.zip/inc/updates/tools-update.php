
<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ==================================================
// SVWS-Tools Versionsvergleich und automatischer ZIP-Download
// Versionsdaten und Download-URLs direkt aus SQLite
// ==================================================

echo "<h2>SVWS-Tools Versionsprüfung und Download</h2>";


// --------------------------------------------------
// Verzeichnisse
// --------------------------------------------------

$dbFile = "/var/www/html/sqlite/tools.sqlite";
$zipDir = "/var/www/html/zip/";


// --------------------------------------------------
// Tabellen
// --------------------------------------------------

$tools = [
    "laufbahn",
    "wenom",
    "import",
    "prognos",
    "conference",
    "gradehub"
];


// --------------------------------------------------
// HTML-Ausgabe absichern
// --------------------------------------------------

function h($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


// --------------------------------------------------
// ZIP-Verzeichnis erstellen
// --------------------------------------------------

if (!is_dir($zipDir)) {

    if (!mkdir($zipDir, 0775, true) && !is_dir($zipDir)) {
        throw new Exception(
            "Download-Verzeichnis konnte nicht erstellt werden."
        );
    }

}


// --------------------------------------------------
// ZIP-Datei herunterladen
// --------------------------------------------------

function downloadZip($downloadUrl, $zipDir)
{

    // URL prüfen

    if (
        !filter_var($downloadUrl, FILTER_VALIDATE_URL) ||
        parse_url($downloadUrl, PHP_URL_SCHEME) !== "https" ||
        empty(parse_url($downloadUrl, PHP_URL_HOST))
    ) {
        throw new Exception("Ungültige Download-URL.");
    }


    // Dateinamen aus URL ermitteln

    $path = parse_url($downloadUrl, PHP_URL_PATH);

    $zipName = basename(rawurldecode($path));

    $zipName = preg_replace(
        '/[^A-Za-z0-9._-]/',
        '_',
        $zipName
    );


    if (
        empty($zipName) ||
        strtolower(pathinfo($zipName, PATHINFO_EXTENSION)) !== "zip"
    ) {
        throw new Exception(
            "Die URL verweist nicht auf eine ZIP-Datei."
        );
    }


    $target = $zipDir . $zipName;
    $temp = $target . ".tmp";


    // Vorhandene ZIP-Datei prüfen

    if (file_exists($target) && filesize($target) > 0) {

        $handle = fopen($target, "rb");

        $signature = $handle ? fread($handle, 2) : "";

        if ($handle) {
            fclose($handle);
        }

        if ($signature === "PK") {

            return [
                "name" => $zipName,
                "size" => filesize($target),
                "existing" => true
            ];

        }

        @unlink($target);

    }


    // Alte temporäre Datei entfernen

    if (file_exists($temp)) {
        @unlink($temp);
    }


    // Temporäre Datei öffnen

    $output = @fopen($temp, "wb");

    if ($output === false) {
        throw new Exception(
            "Temporäre ZIP-Datei kann nicht angelegt werden."
        );
    }


    // cURL Download

    $ch = curl_init($downloadUrl);

    curl_setopt_array($ch, [

        CURLOPT_FILE => $output,

        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 10,

        CURLOPT_CONNECTTIMEOUT => 30,
        CURLOPT_TIMEOUT => 600,

        CURLOPT_USERAGENT => "SVWS-Tools",

        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,

        CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
        CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,

        CURLOPT_FAILONERROR => true

    ]);


    $success = curl_exec($ch);

    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    $curlError = curl_error($ch);

    curl_close($ch);

    fclose($output);


    // Download überprüfen

    if ($success === false || $httpCode !== 200) {

        @unlink($temp);

        throw new Exception(
            "Download fehlgeschlagen: HTTP " .
            $httpCode . " - " . $curlError
        );

    }


    clearstatcache(true, $temp);

    $actualSize = file_exists($temp)
        ? filesize($temp)
        : 0;


    if ($actualSize <= 0) {

        @unlink($temp);

        throw new Exception(
            "Die heruntergeladene ZIP-Datei ist leer."
        );

    }


    // ZIP-Signatur prüfen

    $handle = fopen($temp, "rb");

    $signature = $handle ? fread($handle, 2) : "";

    if ($handle) {
        fclose($handle);
    }


    if ($signature !== "PK") {

        @unlink($temp);

        throw new Exception(
            "Die heruntergeladene Datei ist keine gültige ZIP-Datei."
        );

    }


    // ZIP-Datei endgültig speichern

    if (!rename($temp, $target)) {

        @unlink($temp);

        throw new Exception(
            "ZIP-Datei konnte nicht gespeichert werden."
        );

    }


    return [
        "name" => $zipName,
        "size" => $actualSize,
        "existing" => false
    ];

}


// ==================================================
// HAUPTPROGRAMM
// ==================================================

try {

    // --------------------------------------------------
    // SQLite-Datenbank öffnen
    // --------------------------------------------------

    $db = new PDO("sqlite:" . $dbFile);

    $db->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

    echo "<p style='color:green;'>";
    echo "Datenbank erfolgreich geöffnet.";
    echo "</p>";


    // --------------------------------------------------
    // Alle Tabellen durchlaufen
    // --------------------------------------------------

    foreach ($tools as $table) {

        echo "<hr>";

        echo "<h3>" . h($table) . "</h3>";


        // --------------------------------------------------
        // Daten aus SQLite lesen
        // --------------------------------------------------

        $stmt = $db->query(
            "SELECT Installiert, Aktuell, Download
             FROM \"$table\""
        );


        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);


        if (empty($rows)) {

            echo "<span style='color:orange;'>";
            echo "Keine Datensätze vorhanden.";
            echo "</span>";

            continue;

        }


        // --------------------------------------------------
        // Datensätze durchlaufen
        // --------------------------------------------------

        foreach ($rows as $row) {

            $installiert = trim(
                (string)($row["Installiert"] ?? "")
            );

            $aktuell = trim(
                (string)($row["Aktuell"] ?? "")
            );

            $downloadUrl = trim(
                (string)($row["Download"] ?? "")
            );


            echo "<strong>Installiert:</strong> ";
            echo h($installiert ?: "Nicht vorhanden");
            echo "<br>";

            echo "<strong>Aktuell:</strong> ";
            echo h($aktuell ?: "Nicht vorhanden");
            echo "<br>";


            // --------------------------------------------------
            // Versionen prüfen
            // --------------------------------------------------

            if (
                empty($aktuell) ||
                empty($installiert)
            ) {

                echo "<span style='color:orange;'>";
                echo "Versionsvergleich nicht möglich.";
                echo "</span><br>";

                continue;

            }


            if (!version_compare($aktuell, $installiert, '>')) {

                echo "<span style='color:blue;'>";
                echo "Keine neue Version vorhanden.";
                echo "</span><br>";

                continue;

            }


            // --------------------------------------------------
            // Neue Version vorhanden
            // --------------------------------------------------

            echo "<strong style='color:green;'>";
            echo "Neue Version gefunden!";
            echo "</strong><br>";


            // --------------------------------------------------
            // Download-URL prüfen
            // --------------------------------------------------

            if (empty($downloadUrl)) {

                echo "<span style='color:orange;'>";
                echo "Keine Download-URL in SQLite vorhanden.";
                echo "</span><br>";

                continue;

            }


            echo "<strong>Download-URL:</strong> ";
            echo h($downloadUrl);
            echo "<br>";


            // --------------------------------------------------
            // ZIP-Datei herunterladen
            // --------------------------------------------------

            try {

                $result = downloadZip(
                    $downloadUrl,
                    $zipDir
                );


                if ($result["existing"]) {

                    echo "<span style='color:blue;'>";
                    echo "ZIP-Datei bereits vorhanden.";
                    echo "</span><br>";

                } else {

                    echo "<span style='color:green;'>";
                    echo "ZIP erfolgreich heruntergeladen!";
                    echo "</span><br>";

                }


                echo "<strong>Dateiname:</strong> ";
                echo h($result["name"]);
                echo "<br>";


                echo "<strong>Speicherort:</strong> ";
                echo h($zipDir . $result["name"]);
                echo "<br>";


                echo "<strong>Dateigröße:</strong> ";

                echo number_format(
                    $result["size"] / 1024 / 1024,
                    2,
                    ',',
                    '.'
                );

                echo " MB<br>";


            } catch (Throwable $e) {

                echo "<span style='color:red;'>";
                echo "Downloadfehler: ";
                echo h($e->getMessage());
                echo "</span><br>";

            }

        }

    }


    // --------------------------------------------------
    // Abschluss
    // --------------------------------------------------

    echo "<hr>";

    echo "<h2 style='color:green;'>";
    echo "Versionsprüfung abgeschlossen!";
    echo "</h2>";

    echo "<p>Download-Verzeichnis: ";
    echo h($zipDir);
    echo "</p>";


} catch (Throwable $e) {

    echo "<h3 style='color:red;'>Fehler:</h3>";

    echo h($e->getMessage());

}

?>
