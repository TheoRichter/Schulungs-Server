
<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h2>SVWS Versionsprüfung</h2>";

// --------------------------------------------------
// GitHub Release URLs
// --------------------------------------------------

$url_SVWS = "https://api.github.com/repos/SVWS-NRW/SVWS-Server/releases/latest";

$url_Import = "https://api.github.com/repos/SVWS-NRW/SVWS-Import/releases/latest";

$url_Prognos = "https://api.github.com/repos/SVWS-NRW/SVWS-Prognos/releases/latest";

$url_Conference = "https://api.github.com/repos/SVWS-NRW/SVWS-Conference/releases/latest";

$url_GradeHub = "https://api.github.com/repos/SVWS-NRW/SVWS-GradeHub/releases/latest";


// --------------------------------------------------
// Tabellen und zugehörige GitHub-URLs
// --------------------------------------------------

$tools = [
    "laufbahn"   => $url_SVWS,
    "wenom"      => $url_SVWS,
    "import"     => $url_Import,
    "prognos"    => $url_Prognos,
    "conference" => $url_Conference,
    "gradehub"   => $url_GradeHub
];


// --------------------------------------------------
// GitHub-Version auslesen
// --------------------------------------------------

function getGitHubVersion($url) {

    $options = [
        "http" => [
            "header" =>
                "User-Agent: SVWS-Tools\r\n" .
                "Accept: application/vnd.github+json\r\n",
            "timeout" => 20,
            "ignore_errors" => true
        ]
    ];

    $context = stream_context_create($options);

    $response = file_get_contents($url, false, $context);

    if ($response === false) {
        throw new Exception("GitHub konnte nicht erreicht werden: $url");
    }

    $data = json_decode($response, true);

    if (!isset($data["tag_name"])) {
        throw new Exception("Keine Release-Version gefunden: $url");
    }

    return preg_replace('/^v/', '', $data["tag_name"]);
}


// --------------------------------------------------
// GitHub-Versionen abrufen
// --------------------------------------------------

try {

    $versions = [];

    foreach (array_unique($tools) as $url) {

        $versions[$url] = getGitHubVersion($url);

    }

    echo "<h3>GitHub-Versionen</h3>";

    foreach ($tools as $table => $url) {

        echo htmlspecialchars($table) . ": <strong>" .
             htmlspecialchars($versions[$url]) .
             "</strong><br>";

    }


    // --------------------------------------------------
    // SQLite-Datenbank öffnen
    // --------------------------------------------------

    $db = new PDO("sqlite:/var/www/html/sqlite/tools.sqlite");

    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "<br>Datenbank erfolgreich geöffnet.<br>";


    // --------------------------------------------------
    // Datenbank aktualisieren
    // --------------------------------------------------

    $db->beginTransaction();

    foreach ($tools as $table => $url) {

        $version = $versions[$url];

        // Vorhandene Datensätze ermitteln
        $count = $db->query(
            "SELECT COUNT(*) FROM \"$table\""
        )->fetchColumn();

        if ($count > 0) {

            // Vorhandene Version aktualisieren
            $stmt = $db->prepare(
                "UPDATE \"$table\" SET Aktuell = :version"
            );

            $stmt->execute([
                ":version" => $version
            ]);

        } else {

            // Falls Tabelle noch leer ist
            $stmt = $db->prepare(
                "INSERT INTO \"$table\" (Installiert, Aktuell)
                 VALUES (NULL, :version)"
            );

            $stmt->execute([
                ":version" => $version
            ]);

        }

        echo htmlspecialchars($table) .
             " erfolgreich aktualisiert: <strong>" .
             htmlspecialchars($version) .
             "</strong><br>";

    }

    $db->commit();

    echo "<br><h3>Alle SVWS-Tools erfolgreich aktualisiert!</h3>";


} catch (Throwable $e) {

    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }

    echo "<h3>Fehler:</h3>";

    echo htmlspecialchars(
        $e->getMessage(),
        ENT_QUOTES,
        'UTF-8'
    );

}

?>
