
<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h2>SVWS Versionsprüfung</h2>";

// --------------------------------------------------
// GitHub Release URLs
// --------------------------------------------------

$url_SVWS = "https://api.github.com/repos/SVWS-NRW/SVWS-Server/releases/latest";
$url_Import = "https://api.github.com/repos/SVWS-NRW/SVWS-Import/releases/latest";
$url_Prognos = "https://api.github.com/repos/SVWS-NRW/SVWS-Prognos/releases/latest";
$url_Conference = "https://api.github.com/repos/SVWS-NRW/SVWS-Conference/releases/latest";
$url_GradeHub = "https://api.github.com/repos/SVWS-NRW/SVWS-GradeHub/releases/latest";


// --------------------------------------------------
// Tools und ZIP-Dateinamen
// --------------------------------------------------

$tools = [

    "laufbahn" => [
        "url" => $url_SVWS,
        "zip" => "SVWS-Laufbahnplanung-%s.zip"
    ],

    "wenom" => [
        "url" => $url_SVWS,
        "zip" => "WeNoM-%s.zip"
    ],

    "import" => [
        "url" => $url_Import,
        "zip" => "SVWS-Import-%s-webapp.zip"
    ],

    "prognos" => [
        "url" => $url_Prognos,
        "zip" => "SVWS-Prognos-%s-webserver.zip"
    ],

    "conference" => [
        "url" => $url_Conference,
        "zip" => "svws-conference-%s-webserver.zip"
    ],

    "gradehub" => [
        "url" => $url_GradeHub,
        "zip" => "gradehub-%s-webserver.zip"
    ]

];


// --------------------------------------------------
// Download-Verzeichnis
// --------------------------------------------------

$zipDir = "/var/www/html/zip/";

if (!is_dir($zipDir)) {
    if (!mkdir($zipDir, 0775, true)) {
        throw new Exception("Download-Verzeichnis konnte nicht erstellt werden.");
    }
}


// --------------------------------------------------
// GitHub Release auslesen
// --------------------------------------------------

function getGitHubRelease($url) {

    $options = [
        "http" => [
            "header" =>
                "User-Agent: SVWS-Tools\r\n" .
                "Accept: application/vnd.github+json\r\n",
            "timeout" => 30,
            "ignore_errors" => true
        ]
    ];

    $context = stream_context_create($options);

    $response = file_get_contents($url, false, $context);

    if ($response === false) {
        throw new Exception("GitHub konnte nicht erreicht werden: $url");
    }

    $data = json_decode($response, true);

    if (!isset($data["tag_name"])) {
        throw new Exception("Keine Release-Version gefunden: $url");
    }

    return [
        "version" => preg_replace('/^v/', '', $data["tag_name"]),
        "assets" => $data["assets"] ?? []
    ];
}


// --------------------------------------------------
// Exakt passende ZIP-Datei herunterladen
// --------------------------------------------------

function downloadZip($release, $zipName, $zipDir) {

    $downloadUrl = null;

    // Exakten Dateinamen suchen
    foreach ($release["assets"] as $asset) {

        if ($asset["name"] === $zipName) {

            $downloadUrl = $asset["browser_download_url"];
            break;

        }

    }

    if ($downloadUrl === null) {
        throw new Exception(
            "ZIP-Datei nicht im GitHub-Release gefunden: " . $zipName
        );
    }

    $target = $zipDir . $zipName;
    $temp = $target . ".tmp";

    $options = [
        "http" => [
            "header" => "User-Agent: SVWS-Tools\r\n",
            "timeout" => 180,
            "follow_location" => 1,
            "max_redirects" => 10
        ]
    ];

    $context = stream_context_create($options);

    $input = fopen($downloadUrl, "rb", false, $context);

    if ($input === false) {
        throw new Exception("Download fehlgeschlagen: " . $downloadUrl);
    }

    $output = fopen($temp, "wb");

    if ($output === false) {
        fclose($input);
        throw new Exception("ZIP-Datei kann nicht angelegt werden.");
    }

    $bytes = stream_copy_to_stream($input, $output);

    fclose($input);
    fclose($output);

    if ($bytes === false || $bytes === 0) {

        @unlink($temp);

        throw new Exception("ZIP-Download fehlgeschlagen: " . $zipName);

    }

    if (!rename($temp, $target)) {

        @unlink($temp);

        throw new Exception("ZIP-Datei konnte nicht gespeichert werden.");

    }

    return $bytes;
}


// --------------------------------------------------
// SQLite-Datenbank öffnen
// --------------------------------------------------

try {

    $db = new PDO("sqlite:/var/www/html/sqlite/tools.sqlite");

    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "<h3>Datenbank erfolgreich geöffnet.</h3>";


    // --------------------------------------------------
    // GitHub-Releases einmalig abrufen
    // --------------------------------------------------

    $releases = [];

    foreach ($tools as $tool) {

        $url = $tool["url"];

        if (!isset($releases[$url])) {
            $releases[$url] = getGitHubRelease($url);
        }

    }


    // --------------------------------------------------
    // Versionsvergleich und Download
    // --------------------------------------------------

    $db->beginTransaction();

    foreach ($tools as $table => $tool) {

        echo "<hr><h3>" .
             htmlspecialchars($table) .
             "</h3>";

        $release = $releases[$tool["url"]];

        $aktuell = $release["version"];

        // Exakten ZIP-Dateinamen erstellen
        $zipName = sprintf($tool["zip"], $aktuell);


        // Installierte Version auslesen
        $stmt = $db->query(
            "SELECT Installiert FROM \"$table\" LIMIT 1"
        );

        $installiert = $stmt->fetchColumn();

        echo "Installiert: " .
             htmlspecialchars($installiert ?: "Nicht vorhanden") .
             "<br>";

        echo "Aktuell: " .
             htmlspecialchars($aktuell) .
             "<br>";

        echo "ZIP-Datei: " .
             htmlspecialchars($zipName) .
             "<br>";


        // --------------------------------------------------
        // Versionsvergleich
        // --------------------------------------------------

        if (
            !empty($installiert) &&
            version_compare($aktuell, $installiert, '>')
        ) {

            echo "<strong>Neue Version gefunden!</strong><br>";

            // ZIP herunterladen
            $bytes = downloadZip(
                $release,
                $zipName,
                $zipDir
            );

            echo "<span style='color:green;'>ZIP erfolgreich heruntergeladen!</span><br>";

            echo "Dateigröße: " .
                 number_format($bytes / 1024 / 1024, 2) .
                 " MB<br>";

        } else {

            echo "Keine neue Version vorhanden.<br>";

        }


        // --------------------------------------------------
        // Aktuelle Version in SQLite aktualisieren
        // --------------------------------------------------

        $stmt = $db->prepare(
            "UPDATE \"$table\" SET Aktuell = :version"
        );

        $stmt->execute([
            ":version" => $aktuell
        ]);

        echo "SQLite erfolgreich aktualisiert.<br>";

    }

    $db->commit();

    echo "<hr><h2>Versionsprüfung abgeschlossen!</h2>";

} catch (Throwable $e) {

    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }

    echo "<h3 style='color:red;'>Fehler:</h3>";

    echo htmlspecialchars(
        $e->getMessage(),
        ENT_QUOTES,
        'UTF-8'
    );

}

?>
