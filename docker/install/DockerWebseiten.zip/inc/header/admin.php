<style>
.label-large {
    font-size: 18px;
    padding: 6px 12px;
    display: inline-block;
}
</style>
<div class="w3-row">
 <nav class="navbar">
  <div class="container-fluid">
<!-- navbar rechts -->
   <ul class="nav navbar-nav navbar-left">
     <li>&nbsp;</li>
     <li class="dropdown active">
     <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-success label-large height-label"><img src="../svg/bookmarks.svg" alt="Bookmark" width="20" height="20">&nbsp;Schemata <img src="../svg/caret-down-fill.svg" alt="Bookmark" width="20" height="20"></span></a>
      <ul class="dropdown-menu">
       <li class="divider"></li>
       <li><a href="alleSchemata.php"><span class="label label-primary label-large height-label"><img src="../svg/database.svg" alt="database.svg" width="20" height="20">&nbsp;alleSchemata</span></a></li>
       <li class="divider"></li>
       <li><a href="Schemata.php"><span class="label label-primary label-large height-label"><img src="../svg/database.svg" alt="database.svg" width="20" height="20">&nbsp;Schemata</span></a></li>
       <li class="divider"></li>
	 </ul>
	</li>
     <li>&nbsp;</li>
    <li class="dropdown active">
     <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-success label-large height-label"><img src="../svg/bookmarks.svg" alt="Bookmark" width="20" height="20">&nbsp;Tabellen <img src="../svg/caret-down-fill.svg" alt="Bookmark" width="20" height="20"></span></a>
      <ul class="dropdown-menu">
       <li class="divider"></li>
       <li><a href="Lehrer.php"><span class="label label-info label-large height-label"><img src="../svg/table.svg" alt="table.svg" width="20" height="20">&nbsp;Lehrer</span></a></li>
       <li class="divider"></li>
       <li><a href="Schueler.php"><span class="label label-info label-large height-label"><img src="../svg/table.svg" alt="table.svg" width="20" height="20">&nbsp;Sch&uuml;ler</span></a></li>
       <li class="divider"></li>
       <li><a href="Schuljahresabschnitte.php"><span class="label label-info label-large height-label"><img src="../svg/table.svg" alt="table.svg" width="20" height="20">&nbsp;Schuljahresabschnitte</span></a></li>
       <li class="divider"></li>
	 </ul>
	</li>
   </ul>
<!-- navbar links
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
 -->
 </div>
 </nav>
 </div>
</div>