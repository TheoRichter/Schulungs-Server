<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $benutzer = $_POST['benutzer'] ?? '';
    $kennwort = $_POST['kennwort'] ?? '';

    $db = new PDO('sqlite:login.sqlite');

    // Benutzer aus DB holen
    $stmt = $db->prepare("SELECT * FROM login WHERE Benutzer = ?");
    $stmt->execute([$benutzer]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && $kennwort === $user['Kennwort']) {
        // Login erfolgreich
        $_SESSION['benutzer'] = $benutzer;
        header("Location: ../../index.php");
        exit;
    } else {
        echo "Benutzername oder Passwort falsch.";
    }
}
?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html lang="de">
<head>
<title>Schulungszentrum-Login</title>
 <meta name="author" content="Dipl.Ing.Theo Richter">
 <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15">
 <meta name="description" content="">
 <link rel="shortcut icon" href="../../ico/favicon.png">
<!-- Bootstrap core CSS -->
 <link href="../../css/bootstrap.min.css" rel="stylesheet">
<!-- Custom styles for this template -->
 <link href="../../css/navbar.css" rel="stylesheet">
 <style>
  body {
   background-color: #f0f0f0;
   font-family: Arial, sans-serif;
   padding: 40px;
  }
 </style>
</head>
<body>
<section id="content"><!-- Anfang Mittelteil -->
 <div class="container">
  <div class="row">
   <div class="col-md-12">
     <p>&nbsp;</p>
     <p>&nbsp;</p>
   </div>
  </div>
  <div class="row">
   <div class="col-md-2">
     <p>&nbsp;</p>
   </div>
   <div class="col-md-8">
    <div class="well well-sm">
    <div class="form-group">
     <p>&nbsp;</p>
	 <p>&nbsp;</p>
    </div>
	<?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form class="form-horizontal" role="form" action="login.php" method="post">
     <div class="form-group">
       <label class="col-sm-3 control-label">Benutzername:</label>
     <div class="col-sm-8">
       <input class="form-control" type="text" name="benutzer"  placeholder="Benutzername" />
     </div>
    </div>
    <div class="form-group">
     <label for="inputPassword" class="col-sm-3 control-label">Kennwort:</label>
    <div class="col-sm-8">
     <input type="password" class="form-control" id="inputPassword" name="kennwort" placeholder="Kennwort">
    </div>
    <div class="form-group">
     <p>&nbsp;</p>
	 <p>&nbsp;</p>
    </div>
     <div class="form-group">
     <div class="col-sm-offset-5 col-sm-8">
      <button type="submit" class="btn btn-success">Anmelden</button>
     </div>
    </div>
   </form>
   <div class="col-md-2">
     <p>&nbsp;</p>
   </div>
  </div>
 </div>
</section><!-- Ende Mittelteil -->
<section id="footer"><!-- Anfang Footer -->
 <?php // include '../footer/footer.php' ?>
</section><!-- Ende Footer -->
<!-- Bootstrap core JavaScript
 ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
 <script src="../../js/jquery-1.10.2.min.js"></script>
 <script src="../../js/bootstrap.min.js"></script>
</body>
</html>