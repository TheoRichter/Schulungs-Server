<?php
session_start();
session_destroy();
header("Location: login.php"); 
exit;
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Logout</title>
  <script>
    // Optional: Elternfenster neu laden (wenn gewünscht)
    if (window.opener && !window.opener.closed) {
      window.opener.location.reload();
    }

    // Fenster schließen
    window.onload = function() {
      window.close();
    };
  </script>
</head>
<body>
  <p>Logout erfolgreich. Fenster wird geschlossen ...</p>
</body>
</html>