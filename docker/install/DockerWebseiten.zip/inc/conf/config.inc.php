<?php
// Variablen Definition
$LOCALEIP    = "00001";
$letzteZeile = "00002";
// Schemata
$datenbanken = [
    'Berufschule' => '/netzlaufwerk/OfficelleTestDBS/Berufschule/Berufschule.sqlite',
    'ENM_SVWS' => '/netzlaufwerk/OfficelleTestDBS/ENM-Json/ENM-Testdaten-01/ENM_SVWS.sqlite',
    'Gesamtschule' => '/netzlaufwerk/OfficelleTestDBS/Gesamtschule/Gesamtschule.sqlite',
    'Grundschule' => '/netzlaufwerk/OfficelleTestDBS/Grundschule/Grundschule.sqlite',
    'Grundschule_1Hj' => '/netzlaufwerk/OfficelleTestDBS/Grundschule/Grundschule_1Hj.sqlite',
    'Grundschule_2Hj' => '/netzlaufwerk/OfficelleTestDBS/Grundschule/Grundschule_2Hj.sqlite',
    'Grundschule_1HjLeistungsdaten' => '/netzlaufwerk/OfficelleTestDBS/Grundschule/Grundschule_1HjLeistungsdaten.sqlite',
    'Grundschule_2HjLeistungsdaten' => '/netzlaufwerk/OfficelleTestDBS/Grundschule/Grundschule_2HjLeistungsdaten.sqlite',
    'S1Schulung' => '/netzlaufwerk/OfficelleTestDBS/S1Schulung/S1Schulung.sqlite',
    'S2Schulung' => '/netzlaufwerk/OfficelleTestDBS/S2Schulung/S2Schulung.sqlite',
    'GOSt_DB-1_VorbereitungEFPlanung'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/GOSt_DB-1_VorbereitungEFPlanung.sqlite',
    'GOSt_DB-2_Laufbahnen10EF-zumBlocken'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/GOSt_DB-2_Laufbahnen10EF-zumBlocken.sqlite',
    'GOSt_DB-3_Blockungen10EFmitFehlern'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/GOSt_DB-3_Blockungen10EFmitFehlern.sqlite',
    'GOSt_DB-4-KlausurplanungEF2'   => '/netzlaufwerk/OfficelleTestDBS/Gymnasium/GOSt_DB-4-KlausurplanungEF2.sqlite'
];
?>
