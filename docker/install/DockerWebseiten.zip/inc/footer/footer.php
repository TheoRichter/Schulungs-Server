   <div style="background-color: #e5e5e5;">
    <div align="right">
     <font size="3" color="black">&numsp;(c)&numsp;by&numsp;Theo&numsp;Richter&numsp;in&numsp;0.2026&numsp;&numsp;&numsp;&numsp;Version 2.0.1</font>
    </div>
   </div>