   <div style="background-color: #e5e5e5;">
     <div align="right">
       <font size="3" color="green">&numsp;<b>(c)</b>&numsp;</font>
       <font size="3" color="">by</font>
       <font size="3" color="blue">Theo Richter</font>
       <font size="3" color="black"> in 10.2026</font>
       <font size="3" color="blue">Version 2.0.1</font>
       <img src="png/trans.png" class="" alt="trans.png" height="1" width="10">
    </div>
   </div>