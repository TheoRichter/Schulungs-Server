<html>
<head>
 <title>Eigenes Schemata</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/form.css">
  <link rel="shortcut icon" href="ico/favicon.png">
</head>
<body>
<?php
$skriptDatei = "sh/EigeneSchemata.sh";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $DBDatei = trim($_POST["art"] ?? "");
    $DBName = trim($_POST["name"] ?? "");
     // Lade Datei
     $inhalt = file_get_contents($skriptDatei);

     // Ersetze die Zeile mit Eigener_DB_NAME.DBDatei
     if (preg_match('/^[a-zA-Z]+$/', $DBName))
     {
        $inhaltNeu = preg_replace(
        [
         '/^DBDatei="[^"]*"/m',
         '/^Eigener_DB_NAME="[^"]*"/m'
        ],
        [
         'DBDatei="' . $DBDatei . '"',
         'Eigener_DB_NAME="' . $DBName . '"'
        ],
        $inhalt
        );
        // Schreibe Datei zurück
        file_put_contents($skriptDatei, $inhaltNeu);
       echo "<p class='echo'>Name des Schemata: <strong>$DBName</strong>, Endung: <strong>$DBDatei</strong> aktualisiert.</p>";
       include "close.php";  
    } else {
		if (isset($DBName) && !empty($DBName)) {	
         echo "<p style='color:red;'>Ungültige $DBName.</p>";
	    }
    }
}
?>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <iframe class="" src="/netzlaufwerk/OfficelleTestDBS/EigeneSchemata/" width="95%" height="305" frameborder="0" style="background-color:"></iframe>
 </div>
</div>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <form method="post">
    <label class="form" for="name">Den Namen des DatenbankSchemata Eingeben.</label>
    <input type="text" name="name" id="name" required><br /><br />
    <label class="form"for="art">sqlite oder mdb Ausw&auml;hlen.</label>
	<select id="art" name="art">
     <option value="sqlite">-</option>
      <option value="sqlite">sqlite</option>
     <option value="mdb">mdb</option>
    </select><br><br>	 
   <button type="submit">weiter</button>
  </form>
 </div>
</div>
</body>
</html>