<?php
$uploadDir = '/netzlaufwerk/installationfiles/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['zipfile']) && $_FILES['zipfile']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['zipfile']['tmp_name'];
        $fileName = basename($_FILES['zipfile']['name']);
        $destPath = $uploadDir . $fileName;

        // Prüfen ob es wirklich eine ZIP-Datei ist
        $fileType = mime_content_type($fileTmpPath);
        if ($fileType === 'application/zip' || pathinfo($fileName, PATHINFO_EXTENSION) === 'zip') {
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                echo "Datei erfolgreich hochgeladen nach: $destPath";
        echo "
        <!DOCTYPE html>
        <html>
         <head>
          <title>Automatisches Schließen</title>
         <script>
          // Warte 3 Sekunden und schließe dann das Fenster
          setTimeout(function () {
            window.close();
          }, 3000);
         </script>
        </head>
        <body>
         <p style='color:green;'>Diese Seite wird in 3 Sekunden automatisch geschlossen.</p>
        </body>
       </html>
       "; 
            } else {
                echo "Fehler beim Verschieben der Datei.";
            }
        } else {
            echo "Nur ZIP-Dateien sind erlaubt.";
        }
    } else {
        echo "Datei-Upload fehlgeschlagen.";
    }
}
?>
