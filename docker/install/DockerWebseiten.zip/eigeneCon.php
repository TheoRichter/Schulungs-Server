<html>
<head>
 <title>Eigene-Connection-Files Erstellen</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/form.css">
  <link rel="shortcut icon" href="ico/favicon.png">
</head>
<body>
<?php
$skriptDatei = "sh/eigeneCon.sh";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $DerDateiname = trim($_POST["dateiname"] ?? "");
    $DasPassword = trim($_POST["Password"] ?? "");	
    
    // Lade Datei
    $inhalt = file_get_contents($skriptDatei);

        // Ersetze die Zeile mit AlteSVWSanfang
    $inhaltNeu = preg_replace(
    [
        '/^dateiname="[^"]*"/m',
        '/^Password="[^"]*"/m'
    ],
    [
       'dateiname="' . $DerDateiname . '"',
       'Password="' . $DasPassword . '"'
    ],
    $inhalt
    );
        // Schreibe Datei zurück
        file_put_contents($skriptDatei, $inhaltNeu);
        echo "<p class='echo'>  Dateiname: <strong>$DerDateiname</strong> Passwort: <strong>$DasPassword</strong> Eingegeben.</p>";
        include "close.php";
}
?>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <form method="post">
    <label class="form" for="dateiname">Bitte Text hinter dem Usernamen aus dem Editor copieren und einfügen.</label>
    <input type="text" name="dateiname" id="dateiname" required><br><br>
    <label class="form" for="Password">Bitte Text hinter Passwort aus dem Editor copieren und einfügen.</label>
    <input type="text" name="Password" id="Password" width="350px" required><br><br>
    <button type="submit">weiter</button>
  </form>
 </div>
</div> 
</body>
</html>