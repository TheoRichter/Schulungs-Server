<?php
$uploadDir = '/netzlaufwerk/OfficelleTestDBS/EigeneSchemata/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['datenbankfile']) && $_FILES['datenbankfile']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['datenbankfile']['tmp_name'];
        $fileName = basename($_FILES['datenbankfile']['name']);
        $destPath = $uploadDir . $fileName;

        // Erlaubte Endungen und MIME-Typen
        $allowedExtensions = ['zip', 'mdb', 'sqlite', 'db'];
        $allowedMimeTypes = [
            'application/zip',
            'application/x-msaccess',   // .mdb (manchmal)
            'application/vnd.ms-access',// .mdb (manchmal)
            'application/octet-stream', // fallback
            'application/x-sqlite3',    // .sqlite
        ];

        $extension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $fileType = mime_content_type($fileTmpPath);

        if (in_array($extension, $allowedExtensions) && in_array($fileType, $allowedMimeTypes)) {
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                echo "Datei erfolgreich hochgeladen nach: $destPath";
                echo "
                <!DOCTYPE html>
                <html>
                 <head>
                  <title>Automatisches Schließen</title>
                  <script>
                  // Warte 3 Sekunden und schließe dann das Fenster
                  setTimeout(function () {
                   window.close();
                  }, 3000);
                  </script>
                 </head>
                 <body>
                  <p style='color:green;'>Diese Seite wird in 3 Sekunden automatisch geschlossen.</p>
                 </body>
                </html>
                "; 
               } else {
                echo "Fehler beim Verschieben der Datei.";
            }
        } else {
            echo "Nur ZIP, MDB, SQLITE und DB-Dateien sind erlaubt.";
        }
    } else {
      $errorCode = $_FILES['datenbankfile']['error'];
      echo "Fehler beim Hochladen. Fehlercode: $errorCode";
      echo "Datei-Upload fehlgeschlagen.";
    }
}
?>