<?php
session_start();
if (!isset($_SESSION['benutzer'])) {
    header("Location: inc/login/login.php");
    exit;
}
?>
<html>
<head>
 <title>SchILD-NRW-3</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row w3-indigo">
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
 <nav class="navbar navbar-inverse" style="border-radius: 0";>
  <div class="container-fluid">
   <ul class="nav navbar-nav">
    <li class="active"><a href="schild3.php"><span class="label label-danger">SchILD-NRW-3</span></a></li>
    <li><a href="index.php"><span class="label label-default">SVWS-Schemata-Update</span></a></li>
    <li><a href="svws-versions-update.php"><span class="label label-default">SVWS-Versions-Update</span></a></li>
    <li><a href="svws-tools-update.php"><span class="label label-default">SVWS-Tools-Update</span></a></li>
    <li><a href="container-status.php"><span class="label label-default">Status/Link</span></a></li>
   </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
  </div>
 </nav>
</div>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <h2 class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-arial w3-center" >Einspielen des neuen SchILD3.</h2>
  <div valign="center" class="w3-tooltip">
  <h3 class="w3-arial">1. Schritt</h3>
   <a href="https://github.com/SVWS-NRW/Schild3-BetaTest/releases" target="_blank">
   <font style="font-size:27px" color="blue">Setup_SchILD3_vx.x.xx.zip download</font></a>
   <font color="green">(Standartmäßig werden die Dateien im Downloads-Ordner des PCs gespeichert.)</font>
 </div>
</div>
</div>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <h3 class="w3-arial">2. Schritt</h3>
   <form id="scriptSchILD3" method="post" target="outputWindow" action="schild3_version.php">
    <!--<label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="Version">Versions-Nummer ändern.</label>&nbsp; -->
    <button class="w3-tooltip w3-leftbar w3-rightbar w3-large w3-arial" type="submit" id="Version" name="Version" value="Version">
      <!-- <span style="position:absolute;left:0;bottom:32px" class="w3-text w3-info">Öffnen der Schild3Download.sh</span> -->
     Release-Nummer ändern
    </button>
    <br />
   </form>
 </div>
</div> 
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
  <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
  <h3 class="w3-arial-">3. Schritt</h3>
   <form id="scriptSchILD3Update" method="post" target="outputWindow" action="schild3-update.php">
    <!--<label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="Schild3Download">Schild3 updaten.</label>&nbsp;-->
    <button class="w3-tooltip w3-leftbar w3-rightbar w3-large w3-arial" type="submit" id="Schild3Download" name="Schild3Download" value="Schild3Download">
     <!-- <span style="position:absolute;left:0;bottom:32px" class="w3-text w3-info">GEDULD!!!</span> -->
     Schild3 Update
    </button>
    <br />
   </form>
  </div>
 </div>
<!--#################### ANFANG FOOTER##############################################################################################################-->
<section id="footer"><!-- Anfang Footer -->
<?php include 'inc/footer/footer.php' ?>
</section><!-- Ende Footer -->
<!--#################### ENDE FOOTER##############################################################################################################-->
  <script>
    document.getElementById('scriptSchILD3').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=120');
    });
    document.getElementById('scriptSchILD3Update').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=600');
    });
    document.getElementById('scriptReports').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=300');
    });
  </script>
</body>
</html>
