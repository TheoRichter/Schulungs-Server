  let linkesFenster = null;
  let rechtesFenster = null;
  let checkIntervall = null;
//#######################################################################################################################################################
  document.getElementById('scriptDocker').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      /////window.open('', 'outputWindow', 'width=600,height=400');
    // Fenstergrößen definieren
    const breiteLinks = 600;
    const hoeheLinks = 400;
    const breiteRechts = 350;
    const hoeheRechts = 160;

    // Positionen berechnen
    const posLinksX = 0;
    const posLinksY = 0;
    const posRechtsX = breiteLinks; // direkt daneben
    const posRechtsY = 0;

    // Linkes Fenster öffnen (Formularziel)
    linkesFenster = window.open('', 'outputWindow',
      `width=${breiteLinks},height=${hoeheLinks},left=${posLinksX},top=${posLinksY}`);

    // Rechtes Fenster öffnen (Hinweis)
    rechtesFenster = window.open('', 'geduldHinweis',
      `width=${breiteRechts},height=${hoeheRechts},left=${posRechtsX},top=${posRechtsY}`);
    
    // Inhalt in Hinweisfenster schreiben
    rechtesFenster.document.write(`
      <html>
        <head><title>Hinweis</title></head>
        <body style='font-family:sans-serif; text-align:center; padding:20px; color:blue;'>
          <h2>Das dauert jetzt etwas!!</h2>
	      <img src="gif/kleineKreise.gif" alt="Bitte warten..." width="48" height="48">
        </body>
      </html>
    `);
    rechtesFenster.document.close();

    // Gegenseitige Überwachung
    if (checkIntervall) clearInterval(checkIntervall);
    checkIntervall = setInterval(() => {
      if (linkesFenster.closed || rechtesFenster.closed) {
        if (linkesFenster && !linkesFenster.closed) linkesFenster.close();
        if (rechtesFenster && !rechtesFenster.closed) rechtesFenster.close();
        clearInterval(checkIntervall);
      }
    }, 500);
  });