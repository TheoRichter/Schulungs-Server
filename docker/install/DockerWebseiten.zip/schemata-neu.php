<html>
<head>
 <title>Schemata Erneuern</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/sh.css">
  <link rel="shortcut icon" href="ico/favicon.png">
 </head>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Script = '';

    foreach ([
	'Gesamtschule',
	'Grundschule',
	'Berufschule',
	'GOSt_DB-1_VorbereitungEFPlanung',
	'GOSt_DB-2_Laufbahnen10EF-zumBlocken',
	'GOSt_DB-3_Blockungen10EFmitFehlern',
	'GOSt_DB-4-KlausurplanungEF2',
	'ENM_SVWS',
	'S1Schulung',
	'S2Schulung'
    ] as $key) {
        if (isset($_POST[$key])) {
            $Script = $key;
            break;
        }
    }

    $scriptPath = "sh/$Script.sh";

    if (file_exists($scriptPath)) {
        $output = shell_exec("bash " . escapeshellarg($scriptPath) . " 2>&1");
        echo "<pre class='start'>" . htmlspecialchars($output) . "</pre>";
        include "close.php";  
    } else {
        echo "<p style='color:red;'>Skript nicht gefunden: " . htmlspecialchars($scriptPath) . "</p>";
    }
}
?>
</body>
</html>
