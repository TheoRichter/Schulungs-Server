<html>
<head>
 <title>Docker-Status</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/sh.css">
  <link rel="shortcut icon" href="ico/favicon.png">
</head>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Script = '';

    foreach ([
        'StartSVWSmariaDB',
        'StopSVWSmariaDB',
        'StartWebserver',
        'StopWebserver',
        'StartPHPmyAdmin',
        'StopPHPmyAdmin',
    ] as $key) {
        if (isset($_POST[$key])) {
            $Script = $_POST[$key];
            break;
        }
    }

    $scriptPath = "sh/$Script.sh";
    //echo $_POST[$key];
	//exit;
    if (file_exists($scriptPath)) {
        $output = shell_exec("bash " . escapeshellarg($scriptPath) . " 2>&1");
        if (($Script == "StartSVWSmariaDB") or ($Script == "StartWebserver") or ($Script == "StartPHPmyAdmin")) {
		 echo "<pre class='start'>" . htmlspecialchars($output) . "</pre>";
		 include "close.php";  
		}
        if (($Script == "StopSVWSmariaDB") or ($Script == "StopWebserver") or ($Script == "StopPHPmyAdmin")) {
		 echo "<pre class='stop'>" . htmlspecialchars($output) . "</pre>";
		 include "close.php";  
		}
    } else {
        echo "<p style='color:red;'>Skript nicht gefunden: " . htmlspecialchars($scriptPath) . "</p>";
    }
}
?>
</body>
</html>