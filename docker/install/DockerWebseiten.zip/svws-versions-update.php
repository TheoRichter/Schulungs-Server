<?php
session_start();
if (!isset($_SESSION['benutzer'])) {
    header("Location: inc/login/login.php");
    exit;
}
?>
<html>
<head>
 <title>SVWS-Versions-Update</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/eigene.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
 <style>
/* Weiße Rahmen für die gesamte Tabelle und alle Zellen */
.svws-table {
    border: 2px solid #ffffff;
    border-collapse: collapse;
}

.svws-table th,
.svws-table td {
    border: 1px solid #ffffff;
}

 /* Kopfzeile Tools */
 .svws-table th:nth-child(1) {
    background: #23476a;
 }

/* Hintergrund der Spalte Tools */
.svws-table tbody td:nth-child(1) {
    background: #23476a;
    color: #fff; 
}

/* Hover-Effekt für Tools */
.svws-table tbody tr:hover td:nth-child(1) {
    background: #eee5a8;
}

 /* Kopfzeile Installiert */
 .svws-table th:nth-child(2) {
    background: #D9D9D9;
    color: #000; 
 }

 /* Hintergrund der Spalte Installiert */
 .svws-table tbody td:nth-child(2) {
    background: #D9D9D9;
 }

 /* Hover-Effekt für Installiert */
 .svws-table tbody tr:hover td:nth-child(2) {
    background: #D9D9D9;
}

 /* Versionszahlen in grau */
 .svws-table tbody td:nth-child(2) .version {
    color: #333333;
 }

 /* Kopfzeile Aktuell */
 .svws-table th:nth-child(3) {
    background: #218443;
 }

 /* Hintergrund der Spalte Aktuell */
 .svws-table tbody td:nth-child(3) {
    background: #218443;
 }

 /* Hover-Effekt für Aktuell */
 .svws-table tbody tr:hover td:nth-child(3) {
    background: #c8e6c9;
 }

 /* Versionszahlen in gruen */
 .svws-table tbody td:nth-child(3) .version {
    color: #218443;
 }
 
 .svws-table {
    width: 25%;
	margin: 0;
    border-collapse: separate;
    border-spacing: 0;
    font-family: Arial, sans-serif;
    font-size: 14px;
    color: #333;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 3px 12px rgba(0,0,0,0.10);
 }

 .svws-table th {
    background: #23476a;
    color: #fff;
    padding: 13px 15px;
    text-align: center;
    font-weight: bold;
 }

 .svws-table td {
    padding: 12px 15px;
    text-align: center;
    border-bottom: 1px solid #e5e5e5;
 }

 .svws-table tbody tr:nth-child(even) {
    background: #f2f6fa;
 }

 .svws-table tbody tr:nth-child(odd) {
    background: #ffffff;
 }

 .svws-table tbody tr:hover {
    background: #e3edf7;
 }

 .svws-table td:first-child {
    text-align: left;
    font-weight: bold;
    color: #23476a;
 }

 .version {
    display: inline-block;
    background: #e5f5e9;
    color: #218443;
    padding: 5px 12px;
    border-radius: 20px;
    font-weight: bold;
    font-size: 12px;
 }

 .svws-table tr:last-child td {
    border-bottom: none;
 }
 </style>
</head>
<body>
<div class="w3-row w3-indigo">
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
 <nav class="navbar navbar-inverse" style="border-radius: 0";>
  <div class="container-fluid">
   <ul class="nav navbar-nav">
    <li class="active"><a href="svws-versions-update.php"><span class="label label-danger">SVWS-Versions-Update</span></a></li>
    <li><a href="index.php"><span class="label label-default">SVWS-Schemata-Update</span></a></li>
    <li><a href="svws-tools-update.php"><span class="label label-default">SVWS-Tools-Update</span></a></li>
    <li><a href="schild3.php"><span class="label label-default">SchILD-NRW-3</span></a></li>
    <li><a href="container-status.php"><span class="label label-default">Status/Link</span></a></li>
   </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
  </div>
 </nav>
</div>
<!--#################### ANFANG svws ##############################################################################################################-->
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
   <h2 class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-arial w3-left">Die SVWS-Server-Releas-Version-Updaten.</h2>
  </div>
 </div>
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
  <h3 class="w3-arial">1. Schritt</h3>
  <!-- ANFANG svws-anzeige-->
  <?php include 'inc/updates/svws-anzeige.php' ?>
  <!-- ENDE svws-anzeige -->
   <form id="scriptSchulungen" method="post" target="outputWindow" action="schulungen.php">
    <!-- <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="schulungen">Die alte SVWS-Versions-Nummer und die neu SVWS-Version-Nummer eintragen.</label>&nbsp; -->
    <button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="schulungen" name="schulungen" value="schulungen">
       <span style="position:absolute;left:0;bottom:32px" class="w3-text w3-info">Neue SVWS-Versions-Nummer in die Datei: < schulungen.txt > eintragen.</span>
      Die SVWS-Versions-Nummern Eintragen
    </button>
    <br />
   </form>
  </div>
 </div>
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
  <h3 class="w3-arial-">2. Schritt</h3>
   <form id="scriptSVWS" method="post" target="outputWindow" action="stack-update.php">
    <!--<label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="SVWSVersion">Das SVWS-Versions-Update durchführen.</label>-->
	<button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="SVWSVersion" name="SVWSVersion" value="SVWSVersion">
	 <span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Das Updaten durchfüheren
	</button>
   </form>
   <br />
  </div>
 </div>
<!--#################### ENDE svws ##############################################################################################################-->
<!--#################### ANFANG FOOTER##############################################################################################################-->
<section id="footer"><!-- Anfang Footer -->
<?php include 'inc/footer/footer.php' ?>
</section><!-- Ende Footer -->
<!--#################### ENDE FOOTER##############################################################################################################-->
 <script>
  let linkesFenster = null;
  let rechtesFenster = null;
  let checkIntervall = null;

  document.getElementById('scriptSVWS').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      ////window.open('', 'outputWindow', 'width=800,height=600');
    // Fenstergrößen definieren
    const breiteLinks = 800;
    const hoeheLinks = 600;
    const breiteRechts = 350;
    const hoeheRechts = 160;

    // Positionen berechnen
    const posLinksX = 0;
    const posLinksY = 0;
    const posRechtsX = breiteLinks; // direkt daneben
    const posRechtsY = 0;

    // Linkes Fenster öffnen (Formularziel)
    linkesFenster = window.open('', 'outputWindow',
      `width=${breiteLinks},height=${hoeheLinks},left=${posLinksX},top=${posLinksY}`);

    // Rechtes Fenster öffnen (Hinweis)
    rechtesFenster = window.open('', 'geduldHinweis',
      `width=${breiteRechts},height=${hoeheRechts},left=${posRechtsX},top=${posRechtsY}`);
    
    // Inhalt in Hinweisfenster schreiben
    rechtesFenster.document.write(`
      <html>
        <head><title>Hinweis</title></head>
        <body style="font-family:sans-arial; text-align:center; padding:20px; color:blue;">
          <h2>Das dauert jetzt etwas!!</h2>
		  <img src="gif/kleineKreise.gif" alt="Bitte warten..." width="48" height="48">
        </body>
      </html>
    `);
    rechtesFenster.document.close();

    // Gegenseitige Überwachung
    if (checkIntervall) clearInterval(checkIntervall);
    checkIntervall = setInterval(() => {
      if (linkesFenster.closed || rechtesFenster.closed) {
        if (linkesFenster && !linkesFenster.closed) linkesFenster.close();
        if (rechtesFenster && !rechtesFenster.closed) rechtesFenster.close();
        clearInterval(checkIntervall);
      }
    }, 500);
    });
    document.getElementById('scriptSchulungen').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=250');
    });
//     document.getElementById('scriptSichern').addEventListener('submit', function () {
//      // Fenster vorher öffnen (wichtig für Popup-Blocker)
//      window.open('', 'outputWindow', 'width=800,height=250');
//    });
      document.getElementById('scriptVersion').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=250');
    });
    document.getElementById('scriptUpload').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=600');
    });
  </script>
</body>
</html>
