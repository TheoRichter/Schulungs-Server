<?php
session_start();
if (!isset($_SESSION['benutzer'])) {
    header("Location: inc/login/login.php");
    exit;
}
?>
<html>
<head>
 <title>SVWS-Versions-Update</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/eigene.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row w3-indigo">
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
 <nav class="navbar navbar-inverse" style="border-radius: 0";>
  <div class="container-fluid">
   <ul class="nav navbar-nav">
    <li class="active"><a href="svws-versions-update.php"><span class="label label-danger">SVWS-Versions-Update</span></a></li>
    <li><a href="index.php"><span class="label label-default">SVWS-Schemata-Update</span></a></li>
    <li><a href="wenom-versions-update.php"><span class="label label-default">WENOM-Versions-Update</span></a></li>
    <li><a href="schild3.php"><span class="label label-default">SchILD-NRW-3</span></a></li>
    <li><a href="container-status.php"><span class="label label-default">Status/Link</span></a></li>
   </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
  </div>
 </nav>
</div>
<!--#################### ANFANG svws ##############################################################################################################-->
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
   <h2 class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-arial w3-center">Die SVWS-Server-Releas-Version-Updaten.</h2>
  </div>
 </div>
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
  <h3 class="w3-arial">1. Schritt</h3>
   <iframe src="schulungen.html" width="95%" height="150px" frameborder="0" style="background-color:"></iframe>
   <form id="scriptSchulungen" method="post" target="outputWindow" action="schulungen.php">
    <!--<label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="schulungen">Die alte SVWS-Versions-Nummer und die neu SVWS-Version-Nummer eintragen.</label>&nbsp;-->
    <button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="schulungen" name="schulungen" value="schulungen">
       <span style="position:absolute;left:0;bottom:32px" class="w3-text w3-info">Neue SVWS-Versions-Nummer in die Datei: < schulungen.txt > eintragen.</span>
      Die SVWS-Versions-Nummern Eintragen
    </button>
    <br />
   </form>
  </div>
 </div>
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
  <h3 class="w3-arial-">2. Schritt</h3>
   <form id="scriptSVWS" method="post" target="outputWindow" action="stack-update.php">
    <!--<label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="SVWSVersion">Das SVWS-Versions-Update durchführen.</label>-->
	<button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="SVWSVersion" name="SVWSVersion" value="SVWSVersion">
	 <span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Das Updaten durchfüheren
	</button>
   </form>
   <br />
  </div>
 </div>
<!--#################### ENDE svws ##############################################################################################################-->
<!--#################### ANFANG FOOTER##############################################################################################################-->
<section id="footer"><!-- Anfang Footer -->
<?php include 'inc/footer/footer.php' ?>
</section><!-- Ende Footer -->
<!--#################### ENDE FOOTER##############################################################################################################-->
 <script>
  let linkesFenster = null;
  let rechtesFenster = null;
  let checkIntervall = null;

  document.getElementById('scriptSVWS').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      ////window.open('', 'outputWindow', 'width=800,height=600');
    // Fenstergrößen definieren
    const breiteLinks = 800;
    const hoeheLinks = 600;
    const breiteRechts = 350;
    const hoeheRechts = 160;

    // Positionen berechnen
    const posLinksX = 0;
    const posLinksY = 0;
    const posRechtsX = breiteLinks; // direkt daneben
    const posRechtsY = 0;

    // Linkes Fenster öffnen (Formularziel)
    linkesFenster = window.open('', 'outputWindow',
      `width=${breiteLinks},height=${hoeheLinks},left=${posLinksX},top=${posLinksY}`);

    // Rechtes Fenster öffnen (Hinweis)
    rechtesFenster = window.open('', 'geduldHinweis',
      `width=${breiteRechts},height=${hoeheRechts},left=${posRechtsX},top=${posRechtsY}`);
    
    // Inhalt in Hinweisfenster schreiben
    rechtesFenster.document.write(`
      <html>
        <head><title>Hinweis</title></head>
        <body style="font-family:sans-arial; text-align:center; padding:20px; color:blue;">
          <h2>Das dauert jetzt etwas!!</h2>
		  <img src="gif/kleineKreise.gif" alt="Bitte warten..." width="48" height="48">
        </body>
      </html>
    `);
    rechtesFenster.document.close();

    // Gegenseitige Überwachung
    if (checkIntervall) clearInterval(checkIntervall);
    checkIntervall = setInterval(() => {
      if (linkesFenster.closed || rechtesFenster.closed) {
        if (linkesFenster && !linkesFenster.closed) linkesFenster.close();
        if (rechtesFenster && !rechtesFenster.closed) rechtesFenster.close();
        clearInterval(checkIntervall);
      }
    }, 500);
    });
    document.getElementById('scriptSchulungen').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=250');
    });
//     document.getElementById('scriptSichern').addEventListener('submit', function () {
//      // Fenster vorher öffnen (wichtig für Popup-Blocker)
//      window.open('', 'outputWindow', 'width=800,height=250');
//    });
      document.getElementById('scriptVersion').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=250');
    });
    document.getElementById('scriptUpload').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=600');
    });
  </script>
</body>
</html>
