<html>
<head>
 <title>SchILD3-Connection-Files Erstellen</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/form.css">
  <link rel="shortcut icon" href="ico/favicon.png">
</head>
<body>
<?php
$skriptDatei = "sh/Schild3ConnetionFiles.sh";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $AnzahlWinPCs = trim($_POST["anzahl"] ?? "");
    $ServerIP = trim($_POST["ip"] ?? "");	
    
    // Lade Datei
    $inhalt = file_get_contents($skriptDatei);

    // Ersetze die Zeile mit $inhaltNeu
     if (preg_match('/^(\d{1,3}\.){3}\d{1,3}$/', $ServerIP)) {
		 $inhaltNeu = preg_replace(
        [
         '/^ENDE="[^"]*"/m',
         '/^SERVERNAME="[^"]*"/m'
        ],
        [
        'ENDE="' . $AnzahlWinPCs . '"',
        'SERVERNAME="' . $ServerIP . '"'
        ],
        $inhalt
        );
        // Schreibe Datei zurück
        file_put_contents($skriptDatei, $inhaltNeu);
        echo "<p class='echo'>  Die DockerIP ist <strong>$ServerIP</strong> und es wurden <strong>$AnzahlWinPCs</strong> Windows-PCs Eingegeben.</p>";
        include "close.php";
		exit;
		} else {
		if (isset($inhaltNeu) && !empty($inhaltNeu)) {	
         echo "<p style='color:red;'>Ungültige $inhaltNeu.</p>";
	    }
	 }
}
?>
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
 <form method="post">
    <label class="form" for="anzahl">Bitte die Anzahl der Windows-PCs Eingeben.</label>
    <input type="text" name="anzahl" id="anzahl" required><br><br>
    <label class="form" for="ip">Bitte die DockerIP (z.B. 10.1.0.3) Eingeben.</label>
    <input type="text" name="ip" id="ip" required><br><br>
    <button type="submit">weiter</button>
 </form>
 </div>
</div> 
</body>
</html>