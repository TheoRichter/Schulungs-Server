<html>
<head>
 <title>Auf Update Pr&uuml;fen</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/eigene.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
 </head>
<body>
 <div class="w3-row">
  <div class="w3-col w3-container" style="width:2%">
   <p> </p>
  </div>
  <div class="w3-col w3-container" style="width:98%">
   <h2 class="w3-blue w3-center">Das Versions-Update.</h2>
   <iframe src="https://web.webolch.de/bauanleitung/downloads/linux/zip/DockerWebseitenZip/" width="95%" height="325" frameborder="0" style="background-color:"></iframe>
  </div>
 </div>
</body>
</html>