<?php
session_start();
include 'inc/conf/config.inc.php';
if (!isset($_SESSION['benutzer'])) {
    header("Location: inc/login/login.php");
    exit;
}
?>
<html>
<head>
 <title>SVWS-Schemata-Erneuern</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/eigene.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="shortcut icon" href="ico/favicon.png">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="w3-row w3-indigo">
 <div class="w3-container w3-threequarter w3-padding-16">
  <a href="https://svws-nrw.github.io/Schulungsunterlagen/" target="_blank">
   <img src="png/nrw-logo.png" class="w3-round" alt="NRW-Logo" width="100">
  </a>	
 </div>
</div>
<div class="w3-row">
 <nav class="navbar navbar-inverse" style="border-radius: 0";>
  <div class="container-fluid">
   <ul class="nav navbar-nav">
    <li class="active"><a href="index.php"><span class="label label-danger">SVWS-Schemata-Update</span></a></li>
    <li><a href="svws-versions-update.php"><span class="label label-default">SVWS-Versions-Update</span></a></li>
    <li><a href="svws-tools-update.php"><span class="label label-default">SVWS-Tools-Update</span></a></li>
    <li><a href="schild3.php"><span class="label label-default">SchILD-NRW-3</span></a></li>
    <li><a href="container-status.php"><span class="label label-default">Status/Link</span></a></li>
   </ul>
<!-- navbar links -->
   <ul class="nav navbar-nav navbar-right">
    <li class=""><a href="inc/login/logout.php"><span class="label label-info height-label"><img src="../svg/box-arrow-in-right.svg" alt="table.svg" width="20" height="20">&nbsp;Logout</span></a></li>
   </ul>
  </div>
 </nav>
</div>
<!-- ANFANG Status -->
<iframe src="statusanzeiger-docker-container.php" width="100%" height="220" frameborder="0" style="background-color:"></iframe> 
<!-- ENDE Status -->
<!-- Anfang Schemata -->
<div class="w3-row">
 <div class="w3-col w3-container" style="width:2%">
  <p> </p>
 </div>
 <div class="w3-col w3-container" style="width:98%">
  <h2 class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-arial w3-center" >Zurücksetzen der Schulungs-Schemata.</h2>
  <form id="scriptSchemata" method="post" target="outputWindow" action="schemata-neu.php">
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="Berufschule">BerufschulSchemata neu einspielen.</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="Berufschule" name="Berufschule" value="Berufschule"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Berufschule einspielen</button><br />
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="ENM_SVWS">Das ENM_SVWS Schemata neu einspielen.</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="ENM_SVWS" name="ENM_SVWS" value="ENM_SVWS"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>ENM_SVWS einspielen</button><br />
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="GOSt_DB-1_VorbereitungEFPlanung"><h4><b>Eigenschaften:</b></h4> + Stand 2. HJ + Keine Noteneinträge + keine Abiturjahrgänge angelegt + Fächer noch ohne SekII-Sortierung + ggf. Fächer Oberstufe ergänzen (z.B. PA) oder entfernen (z.B: I0) + keine Neuaufnahmen + keine Fachwahlen in 10 (neue EF) + fehlende Einstellungen der Laufbahnplanung (Kombinationen, BL, Texte)<h4><b>geeignet für:</b></h4> + Facheinstellungen+ Anlage Abiturjahrgänge + Einrichtung Laufbahnplanungen (Kombinationen, BL, Texte) + Erstellung Laufbahnplanungen (Fachwahlen).</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="GOSt_DB-1_VorbereitungEFPlanung" name="GOSt_DB-1_VorbereitungEFPlanung" value="GOSt_DB-1_VorbereitungEFPlanung"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Vorbereitung EF Planung einspielen</button><br />
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="GOSt_DB-2_Laufbahnen10EF-zumBlocken"><h4><b>Eigenschaften:</b></h4> + Noten 2. HJ + Fächer SekII sortiert + Fachwahlen 10 (neue EF) und EF (neue Q1) eingespielt + Fachwahlen noch teilweise fehlerhaft + keine Blockungen <h4><b>geeignet für:</b></h4> + Korrekturen Laufbahnen + Einstellungen Blockungsbedingungen  Berechnungen Blockunge + Versetzung in nächstes Schuljahr + ggf. Übertragung fertiger Blockungen.</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="GOSt_DB-2_Laufbahnen10EF-zumBlocken" name="GOSt_DB-2_Laufbahnen10EF-zumBlocken" value="GOSt_DB-2_Laufbahnen10EF-zumBlocken"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span> Laufbahnen 10EF zum Blocken einspielen</button><br />
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="GOSt_DB-3_Blockungen10EFmitFehlern"><h4><b>Eigenschaften:</b></h4> + wie DB-2 aber mit fertigen Blockungen + teilweise mehrere Ergebnisse + NV-Fehler <h4><b>geeignet für:</b></h4> + Korrekturen und Neuberechnungen von Blockungen (Ableiten) + Versetzung in nächstes Schuljahr + Übertragen von Blockungen + Änderungen in Fachwahlen nach Übertrag/Synchronisationen + Einrichtung Stundenplan.</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="GOSt_DB-3_Blockungen10EFmitFehlern" name="GOSt_DB-3_Blockungen10EFmitFehlern" value="GOSt_DB-3_Blockungen10EFmitFehlern"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Blockungen 10EF mit Fehlern einspielen</button><br />
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="GOSt_DB-4-KlausurplanungEF2"><h4><b>Eigenschaften:</b></h4> + wie DB-3 + Stundenplan eingerichtet (Zeitraster, Räume, Pausenzeiten) + aktuelle EF2 hat Leistungsdaten + aktuelle EF2 hat Stundenplan eingerichtet <h4><b>geeignet für:</b></h4> + Klausurplanung.</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="GOSt_DB-4-KlausurplanungEF2" name="GOSt_DB-4-KlausurplanungEF2" value="GOSt_DB-4-KlausurplanungEF2"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Klausurplanung EF2 einspielen</button><br />
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="S1Schulung">Zur S1-Schulung die Schemata neu einspielen.</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="S1Schulung" name="S1Schulung" value="S1Schulung"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>S1 Schulung einspielen</button><br />
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="S2Schulung">Zur S2-Schulung die Schemata neu einspielen.</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="S2Schulung" name="S2Schulung" value="S2Schulung"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>S2 Schulung einspielen</button><br />
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="Gesamtschule">Das Gesamtschule-Schemata neu einspielen.</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="Gesamtschule" name="Gesamtschule" value="Gesamtschule"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Gesamtschule einspielen</button><br />
   <label class="w3-panel w3-leftbar w3-rightbar w3-khaki w3-large w3-arial" for="Grundschule">Das Grundschule-Schemata neu einspielen.</label><br /><button class="w3-tooltip w3-leftbar w3-rightbar" type="submit" id="Grundschule" name="Grundschule" value="Grundschule"><span style="position:absolute;left:0;bottom:36px" class="w3-text w3-info">GEDULD!!</span>Grundschule einspielen</button><br />
  </form>
 <br /> 
 </div>
</div>
<!-- &nbsp; Ende Schemata ############################################################################################################################### -->
<!--################################################################################################################################################-->
<!--#################### ANFANG FOOTER##############################################################################################################-->
<section id="footer"><!-- Anfang Footer -->
<?php include 'inc/footer/footer.php' ?>
</section><!-- Ende Footer -->
<!--#################### ENDE FOOTER#################################################################################################################-->
<!-- ### Anfang java Script -->
<script>
  let linkesFenster = null;
  let rechtesFenster = null;
  let checkIntervall = null;
//#######################################################################################################################################################
  document.getElementById('scriptSchemata').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      /////window.open('', 'outputWindow', 'width=600,height=400');
    // Fenstergrößen definieren
    const breiteLinks = 800;
    const hoeheLinks = 600;
    const breiteRechts = 350;
    const hoeheRechts = 160;

    // Positionen berechnen
    const posLinksX = 0;
    const posLinksY = 0;
    const posRechtsX = breiteLinks; // direkt daneben
    const posRechtsY = 0;

    // Linkes Fenster öffnen (Formularziel)
    linkesFenster = window.open('', 'outputWindow',
      `width=${breiteLinks},height=${hoeheLinks},left=${posLinksX},top=${posLinksY}`);

    // Rechtes Fenster öffnen (Hinweis)
    rechtesFenster = window.open('', 'geduldHinweis',
      `width=${breiteRechts},height=${hoeheRechts},left=${posRechtsX},top=${posRechtsY}`);
    
    // Inhalt in Hinweisfenster schreiben
    rechtesFenster.document.write(`
      <html>
        <head><title>Hinweis</title></head>
        <body style='font-family:sans-arial; text-align:center; padding:20px; color:blue;'>
          <h2>Das dauert jetzt etwas!!</h2>
	      <img src="gif/Sanduhr.gif" alt="Bitte warten..." width="48" height="48">
        </body>
      </html>
    `);
    rechtesFenster.document.close();

    // Gegenseitige Überwachung
    if (checkIntervall) clearInterval(checkIntervall);
    checkIntervall = setInterval(() => {
      if (linkesFenster.closed || rechtesFenster.closed) {
        if (linkesFenster && !linkesFenster.closed) linkesFenster.close();
        if (rechtesFenster && !rechtesFenster.closed) rechtesFenster.close();
        clearInterval(checkIntervall);
      }
    }, 500);
  });
</script>
<!--
<script>
 document.getElementById('scriptSchemata').addEventListener('submit', function () { 
 	      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=800,height=600');
   });
</script>

<script>
   document.getElementById('scriptDocker').addEventListener('submit', function () {
	   	      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=600,height=400');
   });	  
</script>
-->
<script>
    document.getElementById('scriptCon').addEventListener('submit', function () {
	      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=600,height=400');
   });	 
</script>
<script>   
   document.getElementById('scriptVariablen').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=600,height=400');
   });
</script>
<script>
   document.getElementById('scriptCon').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=600,height=400');
   });
</script>
<script>
   document.getElementById('scriptDatenbankSchemata').addEventListener('submit', function () {
      // Fenster vorher öffnen (wichtig für Popup-Blocker)
      window.open('', 'outputWindow', 'width=600,height=400');
   });
</script>
 <!-- ### ENDE java Script -->
</body>
</html>
