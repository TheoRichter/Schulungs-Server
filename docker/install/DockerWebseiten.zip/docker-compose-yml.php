<html>
<head>
 <title>Docker Compose yml</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/sh.css">
  <link rel="shortcut icon" href="ico/favicon.png">
</head>
<body>
<?php
$pfad = 'docker/pc-01/pc-01/docker-compose-svws.yml';
$inhalt = file($pfad); // Datei zeilenweise als Array einlesen

$ausgabe = '';
$zeigeZeilen = false;

foreach ($inhalt as $zeile) {
    // Dienst "svws-server" gefunden
    if (preg_match('/^\s*svws-server:/', $zeile)) {
        $ausgabe .= $zeile;
        $zeigeZeilen = true;
        continue;
    }

    // Wenn die image-Zeile kommt, solange wir im richtigen Abschnitt sind
    if ($zeigeZeilen && preg_match('/^\s+image:/', $zeile)) {
        $ausgabe .= $zeile;
        break; // Danach aufhören, da wir alles haben
    }
}

// HTML-sicher und formatiert ausgeben
echo "<pre class='db'>" . htmlspecialchars($ausgabe) . "</pre>";
?>
</body>
</html>